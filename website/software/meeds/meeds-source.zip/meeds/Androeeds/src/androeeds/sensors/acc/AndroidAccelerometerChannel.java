package androeeds.sensors.acc;

import seeds.sensors.sys.acc.AccelerometerChannel;
import seeds.sensors.sys.common.VSensor;

public class AndroidAccelerometerChannel extends AccelerometerChannel {
	
	private final AndroidAccelerometerSensor accelerometer = new AndroidAccelerometerSensor() ;

	protected VSensor getSensor() {
		return accelerometer ;
	}
}
