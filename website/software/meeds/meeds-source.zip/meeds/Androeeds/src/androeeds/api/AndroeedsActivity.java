package androeeds.api;

import android.app.Activity;
import androeeds.sys.core.AndroidNodeContext;


public class AndroeedsActivity extends Activity {

	protected AndroeedsActivity() {
		context = new AndroidNodeContext(this) ;
	}
	
	
	
	protected AndroidNodeContext context ; 
}
