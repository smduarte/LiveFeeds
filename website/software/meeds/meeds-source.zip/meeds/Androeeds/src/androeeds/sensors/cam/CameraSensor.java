package androeeds.sensors.cam;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.hardware.Camera;
import android.hardware.Camera.PictureCallback;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.Window;

public class CameraSensor extends Activity {
	private Preview mPreview;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// Hide the window title. 
		requestWindowFeature(Window.FEATURE_NO_TITLE);

		// Create our Preview view and set it as the content of our activity. 
		mPreview = new Preview(this);
		setContentView(mPreview);
	}


	@Override
	public boolean onPrepareOptionsMenu(Menu menu) {
		super.onPrepareOptionsMenu(menu);
		menu.clear();
		if (mPreview.active)
			menu.add(0, 1, 0, "take picture");
		else {
			menu.add(0, 2, 0, "save picture");
			menu.add(0, 3, 0, "take another pic");
		}
		return true;
	}

	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		switch (item.getItemId()) {
		case 1:
			try {
				mPreview.captureImage();
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case 2:
//			setResult(RESULT_OK, new Intent().putExtra("picture",
//					mPreview.picdata));
			
//			AndroidCamContainer.Store c = Container.byClass(AndroidCamContainer.class);
//			c.storeValue(mPreview.picdata);
			finish();
			break;
			
		case 3:
			mPreview.restartPreview();
			break;
		}
		return true;
	}

}

//---------------------------------------------------------------------- 

class Preview extends SurfaceView implements SurfaceHolder.Callback {
	SurfaceHolder mHolder;
	public Camera mCamera;
	public Bitmap bm;
	public byte[] picdata;
	public boolean active = false;

	Preview(Context context) {
		super(context);
		// Install a SurfaceHolder.Callback so we get notified when the 
		// underlying surface is created and destroyed. 
		mHolder = getHolder();
		mHolder.addCallback(this);
		mHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
	}

	public void surfaceCreated(SurfaceHolder holder) {
		// The Surface has been created, acquire the camera and tell it where 
		// to draw. 
		try {
			mCamera = Camera.open();
			mCamera.setPreviewDisplay(holder);
		} catch( Exception x ) {
			x.printStackTrace() ;
		}
	}

	public void surfaceDestroyed(SurfaceHolder holder) {
		// Surface will be destroyed when we return, so stop the preview. 
		// Because the CameraDevice object is not a shared resource, it's very 
		// important to release it when the activity is paused. 
		mCamera.stopPreview();
		mCamera = null;
	}

	public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) {
		// Now that the size is known, set up the camera parameters and begin 
		// the preview. 
		Camera.Parameters parameters = mCamera.getParameters();
		parameters.setPreviewSize(w, h);
		mCamera.setParameters(parameters);
		mCamera.startPreview();
		active = true;
	}

	public void captureImage() {
		Camera.Parameters params = mCamera.getParameters();

		mCamera.setParameters(params);
		Camera.PictureCallback cb = new PictureCallback() {
			public void onPictureTaken(byte[] data, Camera camera) {
				picdata = data;
				//				bm = BitmapFactory.decodeByteArray(data, 0, data.length); 
				try {
					//					FileOutputStream out = new FileOutputStream("/sdcard/mypick.png"); 

					//					myimage.compress(Bitmap.CompressFormat.PNG, 10, out); 
					//					out.close(); 

				} catch (Exception e) {
					e.printStackTrace();
				}

				//				ImageView mImageDisplay = (ImageView) findViewById(R.id.image_display); 
				//				mImageDisplay.setImageBitmap(b); 
			}
		};
		mCamera.takePicture(null, null, cb);
		mCamera.stopPreview();
		active = false;
		//		mCamera.release(); 
	}

	public void restartPreview() {
		mCamera.startPreview();
		active = true;
	}
}