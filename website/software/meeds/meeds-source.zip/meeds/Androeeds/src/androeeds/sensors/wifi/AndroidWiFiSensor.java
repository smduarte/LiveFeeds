package androeeds.sensors.wifi;

import java.util.ArrayList;
import java.util.List;

import seeds.sensors.api.wifi.HotSpot;
import seeds.sensors.api.wifi.WiFiData;
import seeds.sensors.sys.wifi.WiFiSensor;
import androeeds.sys.core.AndroidNodeContext;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import feeds.sys.tasks.Task;

public class AndroidWiFiSensor extends WiFiSensor {

	@Override
	protected void init() {
		super.init();

		final WiFiScanner scanner = new WiFiScanner();
		
		new Task(currentConfig.refreshRate) {
			public void run() {
				scanner.scanAreas() ;
				reSchedule(currentConfig.refreshRate);
			}
		} ;
	};



	class WiFiScanner extends BroadcastReceiver {

		WifiManager manager;

		WiFiScanner() {
			Activity main = AndroidNodeContext.main;
			manager = (WifiManager) main.getSystemService(Context.WIFI_SERVICE);
			main.registerReceiver(this, new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));
		}

		public void scanAreas() {
			manager.startScan() ;
		}
		
		public void onReceive(Context c, Intent intent) {
			List<HotSpot> res = new ArrayList<HotSpot>() ;
			
			for( ScanResult i : manager.getScanResults() ) {
				res.add( new HotSpot( i.BSSID, i.SSID, i.capabilities, i.frequency, i.level) ) ;
			}	
			currentValue = new WiFiData( res, null ) ;
			
			notifyUpdateNow() ;
		}
	}

	public void reconfigureSensor() {
	}
}
