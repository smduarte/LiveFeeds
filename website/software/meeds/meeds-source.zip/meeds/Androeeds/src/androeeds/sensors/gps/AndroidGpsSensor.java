package androeeds.sensors.gps;

import seeds.sensors.api.gps.GpsLocation;
import seeds.sensors.sys.gps.GpsSensor;
import androeeds.sys.core.AndroidNodeContext;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import feeds.sys.tasks.Task;

public class AndroidGpsSensor extends GpsSensor implements LocationListener {

	protected LocationManager manager;
	protected LooperThread looperThread ;


	protected void init() {
		super.init();

		this.manager = AndroidNodeContext.getLocationManager();

		new Task(0) {
			public void run() {
				if (manager != null) {
					notifyUpdateNow() ;
				}
				this.reSchedule(currentConfig.refreshRate);
			}
		};

		looperThread = new LooperThread();
		looperThread.start() ;
		
	}

	protected void reconfigureSensor() {
		if( looperThread != null )
			looperThread.config() ;
	}

	public void onLocationChanged(Location location) {
		System.out.println("onLocationChanged..." + location);
		currentLocation = new GpsLocation(location.getLongitude(), location.getLatitude(), location.getTime(), location.getSpeed(), location.getAccuracy(), location.getBearing());
	}

	public void onProviderDisabled(String arg0) {
		System.out.println("onProviderDisabled..." + arg0);

	}

	public void onProviderEnabled(String arg0) {
		System.out.println("onProviderEnabled..." + arg0);

	}

	public void onStatusChanged(String arg0, int arg1, Bundle arg2) {
		System.out.println("onStatusChanged..." + arg0 + "/" + arg1 + "/" + arg2);

	}

	class LooperThread extends Thread {
		public Handler mHandler;
		private Looper looper;

		public void run() {
			Looper.prepare();
			looper = Looper.myLooper();

			mHandler = new Handler() {
				public void handleMessage(Message msg) {
					Thread.dumpStack() ;
				}
			};
			config() ;
			
			Looper.loop();
		}

		void config() {
			manager.removeUpdates(AndroidGpsSensor.this);
			manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, currentConfig.minTime, currentConfig.minDistance, AndroidGpsSensor.this, looper);
		}
	}

}
