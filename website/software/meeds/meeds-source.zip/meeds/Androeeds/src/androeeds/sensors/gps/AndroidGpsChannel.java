package androeeds.sensors.gps;

import seeds.sensors.sys.common.VSensor;
import seeds.sensors.sys.gps.GpsChannel;

public class AndroidGpsChannel extends GpsChannel {

	private final AndroidGpsSensor gpsSensor= new AndroidGpsSensor()  ;
	
	protected VSensor getSensor() {
		return gpsSensor ;
	}
}
