package androeeds.sys.core;


import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Enumeration;
import java.util.Random;

import androeeds.sys.directory.AndroidDirectoryStorage;
import androeeds.sys.util.FeedsPrintStream;
import android.app.Activity;
import android.content.Context;
import android.hardware.SensorManager;
import android.location.LocationManager;
import android.net.wifi.WifiManager;
import feeds.api.Feeds;
import feeds.sys.FeedsRegistry;
import feeds.sys.binding.Binding;
import feeds.sys.core.ClientNodeContext;
import feeds.sys.core.ID;
import feeds.sys.membership.MembershipService;
import feeds.sys.registry.RegistryService;

public class AndroidNodeContext extends ClientNodeContext {

	public static Activity main;

	public AndroidNodeContext(Activity a) {
		main = a;
		init();
	}

	public void init() {
		reg.init();
		tf.init();

		System.setErr( Feeds.out = new FeedsPrintStream("out") ) ;
		System.setOut( Feeds.err = new FeedsPrintStream("err") ) ;

		FeedsRegistry.put("DataURL", "nat://-/-/");
		FeedsRegistry.put("BindingURLs", "tcp://10.22.102.162:39999");

		Binding.start() ;

		AndroidDirectoryStorage.init();
		RegistryService.start() ;
		MembershipService.start();

		
	}

	public static WifiManager getWifiManager() {
		return (WifiManager) main.getSystemService(Context.WIFI_SERVICE);
	}

	public static LocationManager getLocationManager() {
		return (LocationManager) main.getSystemService(Context.LOCATION_SERVICE);
	}

	public static SensorManager getSensorManager() {
		return (SensorManager) main.getSystemService(Context.SENSOR_SERVICE);
		
	}

	public static SensorManager getVirtualSensorManager() {
		return getSensorManager();
		// OpenIntents.requiresOpenIntents(main);
		// if(simulator==null){
		// Hardware.mContentResolver = main.getContentResolver();
		// simulator = new
		// SensorManagerSimulator(((SensorManager)main.getSystemService(Context.SENSOR_SERVICE)));
		// }
		// System.out.println("ip address- "+Hardware.IPADDRESS);
		// return simulator;
	}
	
	public String ipAddress() {
		try {
			
			for (Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces(); en.hasMoreElements();) {
				NetworkInterface intf = en.nextElement();
				for (Enumeration<InetAddress> enumIpAddr = intf.getInetAddresses(); enumIpAddr.hasMoreElements();) {
					InetAddress inetAddress = enumIpAddr.nextElement();
					Feeds.err.println( inetAddress + "/" + inetAddress.isSiteLocalAddress() ) ;
					if (!inetAddress.isLoopbackAddress() ) {
						return inetAddress.getHostAddress().toString();
					}
				}
			}
		} catch (Exception x) {
			x.printStackTrace() ;
		}
		return "127.0.0.1";
	}	
	
	private static ID getID( Activity a ) {
		return new ID( new Random().nextLong() ) ;
	}
}


//public class AndroidNodeContext extends MobileNodeContext {
//
//	public static Activity main;
//
//	public AndroidNodeContext(Activity a) {
//		super( getID(a) ) ;
//		main = a;
//		init();
//	}
//
//	public void init() {
//
//		System.setErr( Feeds.out = new FeedsPrintStream("out") ) ;
//		System.setOut( Feeds.err = new FeedsPrintStream("err") ) ;
//		
////		Feeds.out = System.out ;
////		Feeds.err = System.err ;
//		
//		reg = new NodeRegistry();
//		scheduler = new TaskScheduler();
//
//		dir = new ChannelDirectory();
//		plm = new PipelineManager();
//		tf = new MeedsTransports().init();
//		scheduler.start();
//
//		AndroidDirectoryStorage.init();
//		MeedsRegistryService.start();
//		
////		FeedsRegistry.put("DataURL", "udp://-:0/-");
//		FeedsRegistry.put("DataURL", "nat://-/-/");
//		FeedsRegistry.put("HomebaseURLs", "tcp://193.136.124.226:20000");
//
//		Homing.start();
//		new ProxyBinding().start();
//	}
//
//	public static WifiManager getWifiManager() {
//		return (WifiManager) main.getSystemService(Context.WIFI_SERVICE);
//	}
//
//	public static LocationManager getLocationManager() {
//		return (LocationManager) main.getSystemService(Context.LOCATION_SERVICE);
//	}
//
//	public static SensorManager getSensorManager() {
//		return (SensorManager) main.getSystemService(Context.SENSOR_SERVICE);
//		
//	}
//
//	public static SensorManager getVirtualSensorManager() {
//		return getSensorManager();
//		// OpenIntents.requiresOpenIntents(main);
//		// if(simulator==null){
//		// Hardware.mContentResolver = main.getContentResolver();
//		// simulator = new
//		// SensorManagerSimulator(((SensorManager)main.getSystemService(Context.SENSOR_SERVICE)));
//		// }
//		// System.out.println("ip address- "+Hardware.IPADDRESS);
//		// return simulator;
//	}
//	
//	public String ipAddress() {
//		try {
//			
//			for (Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces(); en.hasMoreElements();) {
//				NetworkInterface intf = en.nextElement();
//				for (Enumeration<InetAddress> enumIpAddr = intf.getInetAddresses(); enumIpAddr.hasMoreElements();) {
//					InetAddress inetAddress = enumIpAddr.nextElement();
//					Feeds.err.println( inetAddress + "/" + inetAddress.isSiteLocalAddress() ) ;
//					if (!inetAddress.isLoopbackAddress() ) {
//						return inetAddress.getHostAddress().toString();
//					}
//				}
//			}
//		} catch (Exception x) {
//			x.printStackTrace() ;
//		}
//		return "127.0.0.1";
//	}	
//	
//	private static ID getID( Activity a ) {
//		return new ID( new Random().nextLong() ) ;
//	}
//}
