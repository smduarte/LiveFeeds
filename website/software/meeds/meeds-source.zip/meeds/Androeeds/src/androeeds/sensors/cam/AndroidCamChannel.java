package androeeds.sensors.cam;

import seeds.sensors.sys.cam.CamChannel;
import seeds.sensors.sys.common.VSensor;

public class AndroidCamChannel extends CamChannel {

	private final AndroidCamSensor camera = new AndroidCamSensor() ;
	
	@Override
	protected VSensor getSensor() {
		return camera ;
	}

	
//	public void init(){
//		super.init();
//		cam = Container.byClass(AndroidCamContainer.class);
//		
//		Container.monitor(AndroidCamContainer.class, new ContainerListener<CamContainer>(){
//			public void handleContainerUpdate(CamContainer c) {
//				CamData data = c.getValue();
//				fPacket<CamData, Void> f = new fPacket<CamData, Void>(channel(),thisNode,thisNode,data,null);
//				try {
//					fRoute(f);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}		
//			}
//		});
//	}
//	
//	public void pRoute( pPacket<CamRequest, Object> p ) throws Exception {
//        cam.requestPicture(p.envelope());
//    }
//    
//    public void fRoute( fPacket< CamData, Void> p ) throws Exception {
//    	loq.send(p);
//    }
//    
//	private CamContainer cam;
//	private ID thisNode = FeedsNode.id();
}
