package androeeds.sensors.acc;

import seeds.sensors.api.acc.AccData;
import seeds.sensors.sys.acc.AccelerometerSensor;
import androeeds.sys.core.AndroidNodeContext;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import feeds.sys.tasks.Task;

public class AndroidAccelerometerSensor extends AccelerometerSensor implements SensorEventListener {

	SensorManager manager;
	
	public void init(){
		super.init() ;
		
		manager = AndroidNodeContext.getSensorManager();
		manager.unregisterListener(this);

		Sensor s = manager.getDefaultSensor( Sensor.TYPE_ACCELEROMETER ) ;
		if( s != null ) {
			manager.unregisterListener(this);
			manager.registerListener( this, s, SensorManager.SENSOR_DELAY_NORMAL ) ;			
		}
				
		new Task(currentConfig.refreshTime){
			public void run() {
				notifyUpdateNow() ;
				reSchedule(currentConfig.refreshTime);
			}
		};
	}

	public void onAccuracyChanged(Sensor sensor, int accuracy) {
		// TODO Auto-generated method stub		
	}

	public void onSensorChanged(SensorEvent event) {
		float[] acc = event.values ;
		currentValue = new AccData( acc[SensorManager.DATA_X], acc[SensorManager.DATA_Y], acc[SensorManager.DATA_Z]) ;
	}

	protected void reconfigureSensor() {
	}
}
