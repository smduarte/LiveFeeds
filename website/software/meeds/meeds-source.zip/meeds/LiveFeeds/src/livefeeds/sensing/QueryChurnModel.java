package livefeeds.sensing;

import umontreal.iro.lecuyer.probdist.ExponentialDist;
import umontreal.iro.lecuyer.probdist.TruncatedDist;
import umontreal.iro.lecuyer.probdist.WeibullDist;
import umontreal.iro.lecuyer.randvar.RandomVariateGen;
import umontreal.iro.lecuyer.rng.MRG32k3a;
import umontreal.iro.lecuyer.util.Num;

public class QueryChurnModel {

	public double WEIBULL_SHAPE = 1.8 ;
	public double AVERAGE_QUERY_DURATION = 8 * 3600 ;
	public double AVERAGE_QUERY_SPAWN_RATE = 0.01 ;
	
	static double gamma(double x) {
		return Math.exp(Num.lnGamma(x));
	}

	final private double lambda = AVERAGE_QUERY_SPAWN_RATE / gamma(1 + 1 / WEIBULL_SHAPE);
	final RandomVariateGen spawnGen = new RandomVariateGen(new MRG32k3a(), new ExponentialDist(AVERAGE_QUERY_SPAWN_RATE));
	final RandomVariateGen durationGen = new RandomVariateGen(new MRG32k3a(), new TruncatedDist(new WeibullDist(WEIBULL_SHAPE, 1 / lambda, 0), 0, AVERAGE_QUERY_DURATION));

	
	public double nextQuery() {
		return spawnGen.nextDouble() ;
	}
	
	
	public double queryDuration() {
		return durationGen.nextDouble() ;
	}
	
}
