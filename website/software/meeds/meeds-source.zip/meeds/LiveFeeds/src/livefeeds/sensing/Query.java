package livefeeds.sensing;

import java.awt.geom.Area;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import livefeeds.twister6.TurmoilNode;

public class Query extends SingletonQuery {
	
	Set<SingletonQuery> singletons = new TreeSet<SingletonQuery>() ;
	
	public Query( SingletonQuery q ) {
		super( q.serial, q.expires, q.timestamp ) ;
		this.area = (Area)q.area.clone() ;
		singletons.add( q ) ;
	}
	
	public Query( Query other ) {
		super( other.serial, other.expires, other.timestamp ) ;
		this.area = (Area)other.area.clone() ;
		this.singletons = new TreeSet<SingletonQuery>( other.singletons ) ;
	}
	
	public Query( Query a, Query b, double timestamp ) {
		super( serial(a,b), Math.min( a.expires, b.expires ), timestamp ) ;

		this.singletons.addAll( a.singletons ) ;
		this.singletons.addAll( b.singletons ) ;
		this.area = (Area) a.area.clone() ;
		this.area.add( (Area) b.area.clone() ) ;
				
		if(  ! area.equals( a.area ) && ! area.equals( b.area ) ) {
			this.timestamp += 0.001 ;
		}
		this.area = new Area( this.area.getBounds() ) ;
	}
			
	public Query clone() {
		return new Query( this ) ;
	} 
	
	public boolean isExpired( double ts ) {
		if( expires >= ts ) return false ;
		else {
			for( Iterator<SingletonQuery> it = singletons.iterator() ; it.hasNext() ; ) {
				if( it.next().isExpired(ts) ) 
					it.remove() ;
			}
			this.area = new Area() ;
			return true ;
		}
	}
	
	boolean isDisjoint() {
		return ! area.isSingular() ;
	}
		
	public boolean notify( TurmoilNode node, List<TurmoilNode> path ) {
		return ((AbstractSensingNode)node).notify( this, path ) ;
	}
	
	public Query touch( double ts ) {
		this.timestamp = Math.max(this.timestamp, ts) ;
		return this ;
	}
	
	public String toString() {
		return String.format("(%s | %.6f %s)", serial, timestamp, singletons ) ;
	}
	
	public boolean insertects( Query other ) {
		Area x =(Area)area.clone() ;
		x.intersect( other.area ) ;
		if( ! x.isEmpty() ) return true ;
		
		return false ;
//		x = (Area)area.clone() ;
//		x.add( other.area ) ;
//		return ! (x.equals(this.area) || x.equals(other.area)) ; // cannot be enclosed...
	}
	
	
	static String serial( Query a, Query b ) {
		TreeSet<String> tmp = new TreeSet<String>() ;
		for( SingletonQuery i : a.singletons )
			tmp.add( i.serial ) ;
		for( SingletonQuery i : b.singletons )
			tmp.add( i.serial ) ;

		StringBuilder sb = new StringBuilder() ;
		for( String i : tmp )
			sb.append(i).append(' ') ;
		
		return sb.toString().trim() ;
	}
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
}
