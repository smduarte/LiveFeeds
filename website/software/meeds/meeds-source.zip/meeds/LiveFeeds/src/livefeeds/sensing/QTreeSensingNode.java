package livefeeds.sensing;

<<<<<<< QTreeSensingNode.java
=======
import static simsim.core.Simulation.rg;

>>>>>>> 1.2
import java.util.List;

import livefeeds.sensing.msgs.QuadCast;
import livefeeds.sensing.msgs.QuadCastPayload;
import livefeeds.sensing.msgs.SensingSocketHandler;
import livefeeds.twister6.CatadupaNode;
import livefeeds.twister6.Event;
import livefeeds.twister6.Range;

import simsim.gui.geom.Square;
import simsim.sockets.Socket;
import simsim.utils.RandomList;

public class QTreeSensingNode extends AbstractSensingNode implements SensingSocketHandler {

	public boolean notify(Query q, List<TurmoilNode> path) {
		if (currentTime() < q.expires) {

			Path p = qpaths.get( q ) ;
			if( p == null || q.timestamp > p.timestamp )
				qpaths.put(q, new Path(q.timestamp, path));
			
			out(index + "  GOOOOT QQ" + q + " @      " + currentTime() + "   " + path);

//			Query q2 = q.clone() ;
//			q2.expand() ;
			
			merged.add( new MergedQuery(q));

			lastPublish = Math.max(lastPublish, q.timestamp);
			checkForExpiration(q.timestamp);
			
			if (mergeQueries(path.size(), q.timestamp))
				return false;
		}
		return true;
	}


	Region queryFilter() {
		double WIDTH = 1000;

		double d = Math.pow(2, QuadQuery.MIN_QUAD_DIV);
		double w = WIDTH / d;

		double x = w * (0.5 + (int) (pos.x / w)), y = w * (0.5 + (int) (pos.y / w));
		return new Region(new Square(x, y, w));
	}

	 public void publish( Event ev ) {
		 onReceive( (Socket)null, new QuadCast(0, new Quad(), ev ).append(this));
	 }

	public void onReceive(Socket sock, QuadCast m) {

		if (m.level > 0)
			if( ! m.payload.notify(this, m.path) )
				return ;
		
		List<CatadupaNode> nodes = new Range().nodeList(state.db, new Query(m.quad));
		nodes.removeAll(m.path);
		
		if (nodes.size() > 3 && m.level < (QuadQuery.MIN_QUAD_DIV + 2)) {
			for (Quad i : m.quad.divide() ) {
				RandomList<CatadupaNode> candidates = new Range().nodeList(state.db, new Query(i));

				CatadupaNode j ;
				while((j = candidates.removeRandomElement()) != null ) {
					if( j.accepts( m.payload ) && !m.path.contains(j)) {
						boolean ok = socket.send(j.endpoint, new QuadCast(m.level + 1, i, m.payload).append(m.path, this), 0);
						if (ok)
							break;
					}					
				}
			}
		} else {

			for (CatadupaNode j : nodes)
				if( j.accepts( m.payload ) )
					socket.send(j.endpoint, new QuadCastPayload(m.payload).append(m.path, this), 0);
		}
	}

	public void onReceive(Socket sock, QuadCastPayload m) {
		m.payload.notify(this, m.path);
	}
}
