package livefeeds.sensing;

import static simsim.core.Simulation.rg;

import java.awt.geom.Area;

import simsim.core.Simulation;
import simsim.gui.geom.Square;
import simsim.gui.geom.XY;

public class SingletonQuery extends SensingEvent implements Comparable<SingletonQuery>{
		
	Area area ;	
	double expires ; 
	double timestamp ;
	final public String serial ;

	protected SingletonQuery( String serial, double ttl, double timestamp ) {
		this.serial = serial ;
		this.expires = ttl ;
		this.timestamp = timestamp ;
	}
	
	public SingletonQuery( SingletonQuery other ) {
		this( other.serial, other.expires, other.timestamp) ;
		this.area = (Area) other.area.clone() ;
	}

	public SingletonQuery( Square sq, double ttl ) {
		this( "" + g_serial++, ttl, Math.ceil( Simulation.currentTime() ) ) ;
		area = new Area(sq) ;
		expires = ttl ;
	}
	
	public SingletonQuery( Area a ) {
		this( "" + g_serial++, -1, -1 ) ;
		area = (Area) a.clone() ;
	}
	
	public SingletonQuery( Quad q ) {
		this( "" + g_serial++, -1, -1 ) ;
		area = new Area( q.shape ) ;
	}
	
	public SingletonQuery( double ttl ) {
		serial = "" + g_serial++ ;
		timestamp = Math.ceil(Simulation.currentTime()) ;
		expires = ttl + timestamp ;
		XY center = new XY( rg.nextDouble(), rg.nextDouble() ).mult( 600 + 400 * rg.nextDouble() ) ;
		area = new Area( new Square( center, 150 + 150 * rg.nextDouble() ) ) ;
		System.out.println(serial);
	}
		
	public SingletonQuery clone() {
		return new SingletonQuery( this ) ;
	}
	
	public boolean isExpired( double ts ) {
		return ts > expires ;
	}
	
	public int hashCode() {
		return serial.hashCode() ;
	}
	
	public boolean equals( SingletonQuery other ) {
		return other != null && serial.equals(other.serial);
	}
	
	public boolean equals( Object other ) {
		return other != null && equals( (SingletonQuery)other ) ;
	}

	public String toString() {
		return String.format("%s %.0fh", serial, (expires - Simulation.currentTime())/3600 ) ;
	}
	
	public SingletonQuery touch( double ts ) {
		this.timestamp = Math.max(this.timestamp, ts) ;
		return this ;
	}
	
	public void expand() {}
	/**
	 * 
	 */
	protected static int g_serial = 0 ;

	@Override
	public int compareTo(SingletonQuery other) {
		return serial.compareTo( other.serial ) ;
	}

	private static final long serialVersionUID = 1L;
}
