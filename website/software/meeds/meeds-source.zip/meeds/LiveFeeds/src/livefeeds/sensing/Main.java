package livefeeds.sensing;

import static livefeeds.twister6.config.Config.Config;
import static livefeeds.twister6.stats.Statistics.Statistics;
import static simsim.core.Simulation.DisplayFlags.SIMULATION;
import static simsim.core.Simulation.DisplayFlags.THREADS;
import static simsim.core.Simulation.DisplayFlags.TIME;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;

import livefeeds.twister6.ArrivalsDB;
import livefeeds.twister6.CatadupaNode;
import livefeeds.twister6.GlobalDB;
import livefeeds.twister6.View;

import simsim.core.Displayable;
import simsim.core.PeriodicTask;
import simsim.core.Simulation;
import simsim.core.Task;
import simsim.gui.canvas.Canvas;
import simsim.gui.canvas.Pen;
import simsim.gui.canvas.RGB;
import simsim.gui.geom.Square;
import simsim.gui.geom.XY;
import simsim.gui.pdf.PDF;

public class Main extends Simulation implements Displayable {

	public Main() {
		super(10, EnumSet.of(TIME, THREADS, SIMULATION));
	}

	List<SingletonQuery> queries = new ArrayList<SingletonQuery>() ;


	public Main init() {

		View.init();
		GlobalDB.init();
		ArrivalsDB.init();
		Statistics.init();

		simsim.logging.Log.Log.setLevel( Level.OFF ) ;
		
		new Task(Config.churn.nextArrival()) {
			public void run() {
				new RTreeSensingNode().init();
				if( GlobalDB.size() < 50 )
					reSchedule(Config.churn.nextArrival());
			}
		};

		final QueryChurnModel queryModel = new QueryChurnModel();

//		new Task(queryModel.nextQuery()) {
//			public void run() {
//				SensingNode x = GlobalDB.randomLiveNode();
//
//				if (x != null)
//					x.issueQuery(new Query(currentTime() + queryModel.queryDuration()));
//
//				reSchedule(queryModel.nextQuery());
//			}
//		};
		
		new Task(3500) {
			public void run() {
					if( queries.size() < 12 ) {
						AbstractSensingNode x = GlobalDB.randomLiveNode();
						if (x != null) {
							SingletonQuery q = new QuadQuery(1000 + 1500 * rg.nextDouble() ) ;
							x.publish(q);
							queries.add(q) ;
						}
						reSchedule( 30 + 160 * rg.nextDouble() ) ;
					} else
						reSchedule( 1300 + 1600 * rg.nextDouble() ) ;
					
				}
		};

		super.setSimulationMaxTimeWarp(10000);

		new Task(3500) {
			public void run() {
					AbstractSensingNode x ;
					
					SingletonQuery q1 = new SingletonQuery( new Square(350,350,200), 600000 ) ; 
					queries.add( q1 ) ;
					x = GlobalDB.randomLiveNode();
					x.publish( q1 );
					
					SingletonQuery q2 = new SingletonQuery( new Square(400,400,200), 600000 ) ; 
					queries.add( q2 ) ;
					x = GlobalDB.randomLiveNode();
					x.publish( q2 );

					SingletonQuery q3 = new SingletonQuery( new Square(550,550,200), 60000 ) ; 
					queries.add( q3 ) ;
					x = GlobalDB.randomLiveNode();
					x.publish( q3 );

					SingletonQuery q4 = new SingletonQuery( new Square(700,700,200), 600000 ) ; 
					queries.add( q4 ) ;
					x = GlobalDB.randomLiveNode();
					x.publish( q4 );

					SingletonQuery q5 = new SingletonQuery( new Square(750,750,200), 600000 ) ; 
					queries.add( q5 ) ;
					x = GlobalDB.randomLiveNode();
					x.publish( q5 );
				}
		};
		
//		new Task(3500) {
//			public void run() {
//					RTreeSensingNode x = GlobalDB.randomLiveNode();
//					BasicQuery q1 = new QuadQuery( new Square(500,300,300), 16000000 ) ; 
//					queries.add( q1 ) ;
//					x.publish( q1 );
//					BasicQuery q2 = new QuadQuery( new Square(600,500,300), 60000000 ) ; 
//					queries.add( q2 ) ;
//					x.publish( q2 );
//					BasicQuery q3 = new QuadQuery( new Square(700,700,300), 16000000 ) ; 
//					queries.add( q3 ) ;
//					x.publish( q3 );
//				}
//		};
//		
		
		new PeriodicTask( 1 ) {
			public void run() {
				double now = currentTime() ;
				for( Iterator<SingletonQuery> i = queries.iterator() ; i.hasNext() ; )
					if( now > i.next().expires )
						i.remove() ;
			}
		};
		

		Gui.setDesktopSize(1280, 800);
		Gui.setFrameRectangle("MainFrame", 0, 0, 800, 800);
		// Gui.addDisplayable("Network", Network, 0.01);
		// Gui.setFrameRectangle("Network", 0, 504, 216, 216);
		// Gui.setFrameTransform("Network", 1000, 1000, 0.01, true);

		// Gui.addDisplayable("View", new ViewDisplay(), 5);
		// Gui.setFrameRectangle("View", 220, 504, 216, 216);
		// Gui.setFrameTransform("View", 1000, 1000, 0.0, false);
		// //
		// Gui.addDisplayable("DeadNodes", new DeadNodesDisplay(), 5);
		// Gui.setFrameRectangle("DeadNodes", 700, 10, 512, 512);
		// Gui.setFrameTransform("DeadNodes", 1000, 1000, 0.0, false);

		Gui.setDesktopSize(1600, 1000);
		// Gui.maximizeFrame("LatencyHistogram");


		new PeriodicTask(3600) {
			public void run() {
				PDF.saveToPDF(Main.this, "/tmp/foo.pdf", 1000, 1000) ;
			}
		};
		
		super.start();
		return this;
	}

	public void displayOn( Canvas canvas ) {

		canvas.uDraw("Nodes:" + GlobalDB.size(), 2, 50 ) ;
		// Display the nodes
//		for (CatadupaNode i : GlobalDB.liveNodes()) {
//			CatadupaNode j = (CatadupaNode) i ;
//			canvas.sFill( new Circle(i.state.pos, 4) ) ;
//		}

		for (CatadupaNode i : GlobalDB.liveNodes()) {
			i.displayOn(canvas);
		}

		// Find closest node to the mouse pointer
		XY mouse = canvas.sMouse();
		AbstractSensingNode closest = null ;
		for (CatadupaNode i : GlobalDB.liveNodes() ) {
			AbstractSensingNode j = (AbstractSensingNode) i ;
			if (closest == null || mouse.distance( j.filter.shape.center() ) < mouse.distance( closest.filter.shape.center()))
				closest = j;
		}

		Pen p = new Pen( new RGB(0.2, 0.2, 0.2, 0.1), 1.0 ) ;
		for( SingletonQuery i : queries) {
			canvas.sFill( p, i.area ) ;
			canvas.sDraw(i.toString(), new XY(i.area.getBounds().getCenterX(), i.area.getBounds().getCenterY()));
		}

		
		if( closest != null )
			closest.displayOn2(canvas) ;

		
//		Set<MergedQuery> merged = new HashSet<MergedQuery>() ;
//		for (CatadupaNode i : GlobalDB.liveNodes() ) {
//			AbstractSensingNode j = (AbstractSensingNode) i ;
//			merged.addAll( j.merged ) ;
//		}
//
//		Pen pg = new Pen( new RGB(0, 0.8, 0, 0.05), .0 ) ;
//		for( Query i : merged)
//			canvas.sDraw( pg, i.area ) ;

		
	}
}