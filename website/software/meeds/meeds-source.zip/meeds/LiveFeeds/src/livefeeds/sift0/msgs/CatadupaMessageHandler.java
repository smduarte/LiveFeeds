package livefeeds.sift0.msgs;

import simsim.core.MessageHandler;

public interface CatadupaMessageHandler extends MessageHandler {
	
	//public void onReceive( EndPoint src, DepartureNotice m) ;
		
}
