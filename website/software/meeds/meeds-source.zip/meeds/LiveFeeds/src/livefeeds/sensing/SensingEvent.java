package livefeeds.sensing;

import java.util.List;

import livefeeds.twister6.Event;
import livefeeds.twister6.TurmoilNode;

public class SensingEvent extends Event {

	static int counter = 0 ;

	@Override
	public boolean notify( TurmoilNode node ) {
		counter++ ;
		System.out.println(counter);
		return node.notify( this ) ;
	}
	
	@Override
	public boolean notify( TurmoilNode node, List<TurmoilNode> path ) {
		counter++ ;
		System.out.println(counter);
		return ((AbstractSensingNode)node).notify( (SingletonQuery)this, path ) ;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
}
