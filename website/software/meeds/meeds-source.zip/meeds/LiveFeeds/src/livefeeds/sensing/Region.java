package livefeeds.sensing;

import livefeeds.twister6.Event;
import livefeeds.twister6.Filter;

import simsim.gui.geom.Rectangle;

public class Region extends Filter {
	
	Rectangle shape;
	
	public Region( Rectangle s ) {
		this.shape = s ;
	}
	
	public boolean accepts( Event e ) {
		SingletonQuery q = (SingletonQuery) e ;
		return q.area.intersects( shape ) ;
	}
	
	public boolean intersects( SingletonQuery q ) {
		return q.area.intersects( shape ) ;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
}
