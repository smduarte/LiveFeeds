package seeds.sensors.sys.common;

public interface SensorParameters {	
}
