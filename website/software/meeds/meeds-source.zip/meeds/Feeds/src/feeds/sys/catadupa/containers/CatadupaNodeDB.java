package feeds.sys.catadupa.containers;

public interface CatadupaNodeDB {

	
	public interface Updater {
		
	}
}
