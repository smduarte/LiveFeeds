package feeds.sys.registry;

public enum Location {
	SOFTSTATE, HARDSTATE 
}
