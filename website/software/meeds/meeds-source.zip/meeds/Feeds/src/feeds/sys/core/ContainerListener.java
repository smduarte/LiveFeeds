package feeds.sys.core;

public interface ContainerListener<T> {    
    void handleContainerUpdate( T c ) ;    
}
