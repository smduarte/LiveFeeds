package simsim.gui.pdf;

import java.awt.Graphics2D;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;

import simsim.core.Displayable;
import simsim.gui.canvas.Canvas;

import com.lowagie.text.pdf.DefaultFontMapper;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfTemplate;
import com.lowagie.text.pdf.PdfWriter;

public class PDF {

	/**
	 * Save chart as PDF file. Requires iText library.
	 * 
	 * @param chart
	 *            JFreeChart to save.
	 * @param fileName
	 *            Name of file to save chart in.
	 * @param width
	 *            Width of chart graphic.
	 * @param height
	 *            Height of chart graphic.
	 * @throws Exception
	 *             if failed.
	 * @see <a href="http://www.lowagie.com/iText">iText</a>
	 */
	static public void saveToPDF(Displayable d, String fileName, int width, int height) {
		try {
			BufferedOutputStream out = null;
			try {
				out = new BufferedOutputStream(new FileOutputStream(fileName));

				// convert chart to PDF with iText:
				com.lowagie.text.Rectangle pagesize = new com.lowagie.text.Rectangle(width, height);
				com.lowagie.text.Document document = new com.lowagie.text.Document(pagesize, 50, 50, 50, 50);
				try {
					PdfWriter writer = PdfWriter.getInstance(document, out);
					document.addAuthor("SimSim");
					document.open();

					PdfContentByte cb = writer.getDirectContent();
					PdfTemplate tp = cb.createTemplate(width, height);
					Graphics2D g2 = tp.createGraphics(width, height, new DefaultFontMapper());
					d.displayOn(new Canvas(g2, g2));
					g2.dispose();
					cb.addTemplate(tp, 0, 0);
				} finally {
					document.close();
				}
			} finally {
				if (out != null) {
					out.close();
				}
			}
		} catch (Exception x) {
			x.printStackTrace();
		}
	}
}
