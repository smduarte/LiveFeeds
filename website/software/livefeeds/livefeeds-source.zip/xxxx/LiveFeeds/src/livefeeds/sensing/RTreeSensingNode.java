package livefeeds.sensing;

import simsim.gui.geom.Square;

public class RTreeSensingNode extends AbstractSensingNode {

	Region queryFilter() {
		return new Region(new Square(pos, 250));
	}

}
