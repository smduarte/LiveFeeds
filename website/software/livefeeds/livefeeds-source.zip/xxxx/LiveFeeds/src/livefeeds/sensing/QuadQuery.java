package livefeeds.sensing;


import static simsim.core.Simulation.rg;

import java.awt.geom.Area;
import java.awt.geom.Rectangle2D;

import simsim.core.Simulation;
import simsim.gui.geom.Rectangle;
import simsim.gui.geom.Square;
import simsim.gui.geom.XY;


public class QuadQuery extends SingletonQuery {
	static int MIN_QUAD_DIV = 3;


	public QuadQuery( QuadQuery other ) {
		super( other.serial, other.expires, other.timestamp ) ;
		this.area = (Area) other.area.clone() ;
	}
	
	public QuadQuery clone() {
		return new QuadQuery( this ) ;
	}

	public QuadQuery( Square sq, double ttl ) {
		super("" + g_serial++, ttl, Math.ceil( Simulation.currentTime() ) ) ;
		area = new Area(sq) ;
		expand() ;
	}
	
	public QuadQuery( double ttl ) {
		super( "" + g_serial++, Math.ceil(Simulation.currentTime()) + ttl, Math.ceil(Simulation.currentTime()) ) ;
		XY center = new XY( rg.nextDouble(), rg.nextDouble() ).mult( 600 + 400 * rg.nextDouble() ) ;
		area = new Area( new Square( center, 150 + 150 * rg.nextDouble() ) ) ;
		expand() ;
	}
	
//	public QuadQuery( Area a ) {
//		super( g_serial++) ;
//		area = (Area) a.clone() ;
//		expires = timestamp = -1 ;
//		expand() ;
//	}
	
	
	public void expand2() {
		double minQLenW = 1000 / Math.pow(2, MIN_QUAD_DIV);
		double minQLenH = 1000 / Math.pow(2, MIN_QUAD_DIV);

		Rectangle2D bounds = area.getBounds2D() ;
		
		double x1 = minQLenW * Math.floor(bounds.getMinX() / minQLenW) ;
		double y1 = minQLenH * Math.floor(bounds.getMinY() / minQLenH) ;

		double x2 = minQLenW * Math.ceil(bounds.getMaxX() / minQLenW) ;
		double y2 = minQLenH * Math.ceil(bounds.getMaxY() / minQLenH) ;

		area = new Area( new Rectangle.Double(x1, y1, x2-x1, y2-y1 ) );
	}
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
}
