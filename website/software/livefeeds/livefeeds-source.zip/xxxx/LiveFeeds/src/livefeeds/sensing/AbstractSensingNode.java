package livefeeds.sensing;

import static simsim.core.Simulation.rg;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import livefeeds.twister6.CatadupaNode;
import livefeeds.twister6.Event;
import livefeeds.twister6.GlobalDB;
import livefeeds.twister6.TurmoilNode;

import simsim.core.PeriodicTask;
import simsim.core.Simulation;
import simsim.gui.canvas.Canvas;
import simsim.gui.canvas.Pen;
import simsim.gui.canvas.RGB;
import simsim.gui.geom.Circle;
import simsim.gui.geom.Line;
import simsim.gui.geom.XY;

abstract public class AbstractSensingNode extends TurmoilNode {

	final static double DELTA = 1;
	XY pos;
	Region filter;

	LogicalClock clock = new LogicalClock() ;
	
	Set<Query> querySet= new HashSet<Query>();
	Map<SingletonQuery, Path> qpaths = new HashMap<SingletonQuery, Path>();

	
	AbstractSensingNode() {
		pos = newPos() ;
		state.filter = filter = queryFilter();
	}

	
	abstract Region queryFilter() ;
	
	public boolean accepts(Event e) {
		return state.filter.accepts(e) && super.isOnline() && state.joined;
	}

	public void shutdown() {
		//super.shutdown() ;
	}
	
	static double events = 0 ;
	static double queries = 0;
	
	public void publish( SingletonQuery q ) {
		queries++;
		events++ ;
		super.publish( new Query(q).touch( clock.increment() ) ) ;
	}
		
	public void publish( Query q ) {
		events++ ;
		super.publish( q ) ;
	}
	
	public boolean notify(Query q, List<TurmoilNode> path) {
		q = q.clone() ;
		if ( clock.physicalTime() + 300 < q.expires && q.timestamp > clock.logicalTime() ) {

			Path p = qpaths.get( q ) ;
			if( p == null || q.timestamp > p.timestamp )
				qpaths.put(q, new Path(q.timestamp, path));

			print("notify: QUERY:" + q + " path: " + path);
			
			clock.max( q.timestamp ) ;
			
			querySet.add(q);
			mergeQueries() ;
			publishQueries() ;			
		}
		return true;
	}
	
	public void init() {
		super.init();

		//Check for expired queries...
		new PeriodicTask(this, 5 * rg.nextDouble(), 30 + 5 * rg.nextDouble()) {
			public void run() {
				checkForExpiration() ;
			}
		};


		//Refresh queries paths
//		new PeriodicTask(this, 300) {
//			public void run() {
//				for (MergedQuery i : querySet) {
//					i.touch( logicalTime() );
//					publish(i);
//				}
//			}
//		};
	}
			
	void mergeQueries() {

		print("IN: querySet:" + querySet) ;

		List<Query> tmp = new ArrayList<Query>( querySet );

		boolean merged ;
		Double nextLogicalTick = null ;
		do {
			merged = false ;
loop:		for (int i = 0; i < tmp.size(); i++) {
				Query qi = tmp.get(i);
				for (int j = tmp.size(); --j > i;) {
					Query qj = tmp.get(j);

					print(" MERGING" + qi + "+" + qj + "->" + (qj.insertects(qi)));
					if (qj.insertects(qi)) {
						if( nextLogicalTick == null )
							nextLogicalTick = clock.increment() ;
						
						tmp.remove(i);
						tmp.remove(j - 1);
						tmp.add(new Query(qi, qj, nextLogicalTick));
						merged = true ;
						break loop;
					}
				}

			}
		} while( merged ) ;
		
		Set<Query> res = new HashSet<Query>() ;
		for( Query i : tmp )
			if( filter.accepts( i) )
				res.add(i) ;

		querySet = new HashSet<Query>( res ) ;
		print("OUT: querySet:" + querySet) ;
	}
	
	void checkForExpiration() {
		print("checkForExpiration: querySet:" + querySet) ;

		for (Iterator<SingletonQuery> i = qpaths.keySet().iterator(); i.hasNext();)
			if (i.next().isExpired( clock.physicalTime() ))
				i.remove();
		
		Set<SingletonQuery> orphanSet = new HashSet<SingletonQuery>();


		for (Iterator<Query> i = querySet.iterator(); i.hasNext();) {
			Query qi = i.next();
			if( qi.isExpired( clock.physicalTime() ) ) {
				i.remove();
				orphanSet.addAll( qi.singletons ) ;
			}
		}

		print("orphanSet:" + orphanSet) ;

		if( orphanSet.size() > 0 ) {
			Double nextLogicalTick = clock.increment() ;
			for( SingletonQuery i : orphanSet )
				querySet.add( new Query(i).touch( nextLogicalTick ) ) ;
		
			mergeQueries() ;
			publishQueries() ;
		}
	}

	boolean publishQueries() {
		print("IN: querySet:" + querySet) ;
		
		final Set<Query> p = new HashSet<Query>();
		
		for (Query i : querySet) {
			if (i.timestamp > clock.logicalTime() ) {
				p.add(i);
				publish(i.clone());						
//				final MergedQuery qi = i ;
//				Path qp = qpaths.get(i) ;
//				double delay = qp == null ? 0 : (0.5 * qp.path.size() + 1) * rg.nextDouble() ;
//				new Task( delay ) {
//					public void run() {
//					}
//				};
			}
		}
		
		if (p.size() > 0)
			print("PUBLISHED: " + p);

			
		return p.size() > 0 ;
	}

	boolean XXX() {
		//return index == 22 ;
		return true;
		// return false && (index == 4 || index == 97 || index == 108);
	}

	void print(String s) {
		if (XXX())
			System.out.printf("%4d --> %s  %s\n", index, clock, s);
	}
	
	static final Pen pen0 = new Pen(RGB.BLACK, 0.5);
	static final Pen pen1 = new Pen(RGB.LIGHT_GRAY, 0.1, 3);
	static final Pen pen2 = new Pen(new RGB(0.7, 0, 0, 0.1), 1, 3);
	static final Pen pen3 = new Pen(RGB.GREEN.darker(), 4);
	static final Pen pen4 = new Pen(RGB.BLUE, 0.5);
	static final Pen pen5 = new Pen(RGB.RED, 2.0);

	@Override
	public void displayOn(Canvas canvas) {
		if (!state.joined)
			return;

		canvas.sFont(14);
		canvas.sDraw("" + events / (queries * GlobalDB.size()), new XY(10, 100)) ;
		canvas.sDraw(pen0, "" + index, pos.add(2, 10));
		canvas.sDraw(pen1, filter.shape);
		canvas.sFill(pen0, new Circle(pos, 5));

		pen5.useOn(canvas.gs);
		for (Query i : querySet) {
			Path p = qpaths.get(i);
			XY p0 = pos;
			double w = 1.0;
			if (p != null && p.path.size() > 0)
				for (TurmoilNode j : p.path) {
					Pen pen = new Pen(RGB.red, w += 1);
					AbstractSensingNode y = (AbstractSensingNode) j;
					XY p1 = y.pos;
					canvas.sDraw( pen, new Line(p0, p1) ) ;
					p0 = p1;
				}
		}
	}

	public void displayOn2(Canvas canvas) {
		if (!state.joined)
			return;

		canvas.sDraw(pen4, filter.shape);

		pen2.useOn(canvas.gs);
		for (SingletonQuery i : querySet) {
			canvas.sFill(i.area);
			canvas.sDraw(i.toString(), new XY(i.area.getBounds().getCenterX(), i.area.getBounds().getCenterY()));
		}

		pen3.useOn(canvas.gs);
		for (Query i : querySet)
			canvas.sDraw(i.area);

		canvas.sFont(20);
		for (SingletonQuery i : querySet) {
			canvas.uDraw(RGB.RED, index + " : " + i.toString(), new XY(0*i.area.getBounds().getCenterX(), i.area.getBounds().getCenterY()));
		}

//		Pen pm = new Pen(new RGB(0.8, 0, 0.8, 0.2), 0);
//		for (BasicQuery i : merged) {
//			QuadQuery x = new QuadQuery( i.area ) ;
//			canvas.sFill(pm, x.area);
//		}

	}

	
	static XY newPos() {
		double minNodeDistance = 10.0;
		int tries = 0;
		Searching: for (;;) {
			if (++tries % 99 == 0) {
				// System.err.println("Euclidean network plane too crowded...")
				// ;
				// System.err.println("Reducing minimum allowed node distance by 15%")
				// ;
				minNodeDistance *= 0.85;
			}
			XY pos = new XY(rg.nextDouble(), rg.nextDouble()).scale(1000);
			if (minNodeDistance > 0)
				for (CatadupaNode i : GlobalDB.liveNodes()) {
					AbstractSensingNode j = (AbstractSensingNode) i;
					if (j.filter != null && pos.distance(j.pos) < minNodeDistance)
						continue Searching;
				}

			return pos;
		}
	}
}


class LogicalClock {
	final double DELTA = 0.001 ;
	double logicalTime = Math.ceil(physicalTime()) ;

	double physicalTime() {
		return Simulation.currentTime() ;
	}

	double logicalTime() {
		return logicalTime ;
	}
	
	double increment() {
		return Math.max( Math.ceil(physicalTime()), logicalTime + DELTA ) ;
	}
	
	double max( double timestamp ) {
		return logicalTime = Math.max( timestamp, logicalTime ) + DELTA ;
	}
	
	public String toString() {
		return String.format("[%.6f / %.6f ]", logicalTime(), physicalTime() ) ;
	}
}