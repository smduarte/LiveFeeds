package livefeeds.sensing.msgs;

import simsim.sockets.Socket;
import simsim.sockets.SocketHandler;

public interface SensingSocketHandler extends SocketHandler {

	void onReceive( Socket sock, QuadCast m) ;	

	void onReceive( Socket sock, QuadCastPayload m) ;	

}
