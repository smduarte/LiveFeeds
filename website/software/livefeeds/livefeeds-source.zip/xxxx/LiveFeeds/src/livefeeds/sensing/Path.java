package livefeeds.sensing;

import java.util.List;

import livefeeds.twister6.TurmoilNode;

public class Path {
	
	double timestamp ;
	List<TurmoilNode> path ;
	
	public Path( double timestamp, List<TurmoilNode> path ) {
		this.path = path;
		this.timestamp = timestamp ;
	}
	
}
