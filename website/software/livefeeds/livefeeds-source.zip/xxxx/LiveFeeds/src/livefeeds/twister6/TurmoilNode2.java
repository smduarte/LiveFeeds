package livefeeds.twister6;

import static livefeeds.twister6.config.Config.Config;
import static simsim.core.Simulation.currentTime;
import static simsim.logging.Log.Log;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import livefeeds.twister6.msgs.TurmoilAccept;
import livefeeds.twister6.msgs.TurmoilCast;
import livefeeds.twister6.msgs.TurmoilPayload;
import livefeeds.twister6.msgs.TurmoilReject;
import livefeeds.twister6.msgs.TurmoilSocketHandler;

import simsim.core.PeriodicTask;
import simsim.sockets.Socket;
import simsim.sockets.SocketFactory;

public class TurmoilNode extends CatadupaNode implements TurmoilSocketHandler {

	int id_counter = 0;

	static int XXX = -1;

	Filter filter;

	static double inbound_events = 0, outbound_events = 0;

	static EventTargetLog eventLog = new EventTargetLog();
	static int event_counter = 0;

	protected final SocketFactory socket;

	protected TurmoilNode() {
		super();
		filter = new Filter();
		socket = new SocketFactory(address.endpoint(3, this), this, this);
	}

	public void init() {
		super.init();

		initQueueDispatchTask();
	}

	public static void injectEvents() {
		new PeriodicTask(1000, 1) {
			public void run() {
				TurmoilNode p = (TurmoilNode) GlobalDB.nodes.randomElement();
				if (p != null)
					p.publish();
			}
		};
	}

	public boolean notify( Event e ) {
		Thread.dumpStack() ;
		return true ;
	}
	
	public boolean notify( Event e, List<?> path ) {
		System.out.println( e.getClass() );
		Thread.dumpStack() ;
		return true ;
	}
	// @Override
	// public void onSendFailure( EndPoint src, Message m ) {
	// if( ! (m instanceof TurmoilMessage ) ) {
	// super.onSendFailure(src, m) ;
	// return ;
	// }
	// System.err.println("Failure:::" + src.handler + "-->" + m ) ;
	// }

	public void shutdown() {
		super.shutdown();

		System.out.println(key + " exiting...");
		System.out.printf("o/i : %f\n", outbound_events / inbound_events);
		System.out.printf("offView/inView : %f\n", offView_events / inView_events);
		eventLog.dispose(key);
	}

	public void publish() {
		publish( new Event() ) ;
	}

	public void publish( Event ev ) {

		ev.resetStamp() ;
		
			
		TreeSet<Integer> targets = new TreeSet<Integer>() ;
		for (CatadupaNode i : GlobalDB.liveNodes())
			if (i.accepts(ev))
				targets.add( i.index ) ;
		
		if( index == XXX )
			System.err.println(this + "    Targets: " + ev.serial + "---" + ev + "----->" + targets );
		
		for (CatadupaNode i : GlobalDB.liveNodes())
			if (i.isOnline() && i.accepts(ev))
				eventLog.addTarget(ev.serial, i.key);
		
		Log.finest("Publisher:" + key + "/" + ev.serial);
//		eventLog.dump();

//		System.out.flush();
		Log.finest(String.format("Targets: %f / %.2f \n", ev.value, eventLog.targets(ev.serial).size() / (double) GlobalDB.size()));

//		System.err.println(ev.serial);
//		System.err.flush();

		for (Range s : new Range().sliceKeys(1)) {
			new PendingTreeDispatch(new TurmoilCast(0, id_counter++, s, state.db.view, ev).append(this));
		}
	}
	
	public void onReceive(Socket sock, TurmoilCast m) {

		assert this.accepts(m.payload);

		boolean inView = state.db.view.contains(m.view);

		// if( pkt.payload.serial == XXX ) {
		// if( ! inView ) {
		// System.out.printf("Own View:%s \n", state.db.view ) ;
		// System.out.printf("Evt View:%s \n", pkt.view ) ;
		// System.out.printf("Faltam:%s \n", state.db.view.missing( pkt.view ))
		// ;
		// }
		// }
		if (state.db.loadedFilters && inView)
			socket.send(sock.src, new TurmoilAccept(m.id, m.payload.serial), 0);
		else {
			socket.send(sock.src, new TurmoilReject(m.id, m.payload.serial), 0);
			onReceive(sock, new TurmoilPayload(m.payload));
			return;
		}

		if( ! m.payload.notify( this, m.path )  )
			return ;

		Range r = m.range;

		Collection<CatadupaNode> P = r.nodeList(state.db, m.payload);
		r = r.advancePast(this.key);

		Collection<CatadupaNode> L = r.nodeList(state.db, m.payload);
		assert !L.contains(this);

		P.removeAll(L);

		for (CatadupaNode i : P) {
			if (i != this)
				outbound_events++;
			socket.send(i.endpoint, new TurmoilPayload(m.payload).append(m.path, this), 0);
		}

		if (L.size() <= Config.PUBSUB_MAX_FANOUT) {
			for (CatadupaNode i : L) {
				outbound_events++;
				socket.send(i.endpoint, new TurmoilPayload(m.payload).append(m.path, this), 0);
			}
		} else {
			for (Range s : r.sliceKeys(Config.PUBSUB_MAX_FANOUT)) {
				new PendingTreeDispatch(new TurmoilCast(m.level + 1, id_counter++, s, m.view, m.payload).append(m.path, this)).dispatch();
			}
		}
	}

	
	public void onReceive(Socket sock, TurmoilPayload m) {

		inbound_events++;

		if (m.payload.serial == XXX) {
			Log.finest("@" + key + eventLog.remaining(m.payload.serial));
		}
		boolean duplicate = !eventLog.newVisit(m.payload.serial, key) && sock.src.address != endpoint.address;

		if (duplicate)
			Log.severe("\nDuplicate Delivery..." + m.payload.serial + "/" + key + "\n");
		
		//System.err.println("TurmoilPayload:" + m.payload.elapsed() );
//		
//		if( m.payload.serial ==  1979 ) {
//			gotters.add( index ) ;
//			System.out.println( "$$$$$$$" + gotters + "/" + m.payload.elapsed() );
//			
//		}
//		
//		if( index == 40 )
//			System.out.println("XXXXXXXXX 40::::" + m.path );
//		
		m.payload.notify( this, m.path ) ;
	}

	private void initQueueDispatchTask() {
		new PeriodicTask(this, 1) {
			public void run() {
				for (PendingTreeDispatch i : new ArrayList<PendingTreeDispatch>(treeDispatchQueue.values())) {
					i.process();
				}
			}
		};
	}


	public void onReceive(Socket sock, TurmoilAccept m) {
		inView_events++;
		treeDispatchQueue.remove(m.id);
	}

	public void onReceive(Socket sock, TurmoilReject m) {
		offView_events++;

		PendingTreeDispatch x = treeDispatchQueue.get(m.id);
		if (x != null) {
			x.advanceRange();
			x.dispatch();
		}
	}

	static double inView_events = 0, offView_events = 0;
	Map<Integer, PendingTreeDispatch> treeDispatchQueue = new HashMap<Integer, PendingTreeDispatch>();

	class PendingTreeDispatch {

		final TurmoilCast m;
		double sndStamp = -1;
		double ageStamp = currentTime();

		PendingTreeDispatch(TurmoilCast m) {
			this.m = m;
			treeDispatchQueue.put(m.id, this);
		}

		double age() {
			return currentTime() - ageStamp;
		}

		void advanceRange() {
			for (CatadupaNode i : m.range.nodes(state.db))
				if (i.accepts(m.payload)) {
					m.range = m.range.advancePast(i.key);
					ageStamp = currentTime();
					return;
				}
			// System.err.printf("Exhausted Range....%d\n", pkt.payload.serial)
			// ;
			treeDispatchQueue.remove(m.id);
		}

		void dispatch() {
			for (CatadupaNode i : m.range.nodes(state.db))
				if (i.accepts(m.payload)) {
					socket.send(i.endpoint, m, 0);
					sndStamp = currentTime();
					outbound_events++;
					break;
				}
		}

		void process() {
			if (age() > 120)
				advanceRange();

			if (currentTime() - sndStamp > 20) {
				dispatch();
			}
		}

		public int hashCode() {
			return m.id;
		}

		public boolean equals(Object other) {
			return this.getClass() == other.getClass() && this.equals((PendingTreeDispatch) other);
		}

		public boolean equals(PendingTreeDispatch other) {
			return this.m.id == other.m.id;
		}

		public String toString() {
			return m.id + ": " + m.payload.serial;
		}
	}
}

class EventTargetLog {
	Map<Integer, Set<Long>> targets = new TreeMap<Integer, Set<Long>>();
	Map<Integer, Set<Visit>> visits = new TreeMap<Integer, Set<Visit>>();

	EventTargetLog() {
		new PeriodicTask(30) {
			public void run() {
				gc();
				// dump() ;
			}
		};
	}

	void gc() {
		double now = currentTime();
		for (int i : new TreeSet<Integer>(targets.keySet())) {
			Set<Long> tI = targets.get(i);
			Set<Visit> vI = visits.get(i);

			if (vI == null || vI.size() < tI.size())
				continue;

			double n = 0;
			for (Visit j : vI)
				n = Math.max(n, j.when);

			if (now - n > 120) {
				targets.remove(i);
				visits.remove(i);
			}
		}
	}

	Set<Long> targets(int serial) {
		Set<Long> res = targets.get(serial);
		return res != null ? res : new TreeSet<Long>();
	}

	Set<Long> visits(int serial) {
		TreeSet<Long> res = new TreeSet<Long>();
		if (visits.size() > 0) {
			for (Visit i : visits.get(serial))
				res.add(i.key);
		}
		return res;
	}

	Set<Long> remaining(int serial) {
		Set<Long> res = new TreeSet<Long>(targets(serial));
		res.removeAll(visits(serial));
		return res;
	}

	void dispose(long k) {
		for (int i : new TreeSet<Integer>(targets.keySet())) {
			Set<Long> tI = targets.get(i);
			Set<Visit> vI = visits.get(i);
			tI.remove(k);
			if (vI != null)
				vI.remove(new Visit(k));
		}
	}
	
	void dump() {
		for (int i : new TreeSet<Integer>(targets.keySet())) {
			Set<Long> tI = targets.get(i);
			Set<Visit> vI = visits.get(i);
			// if( i == Process.XXX )
			// System.out.printf("%s (%s : %s) ", i, tI, vI == null ? "-" : vI )
			// ;
			// else
			System.out.printf("%s (%s : %s) ", i, tI.size(), vI == null ? "-" : vI.size());
		}
		System.out.println();
	}

	void addTarget(int s, long k) {
		Set<Long> x = targets.get(s);
		if (x == null) {
			x = new TreeSet<Long>();
			targets.put(s, x);
		}
		x.add(k);
	}

	boolean newVisit(int s, long k) {
		Set<Visit> x = visits.get(s);
		if (x == null) {
			x = new TreeSet<Visit>();
			visits.put(s, x);
		}
		Visit y = new Visit(k);
		if (!x.contains(y)) {
			x.add(new Visit(k));
			return true;
		} else
			return false;
	}

	boolean isDuplicate(int s, long k) {
		Set<Visit> x = visits.get(s);
		if (x == null) {
			x = new TreeSet<Visit>();
			visits.put(s, x);
		}
		return x.contains(new Visit(k));
	}

	class Visit implements Comparable<Visit> {
		Long key;
		double when;

		Visit(long key) {
			this.key = key;
			when = currentTime();
		}

		public int hashCode() {
			return key.hashCode();
		}

		public boolean equals(Object other) {
			return key.equals(other);
		}

		public int compareTo(Visit other) {
			return key.compareTo(other.key);
		}

		public String toString() {
			return key.toString();
		}
	}
}