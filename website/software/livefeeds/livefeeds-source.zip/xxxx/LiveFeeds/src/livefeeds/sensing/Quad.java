package livefeeds.sensing;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import livefeeds.twister6.CatadupaNode;
import livefeeds.twister6.DB;
import livefeeds.twister6.Event;
import livefeeds.twister6.Range;

import simsim.gui.geom.Square;
import simsim.gui.geom.XY;

public class Quad extends Region {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	Quad() {	
		this(500,500,1000) ;
	}
	
	Quad( double x, double y, double w ) {
		super( new Square(x, y, w)) ;
		level = 1 ;
	}
	
	Quad( double x, double y, double w, int l ) {
		super( new Square(x, y, w)) ;
		level = l ;
	}
	
	public Quad clone() {
		return new Quad( shape.center().x, shape.center().y, shape.getWidth(), level ) ;
	}
	
	List<Quad> divide( int level, Event q) {
		List<Quad> res = new ArrayList<Quad>() ;
		
		XY p = shape.center() ;
		double w = shape.getWidth() * 0.25 ;
		res.add( new Quad( p.x - w, p.y - w, 2*w ) ) ;
		res.add( new Quad( p.x + w, p.y - w, 2*w ) ) ;
		res.add( new Quad( p.x - w, p.y + w, 2*w ) ) ;
		res.add( new Quad( p.x + w, p.y + w, 2*w ) ) ;
				
		for( Iterator<Quad> i = res.iterator() ; i.hasNext() ; )
			if( ! i.next().accepts(q) )
				i.remove() ;

		return res ;
	}
	
	List<Quad> divide() {
		List<Quad> res = new ArrayList<Quad>() ;
		
		XY p = shape.center() ;
		double w = shape.getWidth() * 0.25 ;
		res.add( new Quad( p.x - w, p.y - w, 2*w, level+1 ) ) ;
		res.add( new Quad( p.x + w, p.y - w, 2*w, level+1 ) ) ;
		res.add( new Quad( p.x - w, p.y + w, 2*w, level+1 ) ) ;
		res.add( new Quad( p.x + w, p.y + w, 2*w, level+1 ) ) ;
		
		return res ;
	}
	
	public String toString() {
		return shape.center() + ":" + shape.getWidth() ;
	}	
	
	int nodeCount( DB db ) {
		if( nodeCount < 0 ) {
			nodeCount = 0 ;
			for( CatadupaNode i : new Range().nodeList(db) ) {
				RTreeSensingNode j = (RTreeSensingNode)i ;
				if( shape.contains( j.pos.point2D()) )
					nodeCount++ ;
			}
		}
		return nodeCount ;
	}
	
	int nodeCount = -1 ;
	int level ;
}
