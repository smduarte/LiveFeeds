package simsim.gui;

import java.awt.*;
import simsim.core.*;
import simsim.utils.*;

@SuppressWarnings("serial")
public class NoGUI extends GuiDesktop {

	public void init() {		
	}
	
	public void redraw() {	
	}
	
	public void addDisplayable(String frame, Displayable d, double fps) {
	}

	public XY getMouseXY() {
		return new XY(0,0);
	}

	public XY getMouseXY_Scaled(Graphics2D gs) {
		return new XY(0,0);
	}

	public void maximizeFrame(String frame) {
	}

	public void setFrameRectangle(String frame, int x, int y, int w, int h) {
	}

	public void setFrameTransform(String frame, double virtualWidth, double virtualHeight, double offset, boolean keepRatios) {
	}

}
