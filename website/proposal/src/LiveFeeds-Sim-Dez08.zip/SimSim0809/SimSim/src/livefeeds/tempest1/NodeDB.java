package livefeeds.tempest1;

import java.util.*;

import simsim.utils.*;
import static livefeeds.tempest1.Main.*;

public class NodeDB {

	static TreeMap<Long, Node> k2n = new TreeMap<Long, Node>();

	public static void store( Node n, long k) {
		n.key = k ;
		k2n.put(n.key, n) ;
	}
	
	public static long store(Node n) {

		if (k2n.size() >= (MAX_KEY_VALUE + 1))
			throw new RuntimeException("NODE_KEY_LENGTH too small...");
		for (;;) {
			long key = (long) (rg.nextDouble() * (MAX_KEY_VALUE + 1L));
			 //long key = (k2n.size() + 1) * (MAX_KEY_VALUE+1L) / Main.TOTAL_NODES -1L;
			if (!k2n.containsKey(key)) {
				k2n.put(key, n);
				return key;
			}
		}
	}

	public static Collection<Node> all() {
		return k2n.values();
	}

	public static Node randomNode() {
		return new RandomList<Node>( k2n.values()).randomElement();
	}

	public static Collection<Node> nodes(long L, long H) {
		try {
			return k2n.subMap(L, H + 1).values();
		} catch (Exception x) {
			System.out.println(L + "/" + H);
			throw new RuntimeException(x.getMessage());
		}
	}

}