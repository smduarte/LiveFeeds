package livefeeds.tempest1.stats;

import java.awt.*;

import simsim.ext.charts.*;
import static simsim.core.Simulation.*;

import livefeeds.tempest1.*;
import static livefeeds.tempest1.Main.*;

public class TrafficStats extends XYLineChart {

	public TrafficStats(String frame, double fps) {
		super(frame, fps, "xAxis", "yAxis");
		
		super.setSeriesLinesAndShapes( "UpStream", true, false) ;
		super.setSeriesLinesAndShapes( "DownStream", true, false) ;
		super.setYRange(false, 0, 100);

	}

	double minRange = 0;
	double maxRange = 1;
	boolean rangesInited = false;

	public void display(Graphics2D gu, Graphics2D gs) {
		try {
			super.getSeries("UpStream").clear();
			super.getSeries("DownStream").clear();

			double min = Double.MAX_VALUE;
			double max = Double.MIN_VALUE;

			for (Node i : NodeDB.all()) {
				if (i.isOffline())
					continue;

				double time = currentTime();
				double key = i.key / (double) (1L << NODE_KEY_LENGTH);

				double v1 = i.address.uploadedBytes / time;
				double v2 = i.address.downloadedBytes / time;

				super.getSeries("UpStream").add( key, v1);
				super.getSeries("DownStream").add(key, v2);

				min = Math.min(min, Math.min(v1, v2));
				max = Math.max(max, Math.max(v1, v2));
			}
			minRange = rangesInited ? (0.9 * minRange + 0.1 * min) : min;
			maxRange = rangesInited ? (0.9 * maxRange + 0.1 * max) : max;
			rangesInited = true;

			super.setYRange(false, 0.9 * minRange, 1.1 * maxRange);
			super.display(gu, gs);

		} catch (Exception x) {
		}
	}
}
