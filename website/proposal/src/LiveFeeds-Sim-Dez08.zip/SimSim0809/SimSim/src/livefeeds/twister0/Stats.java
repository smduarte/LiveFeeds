package livefeeds.twister0;

import java.awt.*;
import simsim.core.*;
import simsim.ext.charts.*;
import static simsim.core.Simulation.*;

import umontreal.iro.lecuyer.stat.*;

public class Stats {
	static XYDeviationLineChart traffic ;

	private static int SAMPLE_DURATION = 300 ;	
	private static int NetworkUsage_SAMPLES = (int)(Main.MAX_SESSION_DURATION / SAMPLE_DURATION) + 1;
	
	static public Tally avgJoinDelay = new Tally("avgJoinDelay");
	static public Tally g_avgPayloadSize = new Tally("g_avgPayloadSize");

	static public Tally[] g_avgUploadUsage = new Tally[NetworkUsage_SAMPLES] ;
	static public Tally[] g_avgDownloadUsage = new Tally[NetworkUsage_SAMPLES] ;

	
	static void recordSession( Node node ) {
		double sessionDuration = node.upTime() ;
		int tally = (int) (sessionDuration / SAMPLE_DURATION) ;
		g_avgUploadUsage[ tally ].add( node.address.uploadedBytes / sessionDuration ) ; 
		g_avgDownloadUsage[ tally ].add( node.address.downloadedBytes / sessionDuration ) ; 
	}
	
	static void init() {
		for( int i = 0 ; i < g_avgUploadUsage.length ; i++ )
			g_avgUploadUsage[i] = new Tally("g_avgUploadUsage" + i ) ;
		
		for( int i = 0 ; i < g_avgDownloadUsage.length ; i++ )
			g_avgDownloadUsage[i] = new Tally("g_avgDownloadUsage" + i ) ;
		
		
		// Create a chart to monitor the infection progress rate
		traffic = new XYDeviationLineChart("Traffic Mean by Session Duration", 0.0, "bytes/s", "time(h)") ;
		
		Gui.addDisplayable("Traffic Stats", new Displayable() {
			public void display( Graphics2D gu, Graphics2D gs) {				
				traffic.getSeries("upload").clear() ;
				traffic.getSeries("download").clear() ;
				traffic.getSeries("#samples").clear() ;
				for( int i = 0 ; i < g_avgUploadUsage.length ; i++ ) {
					double x = i * SAMPLE_DURATION / 3600.0 ;
					Tally t = g_avgUploadUsage[i] ;
					if( t.numberObs() > 2 ) {
						traffic.getSeries("upload").add( x, t.average(), t.min(), t.max() ) ;
					}
				}
				
				for( int i = 0 ; i < g_avgDownloadUsage.length ; i++ ) {
					double x = i * SAMPLE_DURATION / 3600.0 ;
					Tally t = g_avgDownloadUsage[i] ;
					if( t.numberObs() > 2 ) {
						traffic.getSeries("download").add(  x, t.average(), t.min(), t.max() ) ;
					}
				}
//				for( int i = 0 ; i < g_avgDownloadUsage.length ; i++ ) {
//					double x = i * SAMPLE_DURATION / 3600.0 ;
//					Tally t = g_avgDownloadUsage[i] ;
//					if( t.numberObs() > 2 ) {
//						traffic.getSeries("#samples").add(  x, t.numberObs(), t.numberObs(), t.numberObs() ) ;
//					}
//				}
				traffic.display( gu, gs) ;
			}
		}, 0.1) ;
		Gui.setFrameRectangle("Traffic Stats", 0, 0, 480, 480) ;
		Gui.setFrameTransform("Traffic Stats", 500, 500, 0, false) ;
			
	}
}
