package livefeeds.twister0.msgs;

import java.awt.* ;

import simsim.core.*;
import livefeeds.twister0.*;

@SuppressWarnings("serial")
public class MembershipInfoReply extends AppMessage {
	
	public View oView;
	public View gView ;
	public SlidingIntSet knownNodes ;
		
	
	public MembershipInfoReply(  View ov, View gv, SlidingIntSet kn ) {
		super(true, Color.blue) ;
		this.oView = new View( ov ) ;
		this.gView = new View( gv ) ;
		this.knownNodes = new SlidingIntSet( kn ) ;
	}
	
	public int length() {
		return 0 * 1024 * Main.AVERAGE_NUMBER_OF_NODES;
	}
	
	public String toString() {
		return String.format("MembershipInfo") ;
	}
	
	public void deliverTo( TcpChannel ch, MessageHandler handler ) {
		((AppMessageHandler)handler).onReceive( ch, this ) ;
	}
	
	public void deliverTo( EndPoint src, MessageHandler handler ) {
		((AppMessageHandler)handler).onReceive( src, this ) ;
	}
}
