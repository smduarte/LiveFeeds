package livefeeds.twister0.msgs;

import java.util.* ;

import simsim.core.*;

import livefeeds.twister0.*;

@SuppressWarnings("serial")
public class MembershipRepairReply extends Message {
	
	public View gView ;
	public List<NewArrivals> data ;
	
	public MembershipRepairReply( List<NewArrivals> data, View gView ) {
		this.data = data ;
		this.gView = new View( gView) ;
	}
	
	public int length() {
		return 0 * (256 + data.size() * 512) ;
	}
	
	public String toString() {
		return String.format("MembershipRepair") ;
	}
	
	public void deliverTo( EndPoint src, MessageHandler handler ) {
		((AppMessageHandler)handler).onReceive( src, this ) ;
	}

	public void deliverTo( TcpChannel ch, MessageHandler handler ) {
		((AppMessageHandler)handler).onReceive( ch, this ) ;
	}
}
