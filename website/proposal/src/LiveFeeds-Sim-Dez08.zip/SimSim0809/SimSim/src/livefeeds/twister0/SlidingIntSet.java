package livefeeds.twister0;

public class SlidingIntSet {
	int base ;
	long[] bits ;
	
	public SlidingIntSet() {
		this(2) ;
	}

	public SlidingIntSet( int initialSize ) {
		this.base = 0 ;
		this.bits = new long[ initialSize ] ;
	}

	public SlidingIntSet( SlidingIntSet other ) {
		this.base = other.base ;
		this.bits = new long[ other.bits.length ] ;
		System.arraycopy( other.bits, 0, bits, 0, bits.length) ;
	}
	
	protected SlidingIntSet( int base, long[] bits ) {
		this.base = base ;
		this.bits = bits ;
		while( bits[0] == ALL_ONES )
			slide() ;
	}
	
	int length() {
		return base + bits.length << 6 ;
	}
	
	int window() {
		return bits.length << 6 ;
	}
	
	SlidingIntSet set( int b ) {
		try {		
			int i = b - base ;
			if( i >= 0 ) {
				bits[ i >> 6 ] |= masks[ i & 63 ] ;		
				while( bits[0] == ALL_ONES ) 
					slide() ;
			}
		} catch( Exception x ) {
			grow() ;
			set( b ) ;
		}
		return this ;
	}
	
	boolean get( int b ) {
		int j, i = b - base ;
		return i < 0 || ( (j = (i >> 6)) < bits.length && (bits[j] & masks[i & 63]) != 0) ;	
	}
	
	public boolean equals( SlidingIntSet other ) {
		int b = Math.min( this.base, other.base ) ;
		int B = Math.max( this.base + (this.bits.length << 6), other.base + (other.bits.length << 6)) ;
		int l = (B - b) >> 6 ;
		for( int i = b ; i < l ; i++ )
			if( this.word(i) != other.word(i) ) return false ;
		return true ;
	}
	
	private long word( int b ) {
		int i = b - base ;
		if( i < 0 ) return ALL_ONES ;
		else if( i >= bits.length << 6 ) return 0L ;
		else return bits[ i >> 6 ] ;
	}
	
	public SlidingIntSet union( SlidingIntSet other ) {
		int b = Math.max( this.base, other.base ) ;
		int B = Math.max( this.base + (this.bits.length << 6), other.base + (other.bits.length << 6)) ;
		int l = (B - b) >> 6 ;
		long[] new_bits = new long[l] ;
		for( int i = 0 ; i < l ; i++ ) {
			int bb = b + (i << 6) ;	
			new_bits[i] = this.word( bb) | other.word( bb) ; 
		}
		return new SlidingIntSet( b, new_bits ) ;
	}
	
	public String toString() {
		String res = "" ;
		for( int i = bits.length ; --i >= 0 ; ) {
			long v = bits[i] ;
			for( int j = 0 ; j < 64 ; j++ ) {
				res = (( v & 1) == 0 ? "0" : "1") + res ;
				v >>>= 1 ;
			}
		}
		return String.format("<%d : %s>", base, res ) ;
	}
	
	final private void slide() {
		base += 64 ;
		for( int j = 0 ; j < bits.length - 1 ; j++ )
			bits[j] = bits[j+1] ;				
		bits[ bits.length - 1 ] = 0L ;
	} 
	
	final private void grow() {
		long[] new_bits = new long[ 2 * bits.length ] ;
		for( int i = bits.length ; --i >= 0 ; )
			new_bits[i] = bits[i] ;
		bits = new_bits ;
	}
	
	private static long[] masks = new long[64];
	private static final long ALL_ONES = 0xFFFFFFFFFFFFFFFFL ;
	static {
		for( int i = 0 ; i < 64 ; i++ )
			masks[i] = 0x8000000000000000L >>> i ;
	}
}
