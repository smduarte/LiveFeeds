package livefeeds.tempest1.msgs;

import java.awt.*;
import java.awt.geom.*;

import simsim.core.*;
import simsim.gui.geom.*;
import livefeeds.tempest1.*;

@SuppressWarnings("serial")
public class BroadcastMessage extends Message {
	
	public int level ;
	public Range range ;
	public Object payload ;
	
	public BroadcastMessage( int level, Range range, Object payload ) {
		super(true, Color.green);
		this.level = level ;
		this.range = range ;
		this.payload = payload ;
	}
	
	public int length() {
		return 512 ;
	}
	
	public String toString() {
		return String.format("BroadcastMessage<%d, %s>", level, range) ;
	}
	
	public void display( Graphics2D gu, Graphics2D gs, EndPoint src, EndPoint dst,  double due, double t) {
    	livefeeds.tempest1.Node a = (livefeeds.tempest1.Node) src.handler ;
    	livefeeds.tempest1.Node b = (livefeeds.tempest1.Node) dst.handler ;
   	
    	double x1 = a.shape.x1 ; double y1 = a.shape.y1 ;
    	double x2 = b.shape.x1 ; double y2 = b.shape.y1 ;

    	double x = (x1 + x2) * 0.5 ;
    	double y = (y1 + y2) * 0.5 ;
    	
    	float w = 1.0f / (1 + level ) ;
    	
    	gs.setStroke( new BasicStroke( 7*w ) ) ;
    	
    	double cx = x + (500 - x) * w ;
    	double cy = y + (500 - y) * w ;
    	
    	QuadCurve ab = new QuadCurve( x1, y1, cx, cy, x2, y2) ;
    	gs.setColor(  Color.green ) ;
    	gs.draw( ab ) ;

	}
	
	public void display2( Graphics2D gu, Graphics2D gs, EndPoint src, EndPoint dst,  double due, double t) {
		
    	gs.setColor(  Color.green ) ;
    	gs.setStroke( new BasicStroke( 5.0f ) ) ;

    	double M = (1L << Main.NODE_KEY_LENGTH) ;
    	double D = 30 * level ;
    	Rectangle2D.Double r = new Rectangle2D.Double(50 + D, 50 + D, 900 - 2*D, 900 - 2*D) ;
    	
    	for( Range i : range.subRanges() ) {
    		double l = 360.0 * i.L() / M ;
    		double h = 360.0 * i.H() / M ;
    		gs.draw( new Arc2D.Double( r, l, h - l, Arc2D.OPEN )) ;
    	}
	}
	
	public void deliverTo( EndPoint src, MessageHandler handler ) {
		((AppMessageHandler)handler).onReceive( src, this ) ;
	}
}
