package livefeeds.twister0;

import java.awt.*;
import java.util.*;
import java.awt.image.*;

import simsim.core.*;

import umontreal.iro.lecuyer.rng.*;
import umontreal.iro.lecuyer.util.*;
import umontreal.iro.lecuyer.randvar.*;
import umontreal.iro.lecuyer.probdist.*;

public class Main extends Simulation implements Displayable {

	public static final double SL_BROADCAST_PERIOD = 30.0;
	public static final double JOIN_ATTEMPT_PERIOD = 45.0;

	public static final int NUMBER_OF_SLICES = 4;
	public static final int NODE_KEY_LENGTH = 32;
	public static final int BRAODCAST_MAX_FANOUT = 4;

	public static final int AVERAGE_NUMBER_OF_NODES = 1000;
	public static final double MAX_SESSION_DURATION = 24 * 3600;
	public static final double MEAN_SESSION_DURATION = 3 * 3600;

	private double shape = 1.8;
	private double lambda = MEAN_SESSION_DURATION / Gamma.func(1 + 1 / shape);
	private double arrivalRate = AVERAGE_NUMBER_OF_NODES / MEAN_SESSION_DURATION;

	final RandomVariateGen aGen = new RandomVariateGen(new MRG32k3a(), new ExponentialDist(arrivalRate));
	final RandomVariateGen sGen = new RandomVariateGen(new MRG32k3a(), new TruncatedDist(new WeibullDist(shape, 1 / lambda, 0), 0, MAX_SESSION_DURATION));

	Main() {
		super(5, EnumSet.of(DisplayFlags.TIME, DisplayFlags.THREADS, DisplayFlags.SIMULATION));
	}

	double T0 = System.currentTimeMillis();

	public Main init() {

		Stats.init();

		Gui.addDisplayable("Network", Network, 0.01);
		Gui.setFrameRectangle("Network", 0, 504, 216, 216);
		Gui.setFrameTransform("Network", 1000, 1000, 0.01, true);
		Gui.setFrameRectangle("MainFrame", 484, 0, 480, 480);

		Gui.addDisplayable("ViewMatrix", new ViewBitmapDisplay(), 1);
		Gui.setFrameRectangle("ViewMatrix", 220, 504, 216, 216);
		Gui.setFrameTransform("ViewMatrix", 1000, 1000, 0.01, true);

		System.out.println("Problemas na comunicação TCP...no simulador...");

		new Task(aGen.nextDouble()) {
			public void run() {

				new Node().init(sGen.nextDouble());

				reSchedule(aGen.nextDouble());

			}
		};

		new PeriodicTask(900.0) {
			public void run() {
				ArrivalsDB.gc();
			}
		};

		super.setSimulationMaxTimeWarp(1e10);

		return this;
	}

	public void display(Graphics2D gu, Graphics2D gs) {
		gs.setColor(Color.black);
		gs.setStroke(new BasicStroke(1f));

		gu.drawString("Live Nodes:" + NodeDB.size(), 2, 48);
		for (Map.Entry<Long, Node> i : NodeDB.k2n.entrySet()) {
			Node n = i.getValue();
			if (n.isOnline())
				n.display(gu, gs);
		}
	}

	public static void main(String[] args) throws Exception {
		Globals.set("Sim_RandomSeed", 1L);
		Globals.set("Net_RandomSeed", 1L);

		Globals.set("Net_Type", "Orbis");

		Globals.set("Net_Orbis_FPS", 0.1);
		Globals.set("Net_Orbis_LocalLoopClasses", 10);
		Globals.set("Net_Orbis_LocalLoopClassesDelayFactor", 0.01);
		Globals.set("Net_Orbis_Filename", "src/simsim/net/orbis/topos/500");

		Globals.set("Net_UdpHeaderLength", 28.0);
		Globals.set("Net_TcpHeaderLength", 40.0);

		// Globals.set("Net_UdpHeaderLength", 0.0 );
		// Globals.set("Net_TcpHeaderLength", 0.0 );

		new Main().init().start();
	}
}

class Gamma {
	static double func(double x) {
		return Math.exp(Num.lnGamma(x));
	}
}

class ViewBitmapDisplay implements Displayable {

	BufferedImage img = null;

	public void display(Graphics2D gu, Graphics2D gs) {
		doOwnViewBitMap(gu, gs);
		gu.drawImage(img, 0, 0, 2 * img.getWidth(), img.getHeight(), null);
	}

	private void doOwnViewBitMap(Graphics2D gu, Graphics2D gs) {
		if (img == null) {
			int N = 1024;
			img = gu.getDeviceConfiguration().createCompatibleImage(64, N, Transparency.OPAQUE);
		}
		Graphics2D G = (Graphics2D) img.getGraphics();

		G.setComposite(AlphaComposite.Src);
		G.setColor(new Color(0.0f, 0.0f, 0.0f, 0.0f));
		G.fillRect(0, 0, img.getWidth(), img.getHeight());

		int top = Integer.MIN_VALUE;
		int base = Integer.MAX_VALUE;

		TreeSet<Node> n = new TreeSet<Node>(NodeDB.nodes());
		for (Node i : n)
			if (i.isOnline() && i.joined) {
				base = Math.min(base, i.oView.base);
				top = Math.max(top, i.gView.top());
			}

		int Y = 0;
		for (Node i : n)
			if (i.isOnline() && Y < img.getHeight() && i.joined) {
				int X = img.getWidth() - 1;
				for (int j = top; j-- > top - img.getWidth();) {
					int r = i.gView.contains(j) ? 0 : 255;
					;
					int g = i.oView.contains(j) ? 255 : 0;
					int b = 0;
					int a = 128;
					img.setRGB(X--, Y, a << 24 | r << 16 | g << 8 | b);
				}
				Y++;
			}
	}
}
