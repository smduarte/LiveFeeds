package livefeeds.twister0.msgs;

import java.util.* ;

import java.awt.* ;
import java.awt.geom.*;

import simsim.core.*;
import static simsim.core.Simulation.*;

import livefeeds.twister0.*;

@SuppressWarnings("serial")
public class NewArrivals extends AppMessage {
	
	public View view ;
	public Stamp stamp ;
	public int[] mailbox ;
	public Set<Integer> payload ;
	public double timeStamp = currentTime() ;
	
	public NewArrivals( Stamp s, View v, Set<Integer> p ) {
		super(false, Color.orange ) ;
		this.stamp = s ;
		this.payload = p ;
		this.view = new View(v) ;
		this.mailbox = new int[1] ;
	}
	
	public NewArrivals( NewArrivals other, View v ) {
		super(false, Color.orange ) ;
		this.view = new View( v) ;
		this.stamp = other.stamp ;
		this.payload = other.payload;
		this.mailbox = other.mailbox;
	}
	
	public int length() {
		return 512 + payload.size() * 512 ;
	}
	
	public String toString() {
		return String.format("BroadcastPayload<%s>", payload ) ;
	}
	
	public void deliverTo( EndPoint src, MessageHandler handler ) {
		((AppMessageHandler)handler).onReceive( src, this ) ;
	}

	public void deliverTo( TcpChannel ch, MessageHandler handler ) {
		((AppMessageHandler)handler).onReceive( ch, this ) ;
	}
	
	public void display( EndPoint src, EndPoint dst, Graphics2D g2d ) {
		Node a = (Node) src.handler ;
		Node b = (Node) dst.handler ;
    	
		double x1 = a.pos.x ; double y1 = a.pos.y ;
    	double x2 = b.pos.x ; double y2 = b.pos.y ;

    	double x = (x1 + x2) * 0.5 ;
    	double y = (y1 + y2) * 0.5 ;
    	
    	float w = 1.0f / (1 + 12 ) ;
    	
    	double cx = x + (500 - x) * w ;
    	double cy = y + (500 - y) * w ;
    	
    	QuadCurve2D.Double ab = new QuadCurve2D.Double( x1, y1, cx, cy, x2, y2) ;
    	g2d.setStroke( new BasicStroke( 7*w ) ) ;
    	g2d.setColor( color ) ;
    	g2d.draw( ab ) ;
	}
}
