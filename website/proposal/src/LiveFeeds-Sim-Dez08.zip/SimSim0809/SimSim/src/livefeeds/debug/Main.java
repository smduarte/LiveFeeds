package livefeeds.debug;

import java.awt.*;
import java.util.*;
import java.awt.geom.*;

import simsim.core.*;
import simsim.utils.*;
import simsim.ext.charts.*;

public class Main extends Simulation implements Displayable {

	public static final int NODE_KEY_LENGTH = 32;
	public static final long MAX_KEY_VALUE = (1L << NODE_KEY_LENGTH) - 1 ;

	public static final int BROADCAST_MAX_FANOUT = 3;

	public static final int TOTAL_NODES = 1024;

	Main() {
		super(0.1, EnumSet.of(DisplayFlags.TIME, DisplayFlags.SIMULATION ));
	}

	int counter = 0;

	ArrayList<Node> delivered = new ArrayList<Node>() ;

	public Main init() {
		
		new XYLineChart("Tree Stats", 1.0, "", "") {
			public void display(Graphics2D gu, Graphics2D gs) {
					super.getSeries("data") ;

					float N = 0, T = 0;
					for (Node i : NodeDB.all()) {
						T += i.innerNode;
						N++;
					}
					T /= N;

					for (Node i : NodeDB.all()) {

						double key = (double) i.key / (1L << NODE_KEY_LENGTH);
						super.getSeries("data").add(key, i.innerNode / (double)(i.innerNode + i.leafNode));
					}
					super.display(gu, gs) ;
			}
		} ;

		Gui.setFrameRectangle("Tree Stats", 0, 0, 480, 480);
		Gui.setFrameRectangle("MainFrame", 484, 0, 480, 480);
		
		for (int i = 0; i < TOTAL_NODES; i++)
			new Node() ;

		System.out.println("NODES READY:" + NodeDB.all().size() ) ;
		
		new PeriodicTask(1.0) {
			public void run() {
				counter++ ;
				//System.out.println("Begin Broadcast-----------------------------------------------------------------------------") ;
				broadcast( 0, NodeDB.randomNode(), new Range(), counter);				
								
				HashSet<Node> missed = new HashSet<Node>() ;			
				//System.out.println("End Broadcast-------------------------------------------------------------------------------") ;				
				for( Node i : NodeDB.all())
					if( i.mailbox != counter )
						missed.add(i) ;				
				System.out.println("missed:" + missed ) ;				
				
				System.out.println( counter) ;
			}
		};

		return this;
	}

	
	
	public void broadcast( int L, Node node, Range r, int val) {
		//System.out.println( tab(L) + node.key + " : " + r );

		r = r.remove(node.key);

		//System.out.println( tab(L) + node.key + " > " + r );
		Collection<Node> N = r.nodes();
		if ( N.size() <= BROADCAST_MAX_FANOUT) {
			//System.out.println( node.key + " LEAF -----------> " + r );
			for (Node n : N)
				deliver(n, val, true);

			deliver(node, val, N.isEmpty() );				
			return;
		}

		//System.out.println( tab(L) + node.key + " SLICED ----------->" + r.slice(BROADCAST_MAX_FANOUT) );
	
		boolean isLeafNode = true ;
		String X = "" ;
		for (Range s : L < 1 ? r.slice3( node.key, BROADCAST_MAX_FANOUT ) : r.slice4( BROADCAST_MAX_FANOUT) ) {
			RandomList<Node> cs = s.nodes() ;
			X += cs.size() + "  " ;
			Node target = cs.isEmpty() ? null : cs.randomElement();
			if( target != null ) {
				broadcast( L+1, target, s, val);
				isLeafNode = false ;
			}
		}
		System.out.println( tab(L) + X) ;
		deliver(node, val, isLeafNode);
	}

	public void display(Graphics2D gu, Graphics2D gs) {
		gs.setColor(Color.black);
		gs.setStroke(new BasicStroke(1.0f));
		for( Node i :NodeDB.all() ) {
			XY p  = pos(i.key) ;
			gs.fill( new Ellipse2D.Double( p.x-1, p.y-1, 2, 2) ) ;
		}
	}
	
	
	
	public void deliver(Node n, int val, boolean leafNode) {
		if (leafNode)
			n.leafNode++;
		else
			n.innerNode++ ;
		
		n.mailbox = val ;
//		delivered.add(n) ;
		//System.out.println( (n.innerNode + n.leafNode) + "/" + counter ) ;
	}

	public static void main(String[] args) throws Exception {
		new Main().init().start();
	}

	private String tab(int l) {
		final String res = "                                                                                                                                                                 " ;
		return l + ")" + res.substring(0, l*2) ;
	}
	
	private XY pos( long key ) {
		double R = 500;
		double a = key * 2 * Math.PI / Main.MAX_KEY_VALUE ;
		return new XY(500 + R * Math.sin(a), 500 + R * Math.cos(a));
	}

}
