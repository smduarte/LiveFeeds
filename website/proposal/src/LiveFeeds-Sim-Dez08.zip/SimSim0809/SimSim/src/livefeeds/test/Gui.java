package livefeeds.test;



import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import simsim.core.*;

@SuppressWarnings("serial")
public class Gui extends javax.swing.JFrame {

	private Panel panel;

	
	public Gui() {
		super();
		initGUI();
		setVisible(true) ;
	}

	public void addDisplayable( Displayable d ) {
		panel.items.add( d ) ;
	}
	
	public void removeDisplayable( Displayable d ) {
		panel.items.remove( d ) ;
	}
	
	private void initGUI() {
		try {
			{
				this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
				this.setFocusable(false);
			}
			{
				getContentPane().setBackground(new java.awt.Color(255,255,255));
				this.addWindowListener(new WindowAdapter() {
					public void windowClosed(WindowEvent evt) {
						System.out.println("this.windowClosed, event=" + evt);
					}
				});
			}
			{
				panel = new Panel();
				getContentPane().add(panel, BorderLayout.CENTER);
				panel.setBackground(new java.awt.Color(255,255,255));
				panel.addMouseListener(new MouseAdapter() {
					public void mouseExited(MouseEvent evt) {
						panel.setMousePosition( Integer.MIN_VALUE, Integer.MIN_VALUE ) ;
						panel.repaint() ;
					}
				});
				panel.addMouseMotionListener(new MouseMotionAdapter() {
					public void mouseDragged(MouseEvent evt) {	
						panel.setMousePosition( evt.getX(), evt.getY() ) ;
						panel.repaint() ;
					}

					public void mouseMoved(MouseEvent evt) {
						panel.setMousePosition( evt.getX(), evt.getY() ) ;
						panel.repaint();
					}
				});
			}
			this.setSize(800, 600);
			
			new Thread() {
				public void start(){
					super.setDaemon(true) ;
					super.start();
				}
				public void run() {
					for(;;)
					try {
						repaint() ;
						Thread.sleep(100) ;
					} catch( InterruptedException e) { e.printStackTrace(); }
				}
			}.start();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args ) {
		new Gui() ;		
	}
}
