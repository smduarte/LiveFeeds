package livefeeds.twister0.msgs;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Stroke;
import java.awt.geom.QuadCurve2D;

import simsim.core.*;
import livefeeds.twister0.*;

@SuppressWarnings("serial")
public class MembershipRepairRequest extends Message {
	
	public View oView ;
	public View gView ;
	
	public MembershipRepairRequest( View ov, View gv) {
		super(false, Color.green ) ;
		this.oView = new View( ov ) ;
		this.gView = new View( gv ) ;
	}
	
	public int length() {
		return 0 ;
	}
	
	public String toString() {
		return String.format("MembershipRepair") ;
	}
	
	public void deliverTo( EndPoint src, MessageHandler handler ) {
		((AppMessageHandler)handler).onReceive( src, this ) ;
	}

	public void deliverTo( TcpChannel ch, MessageHandler handler ) {
		((AppMessageHandler)handler).onReceive( ch, this ) ;
	}
	
	public void display( EndPoint src, EndPoint dst, Graphics2D g2d ) {
		final Stroke stroke = new BasicStroke( 5f ) ;

		Node a = (Node) src.handler ;
		Node b = (Node) dst.handler ;
    	
		double x1 = a.pos.x ; double y1 = a.pos.y ;
    	double x2 = b.pos.x ; double y2 = b.pos.y ;

    	double x = (x1 + x2) * 0.5 ;
    	double y = (y1 + y2) * 0.5 ;
    	    	
    	double cx = x + (500 - x) * 0.5 ;
    	double cy = y + (500 - y) * 0.5 ;
    	
    	QuadCurve2D.Double ab = new QuadCurve2D.Double( x1, y1, cx, cy, x2, y2) ;
    	g2d.setStroke( stroke ) ;
    	g2d.setColor( color ) ;
    	g2d.draw( ab ) ;
	}
}
