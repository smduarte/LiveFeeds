package livefeeds.twister0;

import java.util.* ;


import static simsim.core.Simulation.*;
import livefeeds.twister0.msgs.*;

public class ArrivalsDB {

	static TreeMap<Integer, NewArrivals> arrivals = new TreeMap<Integer, NewArrivals>() ;
	

	static void store( NewArrivals v ) {
		arrivals.put( v.stamp.g_serial, v ) ;
	}
	
	static NewArrivals get( Stamp s ) {
		return arrivals.get( s.g_serial ) ;
	}
	
	static void updateMailboxes( Node n ) {
		for( NewArrivals i : arrivals.values() )
			if( n.oView.contains( i.stamp.g_serial ) )
				i.mailbox[0]++ ;
	}
	
	static void gc() {
		
		double now = currentTime() ;
		double expired = now - 1.1 * Main.MAX_SESSION_DURATION ;
		while( ! arrivals.isEmpty() ) {
			int firstKey = arrivals.firstKey() ;
			NewArrivals val = arrivals.get( firstKey ) ;
			
			if( val.timeStamp < expired ) {
				arrivals.remove( firstKey ) ;
				for( long i : val.payload )
					NodeDB.free(i) ;
				
				System.out.println( "g_stamp: " + firstKey + " expired" ) ;
			}
			else break ;
		}
		if( arrivals.isEmpty() ) return ;  
		
		for( int i = arrivals.firstKey() ; i < arrivals.lastKey() ; i++ ) {
			NewArrivals y = arrivals.get(i) ;
			if( y.mailbox[0] > 16 || now - y.timeStamp < 60 ) continue ;
			HashSet<Integer> M = new HashSet<Integer>( y.payload ) ;
			for( int j = i + 1 ; j < arrivals.lastKey() ; j++ ) {
				M.removeAll( y.payload ) ;
				if( M.isEmpty() ) {
					System.out.println("All lost keys accounted for...#" + y.stamp.g_serial ) ;
					for( Node n : NodeDB.nodes() )
						if( n.isOnline() ) {
							n.oView.add( y.stamp ) ;
							n.gView.add( y.stamp ) ;
						}
					return ;
				}
			}
			System.out.println("Not all lost keys accounted for...#" + y.stamp.g_serial) ;			
		}
	}
	
	static ArrayList<NewArrivals> get( Set<Integer> s) {
		ArrayList<NewArrivals> res = new ArrayList<NewArrivals>() ;
		for( Integer i : s )
			res.add( arrivals.get(i) ) ;
		return res ;
	}
	
	static ArrayList<Stamp> toStamps( Set<Integer> s ) {
		ArrayList<Stamp> res = new ArrayList<Stamp>() ;
		for( Integer i : s ) {
			NewArrivals x = arrivals.get(i) ;
			if( x == null )
				System.out.println( i + "Not available...") ;
			else 
				res.add( arrivals.get(i).stamp ) ;

		}
		return res ;		
	}
}
