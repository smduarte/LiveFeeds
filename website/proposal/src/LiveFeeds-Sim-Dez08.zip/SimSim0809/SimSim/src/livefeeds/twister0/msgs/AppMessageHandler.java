package livefeeds.twister0.msgs;

import simsim.core.*;

public interface AppMessageHandler extends MessageHandler {

	public void onReceive( EndPoint src, JoinRequest m) ;

	public void onReceive( TcpChannel ch, MembershipInfoRequest m) ;
	
	public void onReceive( EndPoint src, BroadcastMessage m ) ;
	
	public void onReceive( EndPoint src, NewArrivals m) ;	
		
	public void onReceive( TcpChannel ch, MembershipRepairRequest m) ;	
}
