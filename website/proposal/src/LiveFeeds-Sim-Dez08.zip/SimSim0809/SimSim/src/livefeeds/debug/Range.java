package livefeeds.debug;

import java.util.*;

import static simsim.core.Simulation.*;
import static livefeeds.debug.Main.*;

import simsim.utils.*;

@SuppressWarnings("serial")
public class Range extends Interval {

	public Range() {
		super(0, (1L << NODE_KEY_LENGTH) - 1 );
	}

	Range(long l, long h) {
		super(l, h);
		assert l >= 0 && h < ((1L << NODE_KEY_LENGTH)) ;
	}

	Range(Interval i) {
		super(i);
	}

	public int size() {
		return intervals.size();
	}


	public long randomValue() {
		long res = length() ;
		
		res = (long)(rg.nextDouble() * (1L << NODE_KEY_LENGTH)) % res ;
		for (SimpleInterval i : intervals) {
			long l = i.length();
			res = res - l ;
			if(res < 0) {
				res = res + l + i.L ;
				break;
			}
		}
		assert this.contains(res);
		return res;
	}

	public boolean isSafe( Range cover) {
		return cover.contains(this);
	}

	public List<Range> slice( int slices) {
		ArrayList<Range> res = new ArrayList<Range>();

		long sliceWidth = ( H() - L() ) / slices ;		
		
		long b = L() ;
		for( int i = 0 ; i < slices - 1; i++ ) {
			res.add( new Range(b, b + sliceWidth).intersection(this)) ;
			b += sliceWidth + 1;
		}
		res.add( new Range(b, H()).intersection(this) ) ;
		return res;
	}
	
	public RandomList<Node> nodes() {
		RandomList<Node> res = new RandomList<Node>() ;
		for( SimpleInterval i : intervals )
			res.addAll( NodeDB.nodes( i.L, i.H) ) ;
		return res ;
	}
	
	public Node randomNode() {
		return nodes().randomElement() ;
	}
	
	public String toString() {
		return super.toString() + "=" + length() + "{"+ nodes().size() + "}";
	}

	public Range union(Range other) {
		return new Range(super.union(other));
	}

	public Range difference(Range other) {
		return new Range(super.difference(other));
	}

	public Range intersection(Range other) {
		return new Range(super.intersection(other));
	}

	public Range remove(long K) {
		return new Range(super.difference(new Interval(K, K)));
	}

	public Range subRange3(long O, long K) {		
		Interval x = K >= 0 ? new Interval(O, K) : new Interval(L(), K).union(new Interval(O, H()));
		return new Range(x.intersection(this));
	}	

	
	public List<Range> slice2( int slices) {
		ArrayList<Range> res = new ArrayList<Range>();

		long SW = length() / slices ;
		
		long B = this.randomValue() ;
		Interval remaining = new Interval(this) ;		
		
		for( int i = 0 ; i < slices-1; i++ ) {
			Interval ii = new Interval() ;
			while(ii.length() < SW ) {
				for( SimpleInterval j : remaining.intervals ) {
					if( j.contains( B ) ) {
						long BH = Math.min( j.H, B + (SW-ii.length()) -1L) ;
						
						Interval ij = new Interval( B, BH) ;
						remaining = remaining.difference(ij) ;

						ii = ii.union( ij) ;
						B = remaining.moveInside(BH + 1L) ;
						break ;
					}
				}
			}
			assert ii.length() > 0 ;
			res.add( new Range( ii) ) ;
		}
		res.add( new Range( remaining ) ) ;
		
		assert length() == listLength( res ) ;
		
		return res;
	}

	
	public List<Range> slice2( long B, int slices) {
		ArrayList<Range> res = new ArrayList<Range>();

		long SW = length() / slices ;

		B = super.moveInside(B) ;
		Interval remaining = new Interval(this) ;		
		
		for( int i = 0 ; i < slices-1; i++ ) {
			Interval ii = new Interval() ;
			while(ii.length() < SW ) {
				for( SimpleInterval j : remaining.intervals ) {
					if( j.contains( B ) ) {
						long BH = Math.min( j.H, B + (SW-ii.length()) -1L) ;
						
						Interval ij = new Interval( B, BH) ;
						remaining = remaining.difference(ij) ;

						ii = ii.union( ij) ;
						B = remaining.moveInside(BH + 1L) ;
						break ;
					}
				}
			}
			assert ii.length() > 0 ;
			res.add( new Range( ii) ) ;
		}
		res.add( new Range( remaining ) ) ;
		
		assert this.length() == listLength( res ) ;
		
		return res;
	}

	public List<Range> slice3( int slices) {
		ArrayList<Range> res = new ArrayList<Range>();

		long B = this.randomValue() ;

		Interval remaining = new Interval(this) ;		
		
		for( int i = slices ; --i >= 0 ; ) {
			Interval ii = new Interval() ;
			long SW = (long)( remaining.length() / (i+1.0) + rg.nextDouble() ) ;
			
			while(ii.length() < SW ) {
				for( SimpleInterval j : remaining.intervals ) {
					if( j.contains( B ) ) {
						long BH = Math.min( j.H, B + (SW-ii.length()) -1L) ;
						
						Interval ij = new Interval( B, BH) ;
						remaining = remaining.difference(ij) ;

						ii = ii.union( ij) ;
						if( ! remaining.isEmpty() )
							B = remaining.moveInside(BH + 1L) ;
						break ;
					}
				}
			}
			res.add( new Range( ii) ) ;
		}
		//res.add( new Range( remaining ) ) ;
		//System.out.println( res ) ;
		assert this.length() == listLength( res ) ;
		return res;
	}

	public List<Range> slice3( long b, int slices) {
		ArrayList<Range> res = new ArrayList<Range>();
		
		Interval remaining = new Interval(this) ;		
		long B = remaining.moveInside(b+1L) ;
		
		for( int i = slices ; --i >= 0 ; ) {
			Interval ii = new Interval() ;
			long SW = (long)( remaining.length() / (i+1.0) + rg.nextDouble() ) ;
			
			while(ii.length() < SW ) {
				for( SimpleInterval j : remaining.intervals ) {
					if( j.contains( B ) ) {
						long BH = Math.min( j.H, B + (SW-ii.length()) -1L) ;
						
						Interval ij = new Interval( B, BH) ;
						remaining = remaining.difference(ij) ;

						ii = ii.union( ij) ;
						if( ! remaining.isEmpty() )
							B = remaining.moveInside(BH + 1L) ;
						break ;
					}
				}
			}
			res.add( new Range( ii) ) ;
		}
		//res.add( new Range( remaining ) ) ;
		//System.out.println( res ) ;
		assert this.length() == listLength( res ) ;
		return res;
	}

	public List<Range> slice4(int slices) {
		ArrayList<Range> res = new ArrayList<Range>();

		List<Node> remaining = nodes();

		for( int i = slices ; --i >= 1 ; ) {
			//System.out.println( remaining ) ;
			long B = remaining.get(0).key ;			
			int SW = (int)( remaining.size() / (i+1.0) + rg.nextDouble() ) ;
			//System.out.println("SliceWidth:" + SW ) ;
			long BH = remaining.get(SW-1).key ;
			Range ri = new Range( new Interval(B, BH).intersection(this) ) ;
			//System.out.println("ii " + ii + "/" + ii.nodes() ) ;
			res.add( ri ) ;
			remaining = remaining.subList(SW, remaining.size()) ;
		}
		Range rr = new Range( new Interval( remaining.get(0).key, H() ).intersection(this) ) ;
		res.add(rr) ;
		return res;
	}
	
	private long listLength( List<Range> l ){
		long res = 0 ;
		for( Range i : l )
			res += i.length() ;
		
		return res ;
	}
}
