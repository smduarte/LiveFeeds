package livefeeds.twister0;

import java.util.*;

import simsim.utils.*;
import static simsim.core.Simulation.*;
import static livefeeds.twister0.Main.*;

public class NodeDB {

	static Node dummyNode ;
	static int g_index = -1 ;
	static HashSet<Long> deadNodes = new HashSet<Long>() ;
	static TreeMap<Long, Node> k2n = new TreeMap<Long, Node>() ;
	
	static {
		dummyNode = new Node() ;
		dummyNode.putOffline() ;
		k2n.remove( dummyNode.key) ;
		dummyNode.key = -1L ;
		dummyNode.index = 1 ;
	}
	
	static void store( Node newNode ) {
		if( k2n.size() >= (1L<<NODE_KEY_LENGTH)) throw new RuntimeException("NODE_KEY_LENGTH too small...") ;
		for(;;) {
			long key = new java.math.BigInteger( NODE_KEY_LENGTH, rg ).longValue() ;			
			assert key >= 0 ;
			if( ! k2n.containsKey(key) && ! deadNodes.contains(key)){
				newNode.key = key ;
				newNode.index = g_index++ ;
				k2n.put( newNode.key, newNode) ;
				break ;
			}
		}
	}

	static int size() {
		return k2n.size() - deadNodes.size();
	}
	
	static Node get( long key ) {
		return k2n.get(key) ;
	}
	
	static void dispose( Node n ) {
		k2n.put( n.key, dummyNode ) ;
		deadNodes.add(n.key ) ;
	}

	static void free( long key ) {
		k2n.remove( key ) ;
		deadNodes.remove( key ) ;
	}
		
	static Node randomSeedNode( Node caller ) {
		long randomKey = new java.math.BigInteger( NODE_KEY_LENGTH, rg ).longValue() ;
		Map<Long,Node> m0 = k2n.tailMap( randomKey ) ;
		for( Map.Entry<Long, Node> i : m0.entrySet() ) {
			Node candidate = i.getValue() ;
			if( candidate != caller && candidate.isOnline() && candidate.joined ) return candidate ;
		}
		Map<Long,Node> m1 = k2n.subMap(0L, randomKey) ;
		for( Map.Entry<Long, Node> i : m1.entrySet() ) {
			Node candidate = i.getValue() ;
			if( candidate != caller && candidate.isOnline() && candidate.joined ) return candidate ;
		}
		return null ;
	}
	
	static Node sliceLeader( Node caller ) {
		return sliceLeader(false, caller) ;
	}
	
	static Node closestNode( long key, Node caller ) {
		SlidingIntSet mask = caller.knownNodes ;
		Map<Long,Node> gt = k2n.tailMap(key) ;
		for( Map.Entry<Long, Node> i : gt.entrySet() ) {
			Node candidate = i.getValue() ;
			if( candidate == caller || candidate.isOffline() ) continue ;
			else if( mask.get( candidate.index ) ) return candidate ;
		}
		return caller ;
	}
	
	static Node randomNode( Node caller ) {
		long randomKey = new java.math.BigInteger( NODE_KEY_LENGTH, rg ).longValue() ;
		return closestNode( randomKey, caller ) ;
	}
	
	static Node sliceLeader( boolean excludeSelf, Node caller ) {
		SlidingIntSet mask = caller.knownNodes ;
		long S = (1L << NODE_KEY_LENGTH) / NUMBER_OF_SLICES ;
		long leaderKey = (caller.key / S) * S  ;
		
		Map<Long,Node> gt = k2n.tailMap(leaderKey) ;
		for( Map.Entry<Long, Node> i : gt.entrySet() ) {
			Node candidate = i.getValue() ;
			if( excludeSelf && candidate == caller || candidate.isOffline() ) continue ;
			else if( mask.get( candidate.index ) ) return candidate ;
		}
		return caller ;
	}
	
	public static RandomList<Node> nodes() {
		return new RandomList<Node>( k2n.values() ) ;
	}
		
	public static RandomList<Node> nodes( Node caller ) {
		SlidingIntSet mask = caller.knownNodes ;
		RandomList<Node> x = new RandomList<Node>() ;
		
		for( Node i : k2n.values() )
			if( mask.get( i.index ) ) 
				x.add(i) ;

		return x ;
	}
	
	public static Iterable<Node> nodes( long L, long H, Node caller) {
		try {
			return new MaskedCollectionIterator( k2n.subMap( L, H + 1 ).values().iterator(), caller.knownNodes ) ;
			
		} catch( Exception x ) {
			System.out.println( L + "/" + H ) ;
			throw new RuntimeException(x.getMessage()) ;
		}
	}

}

class MaskedCollectionIterator implements Iterator<Node>, Iterable<Node> {

	SlidingIntSet mask;
	Node next = null ;
	Iterator<Node> it ;
	
	MaskedCollectionIterator( Iterator<Node> it, SlidingIntSet mask ) {
		this.mask = mask ;
		this.it = it ;
	}

	public boolean hasNext() {
		while( it.hasNext() ) {
			next = it.next();
			if( mask.get( next.index ) ) return true ;
		}
		return false ;
	}


	public Node next() {
		assert mask.get( next.index ) == true ;
		return next ;
	}


	public void remove() {
		throw new RuntimeException("Not implemented...") ;
	}


	public Iterator<Node> iterator() {
		return this ;
	}
}