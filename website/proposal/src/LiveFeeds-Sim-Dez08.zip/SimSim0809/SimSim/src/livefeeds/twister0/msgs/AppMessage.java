package livefeeds.twister0.msgs;

import java.awt.*;

import simsim.core.*;
import simsim.utils.* ;
import simsim.gui.geom.*;

import livefeeds.twister0.*;

@SuppressWarnings("serial")
public class AppMessage extends Message {

	AppMessage() {
		this(false) ;
	}
	
	AppMessage( boolean visible ) {
		super( visible, Color.gray ) ;
	}
	
	AppMessage( boolean visible, Color color ) {
		super( visible, color ) ;
	}
		
	public void display( Graphics2D gu, Graphics2D gs, EndPoint src, EndPoint dst,  double t, double p) {
		Node a = (Node) src.handler ;
		Node b = (Node) dst.handler ;
    	
    	double x = (a.pos.x + b.pos.x) * 0.5 ;
    	double y = (a.pos.y + b.pos.y) * 0.5 ;
    	
    	XY c = new XY( x + (500 - x), y + (500-y)) ;
    	
    	gs.setColor(  color ) ;
    	gs.setStroke( new BasicStroke( 1.0f ) ) ;
    	gs.draw( new QuadCurve( a.pos, c, b.pos) ) ;
	}
}
