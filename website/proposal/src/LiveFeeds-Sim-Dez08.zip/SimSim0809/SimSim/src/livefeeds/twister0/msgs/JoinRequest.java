package livefeeds.twister0.msgs;

import java.awt.* ;

import simsim.core.*;

@SuppressWarnings("serial")
public class JoinRequest extends AppMessage {
	
	public int index ;
	
	public JoinRequest( int index ) {
		super(true, Color.magenta ) ;
		this.index = index ;
	}
	
	public int length() {
		return 0 ;
	}
	
	public String toString() {
		return String.format("Join <%d>", index ) ;
	}
	
	public void deliverTo( EndPoint src, MessageHandler handler ) {
		((AppMessageHandler)handler).onReceive( src, this ) ;
	}

	public void deliverTo( TcpChannel ch, MessageHandler handler ) {
		((AppMessageHandler)handler).onReceive( ch, this ) ;
	}
}