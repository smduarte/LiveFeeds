package livefeeds.tempest1;

import java.awt.*;
import java.util.* ;
import java.awt.geom.* ;


import simsim.core.*;

import livefeeds.tempest1.msgs.* ;
import static livefeeds.tempest1.Main.* ;

public class Node extends AbstractNode implements Comparable<Node>, AppMessageHandler {
	
	public Line2D.Double shape ;
	
	public long key ;
	
	public Node() {
		super() ;
		this.key = NodeDB.store( this ) ;

		double R = 450.0 ;
		double a = 2 * Math.PI * key / (1L << NODE_KEY_LENGTH) ;
		double x = 500 + R * Math.sin(a) ;
		double y = 500 + R * Math.cos(a) ;
		shape = new Line2D.Double(x, y, x+1, y ) ;
	}
	
	public void broadcast( Object o ) {
		udpSend( this.endpoint, new BroadcastMessage(0, new Range(), o)) ;
	}
	
	public String toString() {
		return "" + key ;
	}

	public int compareTo(Node other) {
		return key == other.key ? 0 : key < other.key ? -1 : 1 ;
	}

	public void start() {
		new PeriodicTask( 5.0 ){
			public void run() {
				broadcast("?") ;
			}
		} ;
	}
	
	public void onReceive(EndPoint src, BroadcastMessage msg) {
		
		Range r = msg.range ;
		
		//System.out.println( this + " got: " + r  + " : " + r.nodes() ) ;	

		this.onReceive( this.endpoint, new DeliverPayload( msg.payload ) ) ;
		
		r = r.remove( this.key ) ;
		//System.out.println( this + " changed: " + r  + " : " + r.nodes() ) ;	

		Collection<Node> N = r.nodes() ;	
		
		assert !N.contains(this) ;
		
		if( N.size() <= BRAODCAST_MAX_FANOUT) {
			for( Node n : N )
				udpSend( n.endpoint, new DeliverPayload( msg.payload ) ) ;
			
			return ;
		}

		for( Range s : r.slice4(BRAODCAST_MAX_FANOUT) ) {			
			Node target = s.randomNode() ;
			if( target != null ) {
				udpSend( target.endpoint, new BroadcastMessage( msg.level + 1, s, msg.payload ) ) ;
			}
		}
	}

	
	public void onReceive(EndPoint src, DeliverPayload m) {
	}
	
	
	public void display( Graphics2D gu, Graphics2D gs ) {
		gs.draw( shape ) ;
	}
	
}