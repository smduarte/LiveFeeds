package livefeeds.debug;

public class Node implements Comparable<Node> {
	
	public long key ;
	public int mailbox = -1 ;
	
	public Node() {
		super() ;
		this.key = NodeDB.store( this ) ;	
	}	
	
	public String toString() {
		return "" + key ;
	}

	public int compareTo(Node other) {
		return key == other.key ? 0 : key < other.key ? -1 : 1 ;
	}

	public int leafNode = 0 ;
	public int innerNode = 0 ;
}