package livefeeds.twister0;

public class Stamp implements Comparable<Stamp>{
	long key ;
	int serial ;
	int g_serial ;
	
	Stamp( long k, int s ) {
		this.key = k ; 
		this.serial = s ;
		this.g_serial = g_serial_counter++ ;
	}
	
	public int hashCode() {
		return g_serial ;
	}
	
	public long hashValue( int f ) {
		return key ^ (serial * f) ;
	}
	
	public long hashValue( long L, long H ) {
		return L + hashValue(0) % (H - L) ;
	}
	
	public boolean equals( Stamp other ) {
		return g_serial == other.g_serial ;
	}
	
	public boolean equals( Object other ) {
		return equals( (Stamp) other ) ;
	}

	public int compareTo( Stamp other ) {
		return g_serial - other.g_serial ;
	}
	
	public String toString() {
		return String.format("<%d, %d, %d>", key, serial, g_serial) ;
	}
	private static int g_serial_counter = 0 ;
}