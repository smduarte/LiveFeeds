package livefeeds.twister0;

import java.util.*;

public class View extends SlidingIntSet {

	int top ;
	
	public View() {
		super( 2 ) ;
	}
	
	public View( View other ) {
		super( other ) ;
	}
	
	void add( Stamp s ) {
		top = Math.max( top, s.g_serial ) ;
		super.set( s.g_serial ) ;
	}
	
	void merge( View other ) {	
		top = Math.max( top, other.top ) ;
		SlidingIntSet x = this.union( other ) ;
		base = x.base ;
		bits = x.bits ;
		assert this.contains(other) ;
	}

	int top() {
		return top ;
	}
	
	boolean contains( int other ) {
		return super.get( other ) ;
	}
	
	boolean contains( View other ) {
		return this.equals( this.union(other)) ;
	}
	
	boolean widerThan( View other ) {
		int b = Math.min( this.base, other.base ) ;
		int t = Math.max( this.top,  other.top ) ;
		for( int i = b ; i <= t ; i++ )
			if( !other.get(i) && get(i) ) return true ;

		return false ;
	}
	
	Set<Integer> difference( View other ) {
		int b = Math.min( this.base, other.base ) ;
		int t = Math.max( this.top,  other.top ) ;
		HashSet<Integer> res = new HashSet<Integer>() ;
		for( int i = b ; i <= t ; i++ )
			if( !other.get(i) && get(i) )
				res.add(i) ;
		
		return res ;
	}		
}
