package livefeeds.twister0;

import java.awt.*;
import java.util.*;

import umontreal.iro.lecuyer.stat.*;

import simsim.core.*;
import simsim.utils.*;
import simsim.gui.geom.*;
import static simsim.core.Simulation.*;

import livefeeds.twister0.msgs.*;
import static livefeeds.twister0.Main.*;

public class Node extends AbstractNode implements AppMessageHandler, Displayable, Comparable<Node> {
	public XY pos ;
	
	NodeStats stats ;
	NodeDisplay displayable ;
	
	int serial = 0;
	
	long key;
	boolean joined = false;

	View oView;
	View gView;
	Queue<OutputQueueMessage> outputQueue;

	int index;
	Task sliceLeaderTask ;
	SlidingIntSet knownNodes;
	
	int totalHoles = 0;
	public boolean hasBeenSliceLeader ;
	double sessionInit = currentTime() ;
	
	public Node() {
		super();
		NodeDB.store( this);
		
		
		stats = new NodeStats() ;
		displayable = new NodeDisplay( this ) ;
		
		joined = false;
		oView = new View();
		gView = new View();
		knownNodes = new SlidingIntSet();		
		outputQueue = new LinkedList<OutputQueueMessage>();
	}

	public double upTime() {
		return Math.min( Main.MAX_SESSION_DURATION, currentTime() - sessionInit) ;
	}
	
	
	public String toString() {
		return String.format("<%s, %s>", key, index);
	}

	public void shutdown() {
		dispose();
		NodeDB.dispose(this);
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	public void init(double sessionDuration) {
		initSessionManagementTask(sessionDuration);
		initSliceLeaderRoutineTask();
		initOutputQueueDispatcher();
 		initJoinOverlayTask();
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	public void initSessionManagementTask(double sessionDuration) {
		new Task(this, sessionDuration) {
			public void run() {
				Stats.recordSession( Node.this) ;
				shutdown();
			}
		};
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	void initOutputQueueDispatcher() {
		new PeriodicTask(this, 0.25) {
			public void run() {
				while (!outputQueue.isEmpty()) {
					OutputQueueMessage x = outputQueue.remove();
					udpSend(x.dst, x.msg);
				}
			}
		};
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	void initJoinOverlayTask() {
		Node seed = NodeDB.randomSeedNode(this);
		assert seed != this;
		if (seed != null) {
			TcpChannel ch = tcpSend( seed.endpoint, new MembershipInfoRequest());
			if (ch != null) {
				MembershipInfoReply m = ch.tcpRead();
				oView = m.oView;
				gView = m.gView;
				knownNodes = m.knownNodes;
				ArrivalsDB.updateMailboxes( this);
				assert gView.contains(oView);
			}

			new PeriodicTask(this, JOIN_ATTEMPT_PERIOD) {
				public void run() {
					if (!joined) {
						Node sl = NodeDB.sliceLeader(true, Node.this);
						udpSend(sl.endpoint, new JoinRequest(index));
					} else {
						cancel();
						initMembershipRepairTask();
					}
				}
			};

		} else {
			joined = true;
			onReceive(endpoint, new JoinRequest(index));
			initMembershipRepairTask();
		}
	}

	public void onReceive(TcpChannel ch, MembershipInfoRequest m) {
		ch.tcpReply( new MembershipInfoReply(oView, gView, knownNodes));
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	public void onReceive(EndPoint src, JoinRequest m) {
		arrivals.add( m.index);
		if( ! sliceLeaderTask.isScheduled() )
			sliceLeaderTask.reSchedule( SL_BROADCAST_PERIOD) ;
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	HashSet<Integer> arrivals = new HashSet<Integer>();

	void initSliceLeaderRoutineTask() {
		sliceLeaderTask = new Task(this, 0) {
			public void run() {
				if (!arrivals.isEmpty()) {
					hasBeenSliceLeader = true ;
					
					HashSet<Integer> payload = new HashSet<Integer>(arrivals);
					arrivals.clear();

					Stamp stamp = new Stamp(key, serial++);
					gView.add(stamp);
					NewArrivals bp = new NewArrivals(stamp, gView, payload);

					ArrivalsDB.store(bp);
					onReceive(endpoint, new BroadcastMessage(0, new Range(), bp));

					Stats.g_avgPayloadSize.add( bp.payload.size());
				}
			}
		};
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// Broadcast a membership aggregate event.
	public void onReceive(EndPoint src, BroadcastMessage m0) {
		if( m0.level > 1 && rg.nextDouble() < 0.1 ) return ; //Enforce broadcasting erros to test the membership repair mechanism.
		
		NewArrivals p0 = m0.payload;
		gView.merge(p0.view);

		NewArrivals p1 = new NewArrivals(p0, gView);

		assert gView.contains(oView);

		Range r0 = m0.range;
		r0 = r0.remove(this.key);

		this.onReceive( this.endpoint, p1);
		Collection<Node> N0 = r0.onlineNodes(this);

		if (N0.size() <= BRAODCAST_MAX_FANOUT) {
			for (Node i : N0)
				outputQueue.add(new OutputQueueMessage( i.endpoint, p1));
		} else {


			for (Range j : r0.slice4( m0.level == 0 ? 2 : BRAODCAST_MAX_FANOUT, this)) {

				RandomList<Node> candidates = j.nodes(this);
				Node target ;
				for(;;) {
					target = candidates.removeRandomElement();
					if( target == null )
						break ;
					
					if ( target.isOnline() ) {
						udpSend(target.endpoint, new BroadcastMessage(m0.level + 1, j, p1));
						break;
					}
				}
			}
		}
	}

	// Process a new membership aggregate event.
	// The node has joined when it is being announced in the payload.
	// Update the node membership database and the nodes membership views.
	public void onReceive(EndPoint src, NewArrivals p0) {
				
		if( ! joined && p0.payload.contains( this.index)) {
			joined = true ;
			Stats.avgJoinDelay.add( currentTime() - sessionInit ) ;
		}
		
		p0.mailbox[0]++;

		oView.add(p0.stamp);
		gView.merge(p0.view);
		for (int i : p0.payload)
			knownNodes.set(i);
		
		assert gView.contains(oView);
	}

	
	// Compares current private view with global view.
	// If there are any holes, contact a random node to fill in missing aggregate membership events.
	public void initMembershipRepairTask() {
		new PeriodicTask(this, 30.0 + 1 * rg.nextDouble()) {
			public void run() {
				//System.out.println( oView ) ;
				
				assert gView.contains(oView);
				Set<Integer> diff = gView.difference(oView);

				totalHoles = diff.size();
				if (totalHoles > 0) {
					Node other = NodeDB.randomNode( Node.this);
					TcpChannel ch = tcpSend(other.endpoint, new MembershipRepairRequest( oView, gView));
					if (ch != null) {
						MembershipRepairReply res = ch.tcpRead();
						if (res != null) {
							for (NewArrivals j : res.data) {
								onReceive(ch.src, j);
								stats.avgPayloadRecoveryDelay_S.add(currentTime() - j.timeStamp);
							}
						}
					}
				}
			}
		};
	}


	// Reply to a MembershipRepairRequest.
	public void onReceive(TcpChannel ch, MembershipRepairRequest m) {
		gView.merge(m.gView);
		ArrayList<NewArrivals> res = ArrivalsDB.get(oView.difference(m.oView));
		ch.tcpReply(res.isEmpty() ? null : new MembershipRepairReply(res, gView));
	}

	public int compareTo(Node other) {
		return key == other.key ? 0 : key < other.key ? -1 : 1;
	}
	
	

	public void display(Graphics2D gu, Graphics2D gs) {
		displayable.display(gu, gs) ;
	}
}

class NodeStats {
	Tally avgPayloadRecoveryDelay_S = new Tally("avgPayloadRecoveryDelay_S");
	Tally avgPayloadRecoveryDelay_R = new Tally("avgPayloadRecoveryDelay_R");
}

class OutputQueueMessage {
	Message msg;
	EndPoint dst;

	OutputQueueMessage(EndPoint dst, Message msg) {
		this.dst = dst;
		this.msg = msg;
	}
}

class NodeDisplay implements Displayable {
	private static final double RADIUS = 300.0;
	
	XY pos ;
	Node owner ;
	NodeStats stats ;
	
	NodeDisplay( Node owner ) {
		this.stats = owner.stats ;
		this.owner = owner ;
		owner.pos = pos() ;
	}
	
	private XY pos() {
		double R = RADIUS;
		double a = owner.key * 2 * Math.PI / (1L << NODE_KEY_LENGTH) - Math.PI;
		return pos = new XY(500 + R * Math.sin(a), 500 + R * Math.cos(a));
	}

	public void display(Graphics2D gu, Graphics2D gs) {

		gs.setColor(Color.black);
		gs.setStroke( new BasicStroke(3.0f));
		double t = -20 * owner.totalHoles / RADIUS;
		gs.draw(new Line(pos.x, pos.y, pos.x + t * (pos.x - 500), pos.y + t * (pos.y - 500)));

		double SF = 250.0 ;
		double runningTime = owner.currentTime() - owner.sessionInit ;
		gs.setStroke(new BasicStroke(2.0f));
		gs.setColor(Color.red);
		t = SF * owner.address.downloadedBytes / runningTime / RADIUS / 1024.0;		
		if( owner.hasBeenSliceLeader )
			gs.draw(new Line(pos.x, pos.y, pos.x + t * (pos.x - 500), pos.y + t * (pos.y - 500)));
		
		gs.setStroke(new BasicStroke(2.0f));
		gs.setColor(Color.blue);
		t = SF * owner.address.uploadedBytes / runningTime / RADIUS / 1024.0 ;
		if( owner.hasBeenSliceLeader )
			gs.draw(new Line(pos.x, pos.y, pos.x + t * (pos.x - 500), pos.y + t * (pos.y - 500)));

		
//		if (stats.avgPayloadRecoveryDelay_S.numberObs() > 2) {
//			gs.setStroke(new BasicStroke(2.0f));
//			gs.setColor(Color.red); 
//			t = stats.avgPayloadRecoveryDelay_S.max() / RADIUS;
//			if( owner.hasBeenSliceLeader ) t *= 10 ;
//			gs.draw(new Line(pos.x, pos.y, pos.x + t * (pos.x - 500), pos.y + t * (pos.y - 500)));
//		}
//		if ( stats.avgPayloadRecoveryDelay_R.numberObs() > 2) {
//			gs.setStroke(new BasicStroke(2.0f));
//			gs.setColor(Color.blue);
//			t = stats.avgPayloadRecoveryDelay_R.max() / RADIUS;
//			if( owner.hasBeenSliceLeader ) t *= 10 ;
//			gs.draw(new Line(pos.x, pos.y, pos.x + t * (pos.x - 500), pos.y + t * (pos.y - 500)));
//		}
	}
}