package livefeeds.debug;

import java.util.*;

import simsim.utils.*;
import static livefeeds.debug.Main.*;

public class NodeDB {
	
	static TreeMap<Long, Node> k2n = new TreeMap<Long,Node>() ;
	
	static long store( Node n ) {
		
		if( k2n.size() >= (MAX_KEY_VALUE+1) ) throw new RuntimeException("NODE_KEY_LENGTH too small...") ;
		for(;;) {
			long key = (long)(rg.nextDouble() * (MAX_KEY_VALUE + 1L)) ;
			//long key = (k2n.size() + 1) * (MAX_KEY_VALUE+1L) / Main.TOTAL_NODES -1L;
			if( ! k2n.containsKey(key) ){
				k2n.put( key, n) ;
				return key ;
			} 
		}
	}
	
	static void replace( int n ) {
		for(int i = 0 ; i < n ; i++ ) {
			k2n.remove( randomNode().key ) ;
		}

		for(int i = 0 ; i < n ; i++ ) 
			new Node() ;			
	}
	
	public static Collection<Node> all() {
		return k2n.values();
	}

	static Node randomNode() {
		return new RandomList<Node>( k2n.values() ).randomElement() ;
	}
	
	static Collection<Node> nodes( long L, long H) {
		try {
			return k2n.subMap( L, H + 1).values() ;
		} catch( Exception x ) {
			System.out.println( L + "/" + H ) ;
			throw new RuntimeException(x.getMessage()) ;
		}
	}

	}