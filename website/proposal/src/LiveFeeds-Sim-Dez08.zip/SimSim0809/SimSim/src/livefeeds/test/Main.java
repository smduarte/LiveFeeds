package livefeeds.test;


import simsim.core.*;

import java.awt.*;
import java.util.*;
import java.awt.geom.* ;

import umontreal.iro.lecuyer.rng.*;
import umontreal.iro.lecuyer.stat.*;
import umontreal.iro.lecuyer.util.Num;
import umontreal.iro.lecuyer.randvar.*;
import umontreal.iro.lecuyer.probdist.*;

public class Main implements Displayable {
	
	public static final double AVERAGE_NUMBER_OF_NODES = 500 ;
	public static final double MAX_SESSION_DURATION = 12 * 3600 ;
	public static final double MEAN_SESSION_DURATION = 6 * 3600 ;

	final double aRate = AVERAGE_NUMBER_OF_NODES / MEAN_SESSION_DURATION ;	

	double alpha = 1.8 ;
	

	RandomVariateGen aGen = null ;
	RandomVariateGen sGen = null ;
	
	final PriorityQueue<Event> queue = new PriorityQueue<Event>();
	
	final Queue<ArrivalEvent> fArrivalEvents = new LinkedList<ArrivalEvent>() ;
	final Queue<DepartureEvent> fDepartureEvents = new LinkedList<DepartureEvent>() ;
	final int[] sessionTimes = new int[ 1000 ] ;
	
	Tally arrivals = new Tally("Arrivals");
	Tally sessions = new Tally("Sessions");
	Tally size = new Tally("Size");
	
	double now = 0 ;
	
	void go() {
		double mean_session_duration = MEAN_SESSION_DURATION ;
		double lambda = mean_session_duration / Math.exp( Num.lnGamma( 1 + 1 / alpha ) ) ;		

		ContinuousDistribution arrivalsDist = new ExponentialDist(aRate) ;
		ContinuousDistribution sessionsDist0 = new WeibullDist( alpha, 1/lambda, 0 ) ;
		
		System.out.println( sessionsDist0.cdf( MAX_SESSION_DURATION )) ;
		
		ContinuousDistribution sessionsDist = new TruncatedDist( new WeibullDist( alpha, 1/lambda, 0 ), 0, MAX_SESSION_DURATION) ;
		
		System.out.println( sessionsDist0.getMean() / sessionsDist.getMean() ) ;
		
		while( sessionsDist.getMean() < MEAN_SESSION_DURATION ) {
			mean_session_duration += 1 ;
			lambda = mean_session_duration / Math.exp( Num.lnGamma( 1 + 1 / alpha ) ) ;		
			sessionsDist = new TruncatedDist( new WeibullDist( alpha, 1/lambda, 0 ), 0, MAX_SESSION_DURATION) ;
		}
		System.out.println( mean_session_duration / MEAN_SESSION_DURATION ) ;
		System.out.println( sessionsDist.getMean() / 3600.0 ) ;
		
		aGen = new RandomVariateGen(new MRG32k3a(), arrivalsDist );
		sGen = new RandomVariateGen(new MRG32k3a(), sessionsDist );

		
		
		Gui gui = new Gui();
		gui.addDisplayable(this ) ;

//		for( double t = 0 ; t > -MAX_SESSION_DURATION ; ) {
//			t -= aGen.nextDouble() ;
//			double s = sGen.nextDouble() ;
//			
//			if( t + s > 0 ) {
//				queue.add( new DepartureEvent( 0 - (t+s)) ) ;				
//			}
//		}
		
		queue.add( new ArrivalEvent(0) ) ;
		do {
			Event x = queue.remove();
			now = x.due ;
			x.process() ;
			//System.err.printf("Time:%.1f -> Size:%d\n", now, queue.size() ) ;
			
			if( sessions.numberObs() % 100 == 99 )
				System.out.println( sessions.reportAndCIStudent(.95) );

			if( size.numberObs() % 100 == 99 )
				System.out.println( size.reportAndCIStudent(.95) );
//			
//			if( arrivals.numberObs() % 100 == 99 )
//				System.out.println( arrivals.reportAndCIStudent(.95) );
			
			x.dispose() ;
		} while( ! queue.isEmpty() ) ;
	}
	/**
	 * @param args
	 */
	public static void main( String[] args) {
		new Main().go();
	}

	class ArrivalEvent extends Event {
		
		ArrivalEvent( double due) {
			super(due);
		}

		void process() {
			size.add( queue.size() ) ;
			arrivals.add( now - timestamp ) ;
			
			double tdd = now + sGen.nextDouble() ;
			Event de = fDepartureEvents.isEmpty() ? new DepartureEvent( tdd) : fDepartureEvents.remove().renew( tdd) ;
			queue.add( de );
			
			double tad = now + aGen.nextDouble() ;
			Event ae = fArrivalEvents.isEmpty() ? new ArrivalEvent( tad) : fArrivalEvents.remove().renew( tad) ;
			queue.add( ae );
		}
		
		public String toString() {
			return String.format("A:%d: %.6f", id, due) ;
		}

		@Override
		void dispose() {
			fArrivalEvents.add( this ) ;
		}
		

	}

	class DepartureEvent extends Event {
		DepartureEvent( double due) {
			super(due);
		}
		
		public String toString() {
			return String.format("D:%d: %.6f", id, due) ;
		}
		
		@Override
		void dispose() {
			fDepartureEvents.add( this ) ;
		}

		@Override
		void process() {
			
			assert now >= timestamp ;
			
			sessions.add( (now - timestamp)/3600.0 ) ;
			int t = (int)( (now - timestamp) / (48 * 3.6) ) ;
			if( t >= 0 && t < sessionTimes.length) 
				sessionTimes[t]++ ;
		}
	}

	abstract class Event implements Comparable<Event> {

		int id;
		double due;
		double timestamp ;
		
		Event( double due) {
			this.due = due;
			this.id = ids++;
			this.timestamp = now ;
		}

		Event renew( double due) {
			this.due = due ;
			this.timestamp = now ;
			return this ;
		}
		
		abstract void process() ;
		
		abstract void dispose() ;
		
		
		public int hashCode() {
			return id;
		}

		public boolean equals( Object other) {
			return other != null && equals((Event) other);
		}

		private boolean equals( Event other) {
			return this == other && id == other.id;
		}

		public int compareTo( Event other) {
			return due == other.due ? id - other.id : due < other.due ? -1 : 1;
		}
	}

	private static int ids = 0;

	public void display( Graphics2D gu, Graphics2D gs) {
		gu.setColor( Color.black ) ;
		gu.drawString( String.format("%.1f Q:%d", now, queue.size() ), 20, 20) ;
		
//		gs.setColor( Color.magenta ) ;
//		
//		final int[] xxx = new int[ 1000 ] ;
//		for( Event i : queue ) {
//			int t = (int)( (i.due - now) / (48 * 3.6) ) ;
//			if( t >= 0 && t < xxx.length) 
//				xxx[t]++ ;
//		}
		
		double T = 0, M = Integer.MIN_VALUE ;
		for( int i : sessionTimes ) {
			T += i ;
			M = Math.max( M, i ) ;
		}
		
		gs.setColor( Color.black ) ;
		double s = 1000.0 / M ;
		double x0 = 0, y0 = 1000, x = 0, dx = 1000.0 / sessionTimes.length;
		gs.setColor( Color.YELLOW ) ;
		gs.setStroke( new BasicStroke(15.0f)) ;
		for( int i : sessionTimes ) {
			x += dx ;
			double y = 1000 - s * i ;
			gs.draw( new Line2D.Double(x0, y0, x, y) ) ;
			x0 = x ;
			y0 = y ;
		}
		double I = 0 ;
		s = 1000 / T ;
		x0 = 0; y0 = 1000; x = 0;
		gs.setColor( Color.blue ) ;
		for( int i : sessionTimes ) {
			x += dx ;
			double y = 1000 - s * I ;
			//gs.draw( new Line2D.Double(x0, y0, x, y) ) ;
			x0 = x ;
			y0 = y ;
			I += i ;
		}
	}
}

class Gamma {
	static double func(double x) {
		return Math.exp( Num.lnGamma(x)) ;
	}
}