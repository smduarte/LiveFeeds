package livefeeds.tempest1.msgs;

import simsim.core.*;

public interface AppMessageHandler extends MessageHandler {

	public void onReceive( EndPoint src, DeliverPayload m ) ;
	
	public void onReceive( EndPoint src, BroadcastMessage m ) ;
	
}
