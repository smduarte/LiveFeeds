package livefeeds.test;

import java.awt.* ;
import java.util.* ;
import java.awt.geom.* ;

import simsim.core.*;
import static simsim.core.Simulation.rg;

@SuppressWarnings("serial")
public class Panel extends javax.swing.JPanel {
	Collection<Displayable> items = new ArrayList<Displayable>() ;
	
    public static double f = 0.90 ;
    public static final double S = 1000.0 ;
    private static double w, h, l, tx, ty, s, _s ;
    
    private XY mouse = new XY(-1, -1);
    
//    private static final AffineTransform Identity = new AffineTransform().getScaleInstance(1,1) ;
    
    public void paintComponent( Graphics g ) {
        super.paintComponent( g ) ;
        
        Graphics2D gu = (Graphics2D) g ;
        gu.setRenderingHint( RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON ) ;
        
        Graphics2D gs = (Graphics2D)gu.create() ;
        
        XY p = mouse ;
        gu.setColor( Color.gray ) ;
        gu.setStroke( new BasicStroke( 1.0f ) ) ;
        gu.drawLine( p.X() - 4, p.Y() - 4, p.X() + 4, p.Y() + 4 ) ;
        gu.drawLine( p.X() - 4, p.Y() + 4, p.X() + 4, p.Y() - 4 ) ;
        
        
        w = getWidth() ;
        h = getHeight() ;
        l = Math.min( w, h ) * f ;
        
        tx = ( w - l ) / 2 ;
        ty = ( h - l ) / 2 ;
                
        s = l / S ;
        _s = S / l ;
        
        AffineTransform t = new AffineTransform() ;
        t.translate( tx, ty ) ;
        t.scale( s, s ) ;
        gs.setTransform( t ) ;
        
        gs.setColor( Color.lightGray ) ;
        gs.setStroke( new BasicStroke( 1f ) ) ;
        gs.draw( new Rectangle2D.Double( 0, 0, S, S ) ) ;
        
        for( Displayable i : new ArrayList<Displayable>(items) )
        	i.display( gu, gs ) ;
    }
    
    public void setMousePosition( int x, int y ) {
    	mouse = new XY( x, y ) ;
    }
    
    public XY mouse() {
        double x = mouse.x;
        double y = mouse.y;
        double xx = (x - tx) * _s ;
        double yy = (y - ty) * _s;
        return new XY(xx,yy) ;
    }   
}
class XY {
	double x, y ;

	XY() {
		x = rg.nextDouble() ; y = rg.nextDouble() ;
	}
	
	XY( double x, double y ) {
		this.x = x ; this.y = y ;
	}
	
	XY scale( double s ) {
		x *=s ; y *=s ;
		return this ;
	}
	
	int X() {
		return (int)x ;
	}
	
	int Y() {
		return (int)y ;
	}
	double distance( XY other ) {
		return x * x + y * y ;
	}
	
	public String toString() {
		return String.format("<%.3f, .%3f>", x, y) ;
	}
}
