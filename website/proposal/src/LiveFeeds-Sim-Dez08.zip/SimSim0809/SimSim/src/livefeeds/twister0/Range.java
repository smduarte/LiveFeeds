package livefeeds.twister0;

import java.util.*;
import java.math.*;

import simsim.utils.*;
import static simsim.core.Simulation.*;
import static livefeeds.twister0.Main.*;

@SuppressWarnings("serial")
public class Range extends Interval {

	public Range() {
		super(0, (1L << NODE_KEY_LENGTH) - 1 );
	}


	Range(long l, long h) {
		super(l, h);
		assert l >= 0 && h < ((1L << NODE_KEY_LENGTH)) ;
	}

	Range(Interval i) {
		super(i);
	}

	public int size() {
		return intervals.size();
	}

	public long length() {
		return super.length();
	}

	public long randomValue() {
		long res = rg.nextLong() % super.length();
		for (SimpleInterval i : intervals) {
			long l = i.length();
			res = res - l ;
			if(res < 0) {
				res = res + l + i.L ;
				break;
			}
		}
		assert this.contains(res);
		return res;
	}

	public boolean isSafe(Range cover) {
		return cover.contains(this);
	}


	public List<Range> slice(int slices, Node caller) {
		ArrayList<Range> res = new ArrayList<Range>();
		
		long sliceWidth = ( H() - L() ) / slices ;	
		
		long b = L() ;
		for( int i = 0 ; i < slices - 1; i++ ) {
			res.add( new Range(b, b + sliceWidth).intersection(this)) ;
			b += sliceWidth + 1;
		}
		res.add( new Range(b, H()).intersection(this) ) ;
		return res;
	}
	
	public List<Range> slice4(int slices, Node caller ) {
		ArrayList<Range> res = new ArrayList<Range>();

		List<Node> remaining = onlineNodes( caller );

		for( int i = slices ; --i >= 1 ; ) {
			//System.out.println( remaining ) ;
			long B = remaining.get(0).key ;			
			int SW = (int)( remaining.size() / (i+1.0) + rg.nextDouble() ) ;
			//System.out.println("SliceWidth:" + SW ) ;
			long BH = remaining.get(SW-1).key ;
			Range ri = new Range( new Interval(B, BH).intersection(this) ) ;
			//System.out.println("ii " + ii + "/" + ii.nodes() ) ;
			res.add( ri ) ;
			remaining = remaining.subList(SW, remaining.size()) ;
		}
		Range rr = new Range( new Interval( remaining.get(0).key, H() ).intersection(this) ) ;
		res.add(rr) ;
		return res;
	}
	
	public RandomList<Node> nodes( Node caller) {
		RandomList<Node> r = new RandomList<Node>();
		for (SimpleInterval i : intervals) {
			for( Node j : NodeDB.nodes(i.L, i.H, caller) )
				r.add( j ) ;
		}
		return r;
	}

	public RandomList<Node> onlineNodes( Node caller) {
		RandomList<Node> r = new RandomList<Node>();
		for (SimpleInterval i : intervals) {
			for( Node j : NodeDB.nodes(i.L, i.H, caller) )
				if( j.isOnline())
					r.add( j ) ;
		}
		return r;
	}

	public Node randomNode( Node caller ) {
		return nodes( caller ).randomElement() ;
	}

	public String toString() {
		return super.toString() + "=" + length();
	}

	public Range union(Range other) {
		return new Range(super.union(other));
	}

	public Range difference(Range other) {
		return new Range(super.difference(other));
	}

	public Range intersection(Range other) {
		return new Range(super.intersection(other));
	}

	public Range remove(long K) {
		return new Range(super.difference(new Interval(K, K)));
	}

	public Range subRange3(long O, long K) {		
		Interval x = K >= 0 ? new Interval(O, K) : new Interval(L(), K).union(new Interval(O, H()));
		return new Range(x.intersection(this));
	}

	public static Range cover( long k) {
		BigInteger K = BigInteger.valueOf(k) ;
		BigInteger M = BigInteger.ONE.shiftLeft(NODE_KEY_LENGTH);
		BigInteger D = new BigDecimal(M).multiply( BigDecimal.valueOf(1.0)).toBigInteger();

		BigInteger L = K.subtract( D.shiftRight(1));
		BigInteger H = L.add(D);

		if (L.signum() <= 0) {
			L = BigInteger.ZERO;
			H = L.add(D);
		}
		if (H.compareTo(M) > 0) {
			L = L.subtract(H.subtract(M));
			H = M;
		}
		return new Range(L.longValue(), H.longValue());
	}	
}

//public List<Range> slice2(int slices, Node caller) {
//ArrayList<Range> res = new ArrayList<Range>();
//
//Collection<Node> nodes = nodes( caller );
//
//double C = nodes.size() / (double) slices;
//
//// System.out.println( C ) ;
//// System.out.println( "SLICING: " + this + "/" + nodes + " = " +
//// nodes.size() ) ;
//
//// if( C < 1 ) return res ;
//
//double n = 0;
//
//long pKey = L();
//for (Iterator<Node> i = nodes.iterator(); i.hasNext();) {
//	long iKey = i.next().key;
//	if (++n >= C || !i.hasNext()) {
//		if (i.hasNext()) {
//			// System.out.println( pKey + ", " + iKey ) ;
//			res.add(new Range(pKey, iKey).intersection(this));
//			pKey = iKey + 1 ;
//			n -= C;
//		} else {
//			res.add(new Range(new Interval(pKey, H()).intersection(this)));
//		}
//	}
//}
//return res;
//}