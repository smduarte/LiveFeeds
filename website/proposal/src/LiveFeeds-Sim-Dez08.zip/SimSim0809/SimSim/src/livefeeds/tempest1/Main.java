package livefeeds.tempest1;

import java.awt.*;
import java.util.*;

import simsim.core.*;
import livefeeds.tempest1.stats.*;

public class Main extends Simulation implements Displayable {
	
	public static final int NODE_KEY_LENGTH = 32;
	public static final long MAX_KEY_VALUE = (1L << NODE_KEY_LENGTH) - 1 ;

	public static final int BRAODCAST_MAX_FANOUT = 3 ;
	
	public static final int TOTAL_NODES = 500 ;
		
	protected Main() {
		super( 10, EnumSet.of( DisplayFlags.SIMULATION, DisplayFlags.TIME, DisplayFlags.TRAFFIC ) ) ;
	}
	
	public Main init() {

		new TrafficStats("Traffic Stats", 5.0 ) ;
		Gui.setFrameRectangle("Traffic Stats", 0, 0, 480, 480) ;
		Gui.setFrameRectangle("MainFrame", 484, 0, 480, 480) ;
		
		for( int i = 0 ; i < TOTAL_NODES ; i++ )
			new Node().init() ;
		
		new PeriodicTask( 5.0 ){
			public void run() {
				NodeDB.randomNode().broadcast("?") ;
			}
		} ;
		
		return this ;
	}

	
	public void display(Graphics2D gu, Graphics2D gs) {
		gs.setColor( Color.black ) ;
        gs.setStroke( new BasicStroke( 1f ) ) ;
        
        for( Node i : NodeDB.all() ) 
			i.display( gu, gs) ;        
	}
	
	public static void main( String[] args ) throws Exception {

		Globals.set("Sim_RandomSeed", 1L);
		Globals.set("Net_RandomSeed", 1L);

		Globals.set("Net_Type", "Orbis");
		
		Globals.set("Net_Orbis_FPS", 0.1 );
		Globals.set("Net_Orbis_UseOpengGL", false);
		Globals.set("Net_Orbis_LocalLoopClasses", 9 ) ;
		Globals.set("Net_Orbis_CorePerHopLatency", 0.025) ;
		Globals.set("Net_Orbis_LocalLoopPerClassLatencyFactor", 0.01 ) ;
		Globals.set("Net_Orbis_Filename", "src/simsim/net/orbis/topos/500");

		Globals.set("Net_Euclidean_MinimumNodeDistance", -5.0);
		Globals.set("Net_Euclidean_DisplayNodeLabels", false);
		Globals.set("Net_Euclidean_NodeRadius", 10.0);
		Globals.set("Net_Euclidean_CostFactor", 0.0001);		
		
		Globals.set("Net_UdpHeaderLength", 28.0 );		
		Globals.set("Net_TcpHeaderLength", 40.0 );

		
		new Main().init().start() ;
	}

}
