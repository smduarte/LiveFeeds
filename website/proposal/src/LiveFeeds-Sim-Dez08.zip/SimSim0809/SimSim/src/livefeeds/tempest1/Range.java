package livefeeds.tempest1;

import java.util.*;

import static simsim.core.Simulation.*;
import static livefeeds.tempest1.Main.*;

import simsim.utils.*;

@SuppressWarnings("serial")
public class Range extends Interval {

	public Range() {
		super(0, (1L << NODE_KEY_LENGTH) - 1 );
	}

	protected Range(long l, long h) {
		super(l, h);
		assert l >= 0 && h < ((1L << NODE_KEY_LENGTH)) ;
	}

	protected Range(Interval i) {
		super(i);
	}
	
	public int size() {
		return intervals.size();
	}


	public long randomValue() {
		long res = length() ;
		
		res = (long)(rg.nextDouble() * (1L << NODE_KEY_LENGTH)) % res ;
		for (SimpleInterval i : intervals) {
			long l = i.length();
			res = res - l ;
			if(res < 0) {
				res = res + l + i.L ;
				break;
			}
		}
		assert this.contains(res);
		return res;
	}

	public boolean isSafe( Range cover) {
		return cover.contains(this);
	}
	
	public RandomList<Node> nodes() {
		RandomList<Node> res = new RandomList<Node>() ;
		for( SimpleInterval i : intervals )
			res.addAll( NodeDB.nodes( i.L, i.H) ) ;
		return res ;
	}
	
	public Node randomNode() {
		return nodes().randomElement() ;
	}
	
	public String toString() {
		return super.toString() + "=" + length() + "{"+ nodes().size() + "}";
	}

	public Range union(Range other) {
		return new Range(super.union(other));
	}

	public Range difference(Range other) {
		return new Range(super.difference(other));
	}

	public Range intersection(Range other) {
		return new Range(super.intersection(other));
	}

	public Range remove(long K) {
		return new Range(super.difference(new Interval(K, K)));
	}

	public Range subRange3(long O, long K) {		
		Interval x = K >= 0 ? new Interval(O, K) : new Interval(L(), K).union(new Interval(O, H()));
		return new Range(x.intersection(this));
	}	

	/**
	 * Slices just taking into account the extremes of the range.
	 */
	public List<Range> slice( int slices) {
		ArrayList<Range> res = new ArrayList<Range>();

		long sliceWidth = ( H() - L() ) / slices ;		
		
		long b = L() ;
		for( int i = 0 ; i < slices - 1; i++ ) {
			res.add( new Range(b, b + sliceWidth).intersection(this)) ;
			b += sliceWidth + 1;
		}
		res.add( new Range(b, H()).intersection(this) ) ;
		return res;
	}
	
	/**
	 * Slices the range evenly taking into account any holes not part of the range. 
	 * Chooses a random value in the range as the beginning of the first slice, wrapping around the range as needed.
	 */
	public List<Range> slice2( int slices) {
		ArrayList<Range> res = new ArrayList<Range>();

		long B = this.randomValue() ;

		Interval remaining = new Interval(this) ;		
		
		for( int i = slices ; --i >= 0 ; ) {
			Interval ii = new Interval() ;
			long SW = (long)( remaining.length() / (i+1.0) + rg.nextDouble() ) ;
			
			while(ii.length() < SW ) {
				for( SimpleInterval j : remaining.intervals ) {
					if( j.contains( B ) ) {
						long BH = Math.min( j.H, B + (SW-ii.length()) -1L) ;
						
						Interval ij = new Interval( B, BH) ;
						remaining = remaining.difference(ij) ;

						ii = ii.union( ij) ;
						if( ! remaining.isEmpty() )
							B = remaining.moveInside(BH + 1L) ;
						break ;
					}
				}
			}
			res.add( new Range( ii.intersection(this)) ) ;
		}
		assert this.length() == listLength( res ) ;
		return res;
	}

	/**
	 * Slices the range evenly taking into account any holes not part of the range. 
	 * Takes a value in the range as the beginning of the first slice, wrapping around the range as needed.
	 */
	public List<Range> slice3( long b, int slices) {
		ArrayList<Range> res = new ArrayList<Range>();
		
		Interval remaining = new Interval(this) ;		
		long B = remaining.moveInside(b+1L) ;
		
		for( int i = slices ; --i >= 0 ; ) {
			Interval ii = new Interval() ;
			long SW = (long)( remaining.length() / (i+1.0) + rg.nextDouble() ) ;
			
			while(ii.length() < SW ) {
				for( SimpleInterval j : remaining.intervals ) {
					if( j.contains( B ) ) {
						long BH = Math.min( j.H, B + (SW-ii.length()) -1L) ;
						
						Interval ij = new Interval( B, BH) ;
						remaining = remaining.difference(ij) ;

						ii = ii.union( ij) ;
						if( ! remaining.isEmpty() )
							B = remaining.moveInside(BH + 1L) ;
						break ;
					}
				}
			}
			res.add( new Range( ii.intersection(this)) ) ;
		}
		assert this.length() == listLength( res ) ;
		return res;
	}

	public List<Range> slice4(int slices) {
		ArrayList<Range> res = new ArrayList<Range>();

		List<Node> remaining = nodes();

		for( int i = slices ; --i >= 1 ; ) {
			long B = remaining.get(0).key ;			
			int SW = (int)( remaining.size() / (i+1.0) + rg.nextDouble() ) ;
			long BH = remaining.get(SW-1).key ;
			Range ri = new Range( new Interval(B, BH).intersection(this) ) ;
			res.add( ri ) ;
			remaining = remaining.subList(SW, remaining.size()) ;
		}
		Range rr = new Range( new Interval( remaining.get(0).key, H() ).intersection(this) ) ;
		res.add(rr) ;
		return res;
	}
	
	private long listLength( List<Range> l ){
		long res = 0 ;
		for( Range i : l )
			res += i.length() ;
		
		return res ;
	}
	
	public List<Range> subRanges() {
		ArrayList<Range> res = new ArrayList<Range>() ;
		for( SimpleInterval i : intervals )
			res.add( new Range( i.L, i.H ) ) ;
		
		return res ;
	}
	
	@SuppressWarnings("unchecked")
	public <T> T closestNode( Comparator comparator ) {
		TreeSet tmp = new TreeSet( comparator ) ;
		tmp.addAll( nodes() ) ;
		return tmp.isEmpty() ? null : (T)tmp.first() ;
	}
}
