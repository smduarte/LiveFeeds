package livefeeds.tempest1.msgs;

import java.awt.*;
import java.awt.geom.*;

import simsim.core.*;

@SuppressWarnings("serial")
public class DeliverPayload extends Message {
	
	public Object payload ;
	
	public DeliverPayload( Object payload ) {
		super( true, Color.red) ;
		this.payload = payload ;
	}
	
	public int length() {
		return 512 ;
	}
	
	public String toString() {
		return String.format("DeliveryPayload<%s>", payload ) ;
	}
	
	public void display( Graphics2D gu, Graphics2D gs, EndPoint src, EndPoint dst,  double due, double t) {
    	livefeeds.tempest1.Node a = (livefeeds.tempest1.Node) src.handler ;
    	livefeeds.tempest1.Node b = (livefeeds.tempest1.Node) dst.handler ;
    	
    	double x1 = a.shape.x1 ; double y1 = a.shape.y1 ;
    	double x2 = b.shape.x1 ; double y2 = b.shape.y1 ;

    	double x = (x1 + x2) * 0.5 ;
    	double y = (y1 + y2) * 0.5 ;
    	
    	float w = 1.0f / (1 + 5 ) ;
    	
    	
    	double cx = x + (500 - x) * w ;
    	double cy = y + (500 - y) * w ;
    	
    	QuadCurve2D.Double ab = new QuadCurve2D.Double( x1, y1, cx, cy, x2, y2) ;
    	gs.setColor(  Color.red ) ;
    	gs.setStroke( new BasicStroke( 1f ) ) ;
    	gs.draw( ab ) ;
	}
	
	public void deliverTo( EndPoint src, MessageHandler handler ) {
		((AppMessageHandler)handler).onReceive( src, this ) ;
	}
}
