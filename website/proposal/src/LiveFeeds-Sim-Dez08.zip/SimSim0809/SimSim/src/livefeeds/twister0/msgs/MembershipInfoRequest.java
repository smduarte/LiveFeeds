package livefeeds.twister0.msgs;

import java.awt.* ;

import simsim.core.*;
import livefeeds.twister0.*;

@SuppressWarnings("serial")
public class MembershipInfoRequest extends AppMessage {
	
	public View oView;
	public View gView ;
	public SlidingIntSet knownNodes ;
	
	public MembershipInfoRequest(){
	} 
	
	public int length() {
		return 0 ;
	}
	
	public MembershipInfoRequest(  View ov, View gv, SlidingIntSet kn ) {
		super(true, Color.blue) ;
		this.oView = new View( ov ) ;
		this.gView = new View( gv ) ;
		this.knownNodes = new SlidingIntSet( kn ) ;
	}
	
	public String toString() {
		return String.format("MembershipInfo") ;
	}
	
	public void deliverTo( TcpChannel ch, MessageHandler handler ) {
		((AppMessageHandler)handler).onReceive( ch, this ) ;
	}
	
	public void deliverTo( EndPoint src, MessageHandler handler ) {
		((AppMessageHandler)handler).onReceive( src, this ) ;
	}
}
