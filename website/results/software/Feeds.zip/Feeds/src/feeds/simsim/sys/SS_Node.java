package feeds.simsim.sys;


import simsim.core.*;
import simsim.gui.canvas.Canvas;
import simsim.gui.canvas.Pen;
import simsim.gui.canvas.RGB;

import feeds.simsim.*;
import feeds.sys.catadupa.Catadupa;
import feeds.sys.core.*;
import feeds.sys.packets.*;

abstract public class SS_Node extends Node implements SS_MessageHandler {

	public static SS_NodeDB<SS_Node> db = new SS_NodeDB<SS_Node>() ;
	
	public ID id ;
	public NodeContext context ;
	Dispatcher dispatcher ;
	
	public SS_Node( NodeContext ctx ) {
		this.id = ctx.id() ;
		this.context = ctx ;		
		db.store(this) ;
	}

	public String url() {
		return "ss://-/" + id + "/" ;
	}
	
	public void init() {
		context.init() ;
		dispatcher = context.plm.dispatcher() ;
	}

	abstract public void initNode() ;
	
	public void onReceive( EndPoint src, SS_cPacket p ) {
		context.makeCurrent() ;
		try {	
			dispatcher.dispatch( cPacket.decode( p.packet ) ) ;
		}
		catch( Exception x ) {
			x.printStackTrace() ;
		}
	}
	
	public void onReceive( TcpChannel ch, SS_cPacket p ) {
		context.makeCurrent() ;
		try {
			dispatcher.dispatch( cPacket.decode( p.packet ) ) ;
		}
		catch( Exception x ) {
			x.printStackTrace() ;
		}
	}
	
	public String toString() {
		return id.toString() ;
	}
	
	final Pen pen0 = new Pen( RGB.black, 0 ) ;
	public void displayOn( Canvas canvas ) {
		pen0.useColorOn(canvas.gs) ;
		canvas.sDraw( address.toString(), address.pos.x, address.pos.y - 20);
//		if( cat == null ) {
//			cat = FeedsRegistry.get("Catadupa") ;
//		} else {			
//			gs.drawString( ""+cat.db.k2n.size(), (float)address.pos.x, (float) (address.pos.y + 20));
//		}
	}
	
	Catadupa cat ;
}