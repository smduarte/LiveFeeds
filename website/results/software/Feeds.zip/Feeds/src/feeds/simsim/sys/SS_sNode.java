package feeds.simsim.sys;


import simsim.gui.canvas.Canvas;
import simsim.gui.canvas.RGB;
import simsim.gui.geom.*;

import feeds.simsim.*;
import feeds.sys.core.*;
import feeds.sys.tasks.*;
import static simsim.core.Simulation.*;

abstract public class SS_sNode extends SS_Node {

	protected SS_Node server ;
	
	protected SS_sNode( SS_pNode server ) {
		super( new SS_sNodeContext( new ID( server.id.longValue() + ((sNode.db.size() + 1) << 25))));
		this.server = server ;
		
		double mpl = SS_pNode.meanLatency() ;
		while( address.latency( server.address) > 0.25 * mpl || address.latency( server.address) < 0.005 ) {
			address = Network.createAddress( this) ;
			endpoint = address.endpoint ;
			mpl *= 1.01 ;
		}
		super.setColor( new RGB(0.7, 0.7, 0.7 ) ) ;
	}

	public void init() {
		super.init() ;
		
		new Task(1000.0 + 500 * rg.nextDouble() ) {
			public void run(){
				context.makeCurrent() ;
				initNode() ;				
			}
		};
	}
	
	static ID randomID() {
		start: for(;;) {
			ID res = new ID() ;
			for( SS_Node i : db.nodes )
				if( i.id.equals(res) ) 
					continue start;
			return res ;
		}
	}
	
	public void displayOn( Canvas canvas) {
		canvas.sFill( super.getColor(), new Circle( address.pos, 18.0 ) ) ;		
	}
}