package feeds.sys.backbone;

public class BackboneServices {
	
	public static void start() {
		HelloService.start() ;
		LinkStateService.start() ;
	}	
}
