package feeds.sys.tasks;


public class TaskScheduler extends simsim.scheduler.RT_Scheduler<Task> {
}   
