package feeds.sys.core;

public enum NodeType { pNODE, sNODE, cNODE, mNODE } ;
