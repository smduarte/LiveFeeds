package meeds.simsim.sys;


import static simsim.core.Simulation.rg;
import meeds.sys.proxying.ProxyDiscoveryService;
import simsim.gui.canvas.Canvas;
import simsim.gui.canvas.HSB;
import simsim.gui.canvas.Pen;
import simsim.gui.canvas.RGB;
import simsim.gui.geom.Circle;
import simsim.gui.geom.Rectangle;
import feeds.simsim.sys.SS_sNode;
import feeds.sys.core.ID;

abstract public class SS_ProxyNode extends SS_FixedNode {
	
	protected SS_ProxyNode( SS_sNode server) {
		super( server, new SS_ProxyNodeContext(new ID( server.id.longValue() + (SS_FixedNode.db.size() + 1))));
	}

	
	
	final Pen paint0 = new Pen( RGB.green.darker(), 1 ) ;
	final Pen paint1 = new Pen( RGB.gray, 2, 4.0 ) ;
	final Pen paint2 = new Pen( RGB.gray, 0.5, 2 ) ;
	final Pen paint4 = new Pen( new HSB(rg.nextFloat(), 0.5, 0.6, 0.25), 0.5) ;

	public void displayOn( Canvas canvas ) {
		//super.display(gu, gs) ;		
		paint0.useOn( canvas.gs ) ;
		canvas.sFill( new Rectangle( address.pos.x, address.pos.y, 12.0, 12.0) ) ;
		paint4.useOn( canvas.gs ) ;
		canvas.sFill( new Circle( address.pos.x, address.pos.y, 2*ProxyDiscoveryService.RADIUS ) ) ;	
		paint2.useOn( canvas.gs ) ;
		canvas.sDraw( new Circle( address.pos.x, address.pos.y, 2*ProxyDiscoveryService.RADIUS ) ) ;	
	}
}


