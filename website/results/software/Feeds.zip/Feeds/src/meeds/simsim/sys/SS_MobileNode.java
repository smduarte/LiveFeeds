package meeds.simsim.sys;

import static simsim.core.Simulation.rg;

import java.awt.geom.Area;
import java.util.ArrayList;

import meeds.simsim.HomebaseNode;
import meeds.sys.homing.HomingService;
import meeds.sys.homing.Position;
import meeds.sys.homing.containers.Homebase;
import meeds.sys.homing.containers.Location;
import meeds.sys.proxying.ProxyInfo;
import meeds.sys.proxying.containers.Proxy;
import simsim.gui.canvas.Canvas;
import simsim.gui.canvas.HSB;
import simsim.gui.canvas.Pen;
import simsim.gui.canvas.RGB;
import simsim.gui.geom.Circle;
import simsim.gui.geom.Ellipse;
import simsim.gui.geom.Line;
import simsim.gui.geom.XY;
import feeds.simsim.sys.SS_Node;
import feeds.sys.core.Container;
import feeds.sys.core.ContainerListener;
import feeds.sys.core.ID;
import feeds.sys.core.NodeType;
import feeds.sys.registry.NodeRegistry;
import feeds.sys.tasks.PeriodicTask;
import feeds.sys.tasks.Task;
import feeds.sys.util.ExpirableSet;

abstract public class SS_MobileNode extends SS_Node {
	
	protected SS_Node homebase;
	protected Particle particle ;
	
	protected SS_MobileNode() {
		super(new SS_MobileNodeContext( new ID() ));

		homebase = HomebaseNode.db.nodes.randomElement() ;
				
		particle = new Particle( address.pos ) ;
		super.setColor( paint0.color ) ;
	}

	public void init() {
		super.init() ;
		
		new Task(5000.0 + 3 * rg.nextDouble() ) {
			public void run(){
				context.makeCurrent() ;
				initNode() ;

				new PeriodicTask(1) {
					public void run() {
						particle.update() ;
						address.pos = particle.pos ;
					}
				};
				
				final Location.Updater locu = Container.byClass( Location.class) ;

				new PeriodicTask(30) {
					public void run() {
						locu.set( new Position( address.pos.x, address.pos.y ) ) ;
					}
				} ;
				
				Container.monitor( Location.class, new ContainerListener<Location> () {
					public void handleContainerUpdate(Location c) {
						sampledPos = new XY( c.pos().xy.x, c.pos().xy.y) ;
					}
				}) ;
				
				Container.monitor( Homebase.class, new ContainerListener<Homebase> () {
					public void handleContainerUpdate(Homebase hb) {
						try {
							HB_Node = SS_Node.db.get( hb.sortedTransports().get(0).dst() ) ;
						} catch( Exception x ){
							HB_Node = null ;
						}
					}
				}) ;
				Container.monitor( Proxy.class, new ContainerListener<Proxy> () {
					public void handleContainerUpdate(Proxy p) {
						try {
							PX_Node = SS_Node.db.get( p.closestProxy().dst() ) ;
						} catch( Exception x ){
							PX_Node = null ;
						}
					}
				}) ;
				
			}
		};
		
	}
		
	final Pen paint0 = new Pen( new HSB(rg.nextFloat(), 0.4, 0.6), 2.0 ) ;
	final Pen paint1 = new Pen( new RGB(1, 0, 0, 0.4), 4, 10) ;
	final Pen paint2 = new Pen( new RGB(0,1,0.4,0.4), 8) ;
	final Pen paint3 = new Pen( new RGB(1,0.7,0.4,0.6), 12) ;
	final Pen paint4 = new Pen( new HSB(rg.nextFloat(), 0.2, 0.2, 0.2), 1.0 ) ;
	
	public void displayOn( Canvas canvas) {
		//super.displayOn( canvas ) ;
					

		if( HB_Node != null ) {
			paint1.useOn(canvas.gs) ;
			canvas.sDraw( new Line( address.pos, HB_Node.address.pos ) ) ;
		}
		if( PX_Node != null ) {
			paint2.useOn(canvas.gs) ;
			canvas.sDraw( new Line( address.pos, PX_Node.address.pos) ) ;
		}
		
		if( particle.attractor != null ) {
			paint3.useOn(canvas.gs) ;
			canvas.sDraw( new Circle( particle.attractor.address.pos, 40 ) ) ;
		}
		
		ExpirableSet<ProxyInfo> pset = HomingService.pmap.get(id) ;
		if( pset != null ) {
			paint4.useOn(canvas.gs) ;
			
			Area a = new Area() ;
			for( ProxyInfo i : new ArrayList<ProxyInfo>(pset) ) {
				a.add( new Area( new Circle( i.pos.xy.x, i.pos.xy.y, 2*i.radius) ) ) ;		
			}
			canvas.sFill(a) ;
		}
		
		final Pen paint0 = new Pen( RGB.blue, 0.5 ) ;
		paint0.useOn( canvas.gs ) ;
		canvas.sFill(new Ellipse( address.pos, 10.0, 20.0));
		canvas.sDraw(new Ellipse( sampledPos, 10.0, 20.0));

	}
	

	private SS_Node HB_Node, PX_Node ;
	private XY sampledPos = new XY(-1000, -1000) ;	
}

class SS_MobileNodeContext extends SS_MobilityContext {

	public SS_MobileNodeContext( ID v) {
    	super( v, NodeType.mNODE ) ;
        reg = new NodeRegistry().init() ;     
        isMnode = true ;
        isCnode = false ;
    }    	
}

class Particle {
	XY pos, vel, acc ;
	
	Particle( XY pos ) {
		this.pos = new XY( pos.x, pos.y ) ;
		this.vel = new XY( 0, 0) ;
		this.acc = new XY( 0, 0) ;
	}
		
	void move_it( double dt ) {
		pos = pos.add( vel.mult( dt ) ) ;
		vel = vel.add( acc.mult( dt ) ) ;
		
		double v = vel.normalize() ;
		vel = vel.mult( Math.min(v, 50.0 ) ) ;
	}
	
	void acc_it() {
		
		final double f1 = 100.0, e1 = 0.0 ;
		XY v = pos.sub( attractor.address.pos ) ;
		double d = v.normalize() ;
		acc = v.mult( -f1 * Math.pow(0.001+d, e1) ) ;
	}
		
	public void update() {
		while( (pos.distance( attractor.address.pos ) < (60 + 30 * rg.nextDouble()) || attractor.context.type == NodeType.mNODE) )
			attractor = SS_FixedNode.db.randomNode() ;
		
		acc_it() ;
		move_it(0.01) ;
		
	}
	
	SS_Node attractor = SS_Node.db.randomNode() ;
}
