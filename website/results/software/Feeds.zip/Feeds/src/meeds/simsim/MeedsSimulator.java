package meeds.simsim;

import static simsim.core.Simulation.DisplayFlags.SIMULATION;
import static simsim.core.Simulation.DisplayFlags.TIME;

import java.util.EnumSet;

import simsim.core.Displayable;
import simsim.core.Globals;
import simsim.core.Simulation;
import simsim.gui.canvas.Canvas;
import simsim.gui.canvas.Pen;
import simsim.gui.canvas.RGB;
import feeds.simsim.Node;
import feeds.simsim.pNode;
import feeds.simsim.sNode;

public class MeedsSimulator extends Simulation implements Displayable {

	public static final int TOTAL_mNODES = 7;
	public static final int TOTAL_hNODES = 8;
	public static final int TOTAL_xNODES = 20;
	public static final int TOTAL_sNODES = 20;
	public static final int TOTAL_pNODES = 10;

	MeedsSimulator() {
		super( 5, EnumSet.of( TIME, SIMULATION ));
		//super(15, EnumSet.of(TIME));
	}

	MeedsSimulator init() {
		Spanner.setThreshold(1e10);

		Gui.setDesktopSize(920, 745);
		Gui.setFrameRectangle("MainFrame", 0, 0, 120, 120);
		Gui.maximizeFrame("MainFrame");

		for (int i = 0; i < TOTAL_pNODES; i++)
			new pNode();

		for (int i = 0; i < TOTAL_sNODES; i++)
			new sNode();

		System.out.println("Allocated secondary nodes...");

		for (int i = 0; i < TOTAL_xNODES; i++)
			new ProxyNode();

		for (int i = 0; i < TOTAL_hNODES; i++)
			new HomebaseNode();

		for (int i = 0; i < TOTAL_mNODES; i++)
			new MobileNode();

		System.out.println("Allocated client nodes...");

		for (Node i : Node.nodes())
			i.init();

		Gui.addDisplayable("Lisbon-Map", new Displayable() {
			public void displayOn(Canvas canvas) {
				for (Node i : Node.nodes()) {
					i.displayOn(canvas);
				}
			}
		}, 15);
		Gui.setFrameRectangle("Lisbon-Map", 0, 0, 920, 698) ;
		
		super.setSimulationMaxTimeWarp(1000.0) ;
		return this;
	}

	public static void main(String[] args) throws Exception {

		Globals.set("Net_Jitter", 0.0);
		Globals.set("Sim_RandomSeed", 4L);
		Globals.set("Net_RandomSeed", 4L);

		Globals.set("Net_FontSize", 18.0f);
		Globals.set("Net_Euclidean_NodeRadius", 15.0);
		Globals.set("Net_Euclidean_CostFactor", 0.00001);
		Globals.set("Net_Euclidean_DisplayNodeLabels", true);
		Globals.set("Net_Euclidean_MinimumNodeDistance", 500.0);

		Globals.set("Net_FontSize", 18.0f);
		Globals.set("Net_Euclidean_NodeRadius", 15.0);
		Globals.set("Net_Euclidean_CostFactor", 0.00005);
		Globals.set("Net_Euclidean_DisplayNodeLabels", true);
		Globals.set("Net_Euclidean_MinimumNodeDistance", 500.0);

		Globals.set("Traffic_DeadPacketHistory", 1.0);
		Globals.set("Traffic_DisplayDeadPackets", true);
		Globals.set("Traffic_DisplayDeadPacketsHistory", "time");

		new MeedsSimulator().init().start();
	}

	final Pen pen = new Pen(RGB.BLACK, 1);

	// ------------------------------------------------------------------------------------------------------------------
	public void displayOn(Canvas canvas) {
		pen.useStrokeOn(canvas.gs);
		for (Node i : Node.nodes())
			i.displayOn(canvas);
	}
}