package meeds.sys.pipeline;

import feeds.sys.core.* ;

public class BasicTemplate0 extends BasicTemplate<Void, Void, Void, Void>{
	
	protected BasicTemplate0() {
	}
	
	protected BasicTemplate0( ID channel ) {
		super(channel) ;
	}
}
