package androeeds.sensors.cam;

import seeds.sensors.api.cam.CamData;
import seeds.sensors.api.cam.CamRequest;
import seeds.sensors.sys.cam.CamSensor;

public class AndroidCamSensor extends CamSensor{
	
	public void init(){
	}
	
	public void takePicture(){
		//AndroidNodeContext.main.startActivity(intent)
	}

	protected CamData takePicture(CamRequest req) {
		return null;
	}
	
}
