package androeeds.sensors.mic;

import seeds.sensors.sys.common.VSensor;
import seeds.sensors.sys.mic.MicChannel;

public class AndroidMicChannel extends MicChannel{
	
	AndroidMicSensor mic = new AndroidMicSensor() ;

	protected VSensor getSensor() {
	return mic ;
	}
	
}


