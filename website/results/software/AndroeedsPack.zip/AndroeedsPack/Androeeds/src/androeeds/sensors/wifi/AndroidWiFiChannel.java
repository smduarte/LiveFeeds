package androeeds.sensors.wifi;

import seeds.sensors.sys.common.VSensor;
import seeds.sensors.sys.wifi.WiFiChannel;

public class AndroidWiFiChannel extends WiFiChannel {

	private final AndroidWiFiSensor wifiSensor = new AndroidWiFiSensor() ;

	protected VSensor getSensor() {
		return wifiSensor ;
	}
	
}
