package androeeds.sys.directory;

import meeds.sys.directory.MeedsDirectoryStorage;
import feeds.sys.core.ID;

public class AndroidDirectoryStorage extends MeedsDirectoryStorage {

	public static void init() {
		try {
			MeedsDirectoryStorage.init() ;
	
            //inserido por fábio neves
            createSystemChannelRecord( "/System/Sensors/Accelerometer", "acc_template", new ID(501L) ) ;
            createSystemTemplateRecord("acc_template", androeeds.sensors.acc.AndroidAccelerometerChannel.class) ;

            createSystemChannelRecord( "/System/Sensors/Gps", "gps_template", new ID(503L) ) ;
            createSystemTemplateRecord("gps_template", androeeds.sensors.gps.AndroidGpsChannel.class) ;

            createSystemChannelRecord( "/System/Sensors/Microphone", "mic_template", new ID(504L) ) ;
            createSystemTemplateRecord("mic_template", androeeds.sensors.mic.AndroidMicChannel.class) ;
            
            createSystemChannelRecord( "/System/Sensors/Tilt", "tilt_template", new ID(505L) ) ;
            createSystemTemplateRecord("tilt_template", androeeds.sensors.tilt.AndroidTiltChannel.class) ;

            createSystemChannelRecord( "/System/Sensors/WiFi", "wifi_template", new ID(506L) ) ;
            createSystemTemplateRecord("wifi_template", androeeds.sensors.wifi.AndroidWiFiChannel.class) ;            


            /*
            createSystemChannelRecord( "/System/Sensors/Camera", "cam_channel", new ID(502L) ) ;
            createSystemTemplateRecord("cam_template", androeeds.sensors.cam.channels.AndroidCamChannel.class) ;
  */          

            /*
            
            
    
            */
		} catch (Exception x) {
			x.printStackTrace();
		}
	}
}
