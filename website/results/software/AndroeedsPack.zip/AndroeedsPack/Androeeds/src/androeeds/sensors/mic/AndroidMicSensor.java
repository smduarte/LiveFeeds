package androeeds.sensors.mic;

import seeds.sensors.api.mic.MicData;
import seeds.sensors.sys.mic.MicSensor;
import android.media.MediaRecorder;
import feeds.sys.tasks.Task;

public class AndroidMicSensor extends MicSensor {

	protected MediaRecorder recorder;
	
	String base_file_path = "/sdcard/output" ;

	public void init() {
		super.init() ;
		
		try {			
			new Task(10.0) {
				public void run() {
					
					initRecorder();
					recorder.start(); // Recording is now started
					new Task(currentConfig.duration) {
						public void run() {
							recorder.stop();
							notifyUpdateNow() ;
						}
					};
					reSchedule( currentConfig.refreshRate ) ;
				}
			};
		} catch (Exception x) {
			x.printStackTrace();
		} finally {
			if( recorder != null )
				recorder.release();
		}
	}

	protected void initRecorder() {
		try {
			
			if( recorder == null )
				recorder = new MediaRecorder();
			else
				recorder.reset() ;

			recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
			recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
			recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
			currentValue = new MicData(base_file_path + (++counter%10) + ".3GP", null ) ;
			recorder.setOutputFile( currentValue.filename ) ;
			recorder.prepare();
		} catch (Exception x) {
			x.printStackTrace();
		}
	}
	
	int counter = 0 ;

	protected void reconfigureSensor() {
	}
}
