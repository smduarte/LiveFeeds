package androeeds.sys.pipeline;

import feeds.sys.pipeline.*;
import feeds.sys.directory.* ;

public class PipelineManager extends meeds.sys.pipeline.PipelineManager {
		
	@Override
	synchronized public <E, P, F, Q> Pipeline<E, P, F, Q> setupNewPipeline( ChannelRecord r ) {
		return setupNewPipeline(r, new PacketQueue("piq"), new PacketQueue("poq")) ;
	}	
}
