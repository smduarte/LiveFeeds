package androeeds.sensors.tilt;

import seeds.sensors.sys.common.VSensor;
import seeds.sensors.sys.tilt.TiltChannel;

public class AndroidTiltChannel extends TiltChannel {
	
	private final AndroidTiltSensor tilt = new AndroidTiltSensor() ;

	protected VSensor getSensor() {
		return tilt ;
	}	
}
