    package androeeds.sys.pipeline;

import feeds.api.* ;
import feeds.sys.core.*;
import feeds.sys.packets.*;

public class PacketQueue extends feeds.sys.pipeline.PacketQueue {

	protected PacketQueue( String name ) {
		super( name + "://-/-/") ;		
	} 
	
	public cPacket enqueue(cPacket p) {
		try {
			p.ttl( p.ttl() - 1 ) ;
			p.route(super.router);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return p;
	}

	public void send(cPacket p) throws FeedsException {
		try {
			p.route(router);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void setRouter(Router<?, ?, ?, ?> r) {
		this.router = r ;
	}
}
