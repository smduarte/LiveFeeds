package androeeds.sys.util;

import java.io.*;

import android.util.Log;

import feeds.api.Feeds;
import feeds.sys.FeedsNode;

public class FeedsPrintStream extends PrintStream {
	
	public FeedsPrintStream( String tag ) {
		super( System.out ) ;
		this.tag = tag ;
	}

	public void write(byte[] buf, int off, int len) {
		for (int i = 0; i < len; i++)
			write(buf[off + i]);
	}

	public void write(int b) {
		if (b == '\n' || b == '\r')
			this.flush() ;			
		else
			tmp.write(b);
	}

	public void close() {
		this.flush() ;
	}
	
	public void flush() {
		StringBuilder sb = new StringBuilder() ;
		sb.append( String.format("%12.4f %-16s ", Feeds.time(), "[ " + FeedsNode.id() + " ]" ) ) ;
		sb.append( new String( tmp.toByteArray(), 0, tmp.size() ) )  ;
		Log.d( tag, sb.toString() ) ; 
		tmp.reset() ;
	}
	
	final String tag ;	
	final ByteArrayOutputStream tmp = new ByteArrayOutputStream() ;
}
