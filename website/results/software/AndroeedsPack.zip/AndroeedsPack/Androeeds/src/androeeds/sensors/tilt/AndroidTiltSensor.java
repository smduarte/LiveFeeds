package androeeds.sensors.tilt;

import seeds.sensors.api.tilt.TiltData;
import seeds.sensors.sys.tilt.TiltSensor;
import androeeds.sys.core.AndroidNodeContext;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

public class AndroidTiltSensor extends TiltSensor implements SensorEventListener {

	protected void init() {
		super.init() ;
		
		SensorManager manager = AndroidNodeContext.getSensorManager();
		
		Sensor s = manager.getDefaultSensor( Sensor.TYPE_ORIENTATION ) ;
		if( s != null ) {
			manager.unregisterListener(this);
			manager.registerListener( this, s, SensorManager.SENSOR_DELAY_NORMAL ) ;			
		}
	}

	public void onAccuracyChanged(Sensor sensor, int accuracy) {
	}

	public void onSensorChanged(SensorEvent ev) {
		float[] v = ev.values ;
		currentValue = new TiltData( v[0], v[1], v[2] ) ;
	}
	
	protected void reconfigureSensor() {}
}
