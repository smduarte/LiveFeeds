package androeeds.testing;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import feeds.sys.util.Threading;

class Panel extends SurfaceView implements SurfaceHolder.Callback {

	protected PanelThread _thread ;
	protected SurfaceHolder _surfaceHolder ;
	
	public Panel(Activity activity) {
        super(activity);
        setFocusable(true);
        
        _surfaceHolder = getHolder() ;
        
        _thread = new PanelThread();
        _surfaceHolder.addCallback(this);
    }

	@Override
    public void onDraw(Canvas canvas) {
        canvas.drawColor(Color.LTGRAY);
    }

	
	
	public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
		// TODO Auto-generated method stub
		
	}

	public void surfaceCreated(SurfaceHolder holder) {
		 _thread.setRunning(true);
	}

	public void surfaceDestroyed(SurfaceHolder holder) {
        _thread.setRunning(false);
	}
	
	class PanelThread extends Thread {
        private boolean running = false;
		
        synchronized public void setRunning(boolean run) {
        	if( ! running && run ) {
        		running = true ;
        		start() ;
        	}
        	else if( running & ! run ) {
        		running = false ;
                for(;;) {
                    try {
                        _thread.join();
                        return ;
                    } catch (InterruptedException e) {
                        // we will try it again and again...
                    }
                }
        	}
        }
        
		public void run() {
	        while (running) {
	            Canvas c = null;
                try {
                    c = _surfaceHolder.lockCanvas(null);
                    synchronized (_surfaceHolder) {
                        onDraw(c);
                    }
                    Threading.sleep(50) ;
                } finally {
                    // do this in a finally so that if an exception is thrown
                    // during the above, we don't leave the Surface in an
                    // inconsistent state
                    if (c != null) {
                        _surfaceHolder.unlockCanvasAndPost(c);
                    }
                }
            }
        }
	}
}