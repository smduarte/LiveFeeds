package androeeds.testing;

import meeds.api.Meeds;
import seeds.sensors.api.Seeds;
import seeds.sensors.api.acc.AccCriteria;
import seeds.sensors.api.acc.AccData;
import seeds.sensors.api.gps.GpsCriteria;
import seeds.sensors.api.gps.GpsData;
import seeds.sensors.api.mic.MicCriteria;
import seeds.sensors.api.mic.MicData;
import seeds.sensors.api.tilt.TiltCriteria;
import seeds.sensors.api.tilt.TiltData;
import seeds.sensors.api.wifi.WiFiCriteria;
import seeds.sensors.api.wifi.WiFiData;
import androeeds.api.AndroeedsActivity;
import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Bundle;
import android.view.Window;
import feeds.api.Channel;
import feeds.api.Feeds;
import feeds.api.Payload;
import feeds.api.Receipt;
import feeds.api.Subscriber;

public class Androeeds extends AndroeedsActivity {

	public Androeeds() {
	}

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(new myPanel(this));
		init();
	}

	public void onPause() {
		Feeds.err.println("Activity paused...");
		super.onPause();
	}

	int n = 0;

	void init() {

		testGpsSensor();
		testTiltSensor();
		testAccelerometerSensor();
		testMicChannel() ;

		testWiFiSensor() ;
		
		Feeds.newThread(true, new Runnable() {
			public void run() {
				final Channel<Integer, Void, Void, Void> ch = Meeds.clone("catadupa", "/xpto", -1);
				ch.subscribe(new Subscriber<Integer, Void>() {
					public void notify(Receipt r, Integer e, Payload<Void> p) {
						n = e;
					}
				});

				for (;;) {
					ch.publish(new java.util.Random().nextInt(), null);
					Feeds.sleep(1);
				}
			}
		}).start();
	}

	GpsData location;

	AccData acc;
	TiltData tilt;

	int tilt_sample = 0 ;
	
	class myPanel extends Panel {

		myPanel(Activity a) {
			super(a);
		}

		@Override
		public void onDraw(Canvas canvas) {
			canvas.drawColor(Color.LTGRAY);

			Paint p = new Paint();
			p.setAntiAlias(true);
			p.setColor(Color.BLACK);

			if (location != null)
				canvas.drawText(String.format("lat: %.8f lng: %.8f", location.latitude, location.longitude), 10, 10, p);

			if (tilt != null)
				canvas.drawText(String.format("azimuth: %.3f pitch: %.3f roll: %.3f %d", tilt.azimuth, tilt.pitch, tilt.roll, tilt_sample), 10, 30, p);

			if (acc != null)
				canvas.drawText(String.format("x: %.3f y: %.3f z: %.3f", acc.x, acc.y, acc.z), 10, 50, p);
			//
			// if( mic != null ) {
			// canvas.drawText(String.format("x: %.3f y: %.3f z: %.3f",
			// mic.getTime(), mic.getLatitude(), mic.getLongitude()), 10, 80,
			// p);
			// }
			//				
			canvas.drawText(String.format("n: %d", n), 10, 90, p);
		}

	}

	void testGpsSensor() {
		final Channel<GpsData, Void, ?, ?> channel = Seeds.lookup("/System/Sensors/Gps");

		channel.subscribe(new GpsCriteria(10.0, "gps", 2, 5), new Subscriber<GpsData, Void>() {
			public void notify(Receipt r, GpsData e, Payload<Void> p) {
				location = e;

			}
		});
	}

	void testTiltSensor() {
		final Channel<TiltData, Void, ?, ?> channel = Seeds.lookup("/System/Sensors/Tilt");
		channel.subscribe(new TiltCriteria(0.1), new Subscriber<TiltData, Void>() {
			public void notify(Receipt r, TiltData e, Payload<Void> p) {
				tilt = e; tilt_sample++ ;
			}
		});
	}

	void testAccelerometerSensor() {
		final Channel<AccData, Void, ?, ?> channel = Seeds.lookup("/System/Sensors/Accelerometer");
		channel.subscribe(new AccCriteria(true, 0.0f, 0.1f), new Subscriber<AccData, Void>() {
			public void notify(Receipt r, AccData e, Payload<Void> p) {
				acc = e;
			}
		});
	}
	
	
	
	void testWiFiSensor() {
		final Channel<WiFiData, Void, ?, ?> channel = Seeds.lookup("/System/Sensors/WiFi");
		channel.subscribe( new WiFiCriteria(), new Subscriber<WiFiData, Void>() {
			public void notify(Receipt r, WiFiData e, Payload<Void> p) {
				Feeds.out.println( e ) ;
			}
		});
	}

	void testMicChannel() {
		final Channel<MicData, Void, ?, ?> channel = Feeds.lookup("/System/Sensors/Microphone");
		channel.subscribe(new MicCriteria(20.0, 5.0), new Subscriber<MicData, Void>() {
			public void notify(Receipt r, final MicData e, final Payload<Void> p) {				
				sp.release() ;
				sp = new SoundPool(1, AudioManager.STREAM_MUSIC, 0) ;				
				int id = sp.load( e.filename, 1) ;
				Feeds.err.println( e.filename ) ;
				Feeds.sleep(5) ;
				sp.play(id, 1.0f, 1.0f, 1, 0, 1.5f) ;
			}
		});

	}

	SoundPool sp = new SoundPool(1, AudioManager.STREAM_MUSIC, 0) ;	
}