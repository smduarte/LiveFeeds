package connectionHandler.subscriptionEngine;


/**
 * Interface de gestao de subscricoes
 * Define duas funcoes, que determinam se uma feed deve ser subscrita ou abandonada
 * 
 * @author tgarcia
 *
 */
public interface SubscriptionEngine {

	public boolean shouldSubscribe(String url);
	public boolean shouldUnsubscribe(String url);
}
