package connectionHandler.subscriptionEngine;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;

import contentHandler.HitCount;
import contentHandler.feedData.RssFeed;

import feedProvider.FeedProvider;

public class SimpleSubscriptionEngine implements SubscriptionEngine {
	
	public SimpleSubscriptionEngine() {}

	@Override
	public boolean shouldSubscribe(String url) {
		//feed é subscrita se tiver sido consultada 3 vezes nas ultimas 24 horas
		RssFeed feed = FeedProvider.feedStorage.getFeed(RssFeed.getFeedId(url));
		if (feed == null || feed.isSubscribed())
			return false;
		
		ArrayList<HitCount> hits = FeedProvider.feedStorage.getHits(url);

		int count = 0;
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -1);
		
		Iterator<HitCount> it = hits.iterator();
		while (it.hasNext())
		{
			if (it.next().getTime().after(cal.getTime()))
				count++;
		}
//		System.err.println("SimpleSubscribeEngine:");
//		System.err.println("array size: " + hits.size());
//		System.err.println("count: " + count);
		return count >= 3;
	}

	@Override
	public boolean shouldUnsubscribe(String url) {
		//feed é abandonada se não tiver sido consultada menos de 3 vezes nas ultimas 24 horas
		RssFeed feed = FeedProvider.feedStorage.getFeed(RssFeed.getFeedId(url));
		if (!feed.isSubscribed())
			return false;
		
		ArrayList<HitCount> hits = FeedProvider.feedStorage.getHits(url);

		int count = 0;
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -1);
		
		Iterator<HitCount> it = hits.iterator();
		while (it.hasNext())
		{
			if (it.next().getTime().after(cal.getTime()))
				count++;
		}
		return count < 3;
	}

}
