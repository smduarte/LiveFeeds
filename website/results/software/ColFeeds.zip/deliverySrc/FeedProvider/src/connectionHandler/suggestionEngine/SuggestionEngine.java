package connectionHandler.suggestionEngine;

import contentHandler.feedData.RssFeed;

/**
 * Interface para geracao de sugestoes. A unica funcao associada recebe uma feed
 * e retorna o xml da mesma com as sugestoes embutidas
 * 
 * @author tgarcia
 *
 */
public interface SuggestionEngine {

        public String getFeedXml(RssFeed feed);
        
}
