package connectionHandler;

import java.util.ArrayList;
import contentHandler.feedData.RssFeed;
import colFeeds.BloomFilter;
import dbConnection.*;
import feeds.api.*;

/**
 * Classe responsavel por manter e operar sobre o canal de troca de feeds
 * 
 * @author tgarcia
 *
 */
public class FeedConnector {
	private BloomFilter<String> feedFilter;
	private static DBConnection feedStorage;
	private static Channel<String, RssFeed, Float, Double> feedChannel;
	
	private BloomFilter<String> getFilterData() {
		ArrayList<String> feedList = feedStorage.getFeedFilterData();
		BloomFilter<String> filter = new BloomFilter<String>(0.01 , Math.max(1, feedList.size()));
		filter.addAll(feedList);
		return filter;
	}
	
	public FeedConnector(final DBConnection feedStorage) {
	    feedChannel = Feeds.clone("centradupa", "/feeds", -1) ;
	    
	    FeedConnector.feedStorage = feedStorage;
	    
	    this.feedFilter = getFilterData();
	    
	    feedChannel.subscribe(feedFilter, new Subscriber<String, RssFeed>() {                   
	    	public void notify( Receipt r, String e, Payload<RssFeed> p) {
	            try {
	                feedStorage.updateFeed(p.data());
	                System.err.println("=====================================================");
	                System.err.println("Feed received from LiveFeeds: " + p.data().getTitle() );
	                System.err.println("=====================================================");
	            } catch (Exception e1) {
	            	System.err.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++");
	                System.err.println("Error inserting feed from LiveFeeds");
	                System.err.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++");
	                e1.printStackTrace();
	            }
	            //TODO:averiguar feedback
//	              feedChannel.feedback( r, 0.0f, Feeds.time() ) ;
	        }       
	    }) ;
	}

	
	public void publish(RssFeed rss) {
		feedChannel.publish(rss.getUrl(), rss);
	}
	
	public void subscribe(String url) {
		feedStorage.setFeedSubscription(url, true);
		this.feedFilter = getFilterData();
		feedChannel.subscribe(feedFilter, new Subscriber<String, RssFeed>() {			
			public void notify( Receipt r, String e, Payload<RssFeed> p) {
				try {
					feedStorage.updateFeed(p.data());
					System.err.println("=====================================================");
					System.err.println("Feed received from LiveFeeds: " + p.data().getTitle() );
					System.err.println("=====================================================");
				} catch (Exception e1) {
					System.err.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++");
					System.err.println("Error inserting feed from LiveFeeds");
					System.err.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++");
					e1.printStackTrace();
				}
				//TODO:averiguar feedback
//				feedChannel.feedback( r, 0.0f, Feeds.time() ) ;
			}			
		}) ;
	}
	
}
