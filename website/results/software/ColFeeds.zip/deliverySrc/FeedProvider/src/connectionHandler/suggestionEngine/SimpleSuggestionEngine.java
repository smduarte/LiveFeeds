package connectionHandler.suggestionEngine;

import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Locale;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.sax.SAXTransformerFactory;
import javax.xml.transform.sax.TransformerHandler;
import javax.xml.transform.stream.StreamResult;

import org.xml.sax.SAXException;
import org.xml.sax.helpers.AttributesImpl;

import contentHandler.feedData.*;
import contentHandler.suggestionData.RssFeedSuggestion;

import feedProvider.FeedProvider;

/**
 * geracao do xml da feed com sugestoes embutidas
 * 
 * @author tgarcia
 *
 */
public class SimpleSuggestionEngine implements SuggestionEngine {

        @Override
        public String getFeedXml(RssFeed feed) {
                try{
                        StringWriter output = new StringWriter();
                        StreamResult streamResult = new StreamResult(output);
                        SAXTransformerFactory tf = (SAXTransformerFactory) SAXTransformerFactory.newInstance();
                        // SAX2.0 Contentsndler.
                        TransformerHandler hd = tf.newTransformerHandler();
                        Transformer serializer = hd.getTransformer();
                        serializer.setOutputProperty(OutputKeys.ENCODING,"UTF-8");
                        serializer.setOutputProperty(OutputKeys.VERSION,"1.0");
                        serializer.setOutputProperty(OutputKeys.INDENT,"yes");
                        hd.setResult(streamResult);
                        hd.startDocument();
                        
                        AttributesImpl atts = new AttributesImpl();
                        atts.clear();
//                      if (header != null && !header.isEmpty() && header.compareTo("null") != 0)
//                              atts.addAttribute("","","header","CDATA",id[i]);                        
                        atts.addAttribute("","","version","CDATA",feed.getVersion());
                        hd.startElement("","","rss",atts);
                        atts.clear();
                        hd.startElement("","","channel",atts);
                        if (feed.getTitle() != null && !feed.getTitle().isEmpty() && feed.getTitle().compareTo("null") != 0)
                        {
                                hd.startElement("","","title",atts);
                                hd.characters(feed.getTitle().toCharArray(),0,feed.getTitle().length());
                                hd.endElement("","","title");
                        }
                        if (feed.getLink() != null && !feed.getLink().isEmpty() && feed.getLink().compareTo("null") != 0)
                        {
                                hd.startElement("","","link",atts);
                                hd.characters(feed.getLink().toCharArray(),0,feed.getLink().length());
                                hd.endElement("","","link");
                        }
                        hd.startElement("","","description",atts);
                        if (feed.getDescription() != null && !feed.getDescription().isEmpty() && feed.getDescription().compareTo("null") != 0)
                                hd.characters(feed.getDescription().toCharArray(),0,feed.getDescription().length());
                        hd.endElement("","","description");
                        
                        
                        if (feed.getLanguage() != null && !feed.getLanguage().isEmpty() && feed.getLanguage().compareTo("null") != 0)
                        {
                                hd.startElement("","","language",atts);
                                hd.characters(feed.getLanguage().toCharArray(),0,feed.getLanguage().length());
                                hd.endElement("","","language");
                        }
                        if (feed.getGenerator() != null && !feed.getGenerator().isEmpty() && feed.getGenerator().compareTo("null") != 0)
                        {
                                hd.startElement("","","generator",atts);
                                hd.characters(feed.getGenerator().toCharArray(),0,feed.getGenerator().length());
                                hd.endElement("","","generator");
                        }
                        if (feed.getCopyright() != null && !feed.getCopyright().isEmpty() && feed.getCopyright().compareTo("null") != 0)
                        {
                                hd.startElement("","","copyright",atts);
                                hd.characters(feed.getCopyright().toCharArray(),0,feed.getCopyright().length());
                                hd.endElement("","","copyright");
                        }
                        Iterator<String> categoryIterator = feed.getCategories().iterator();
                        while (categoryIterator.hasNext())
                        {
                                String tempCategory = categoryIterator.next();
                                hd.startElement("","","category",atts);
                                hd.characters(tempCategory.toCharArray(),0,tempCategory.length());
                                hd.endElement("","","category");
                        }
                        if (feed.getImageUrl() != null && !feed.getImageUrl().isEmpty() && feed.getImageUrl().compareTo("null") != 0 && 
                                        feed.getImageTitle() != null && !feed.getImageTitle().isEmpty() && feed.getImageTitle().compareTo("null") != 0 && 
                                        feed.getImageLink() != null && !feed.getImageLink().isEmpty() && feed.getImageLink().compareTo("null") != 0)
                        {
                                hd.startElement("","","image",atts);
                                hd.startElement("","","url",atts);
                                hd.characters(feed.getImageUrl().toCharArray(),0,feed.getImageUrl().length());
                                hd.endElement("","","url");
                                hd.startElement("","","title",atts);
                                hd.characters(feed.getImageTitle().toCharArray(),0,feed.getImageTitle().length());
                                hd.endElement("","","title");
                                hd.startElement("","","link",atts);
                                hd.characters(feed.getImageLink().toCharArray(),0,feed.getImageLink().length());
                                hd.endElement("","","link");
                                hd.endElement("","","image");
                        }
                        Iterator<RssItem> itemIterator = feed.getItems().iterator();
                        while (itemIterator.hasNext())
                        {
                                getItemXml(itemIterator.next(), hd);
                        }
                        
                        getSuggestionXml(feed, hd);
                        
                        hd.endElement("","","channel");
                        hd.endElement("","","rss");
                        hd.endDocument();
                        output.flush();
                        return output.toString();
                }
                catch (Exception e) {
                        return e.getMessage();
                }
        }

        private void getItemXml(RssItem item, TransformerHandler hd) throws SAXException {
                AttributesImpl atts = new AttributesImpl();
                atts.clear();
        
                hd.startElement("","","item",atts);
                if (item.getTitle() != null && !item.getTitle().isEmpty() && item.getTitle().compareTo("null") != 0)
                {
                        hd.startElement("","","title",atts);
                        hd.characters(item.getTitle().toCharArray(),0,item.getTitle().length());
                        hd.endElement("","","title");
                }
                if (item.getLink() != null && !item.getLink().isEmpty() && item.getLink().compareTo("null") != 0)
                {
                        hd.startElement("","","link",atts);
                        hd.characters(item.getLink().toCharArray(),0,item.getLink().length());
                        hd.endElement("","","link");
                }
                if (item.getDescription() != null && !item.getDescription().isEmpty() && item.getDescription().compareTo("null") != 0)
                {
                        hd.startElement("","","description",atts);
                        hd.characters(item.getDescription().toCharArray(),0,item.getDescription().length());
                        hd.endElement("","","description");
                }
                if (item.getPubDateString() != null && !item.getPubDateString().isEmpty() && item.getPubDateString().compareTo("null") != 0)
                {
                        hd.startElement("","","pubDate",atts);
                        hd.characters(item.getPubDateString().toCharArray(),0,item.getPubDateString().length());
                        hd.endElement("","","pubDate");
                }
                if (item.getAuthor() != null && !item.getAuthor().isEmpty() && item.getAuthor().compareTo("null") != 0)
                {
                        hd.startElement("","","author",atts);
                        hd.characters(item.getAuthor().toCharArray(),0,item.getAuthor().length());
                        hd.endElement("","","author");
                }
                if (item.getComments() != null && !item.getComments().isEmpty() && item.getComments().compareTo("null") != 0)
                {
                        hd.startElement("","","comments",atts);
                        hd.characters(item.getComments().toCharArray(),0,item.getComments().length());
                        hd.endElement("","","comments");
                }
                if (item.getEnclosure() != null && !item.getEnclosure().isEmpty() && item.getEnclosure().compareTo("null") != 0)
                {
                        hd.startElement("","","enclosure",atts);
                        hd.characters(item.getEnclosure().toCharArray(),0,item.getEnclosure().length());
                        hd.endElement("","","enclosure");
                }
                if (item.getGuid() != null && !item.getGuid().isEmpty() && item.getGuid().compareTo("null") != 0)
                {
                        hd.startElement("","","guid",atts);
                        hd.characters(item.getGuid().toCharArray(),0,item.getGuid().length());
                        hd.endElement("","","guid");
                }
                if (item.getSource() != null && !item.getSource().isEmpty() && item.getSource().compareTo("null") != 0)
                {
                        hd.startElement("","","source",atts);
                        hd.characters(item.getSource().toCharArray(),0,item.getSource().length());
                        hd.endElement("","","source");
                }
                Iterator<String> categoryIterator = item.getCategories().iterator();
                while (categoryIterator.hasNext())
                {
                        String tempCategory = categoryIterator.next();
                        hd.startElement("","","category",atts);
                        hd.characters(tempCategory.toCharArray(),0,tempCategory.length());
                        hd.endElement("","","category");
                }
                hd.endElement("","","item");
        }

        private void getSuggestionXml(RssFeed feed, TransformerHandler hd) throws SAXException {
                AttributesImpl atts = new AttributesImpl();
                atts.clear();
        
                hd.startElement("","","item",atts);
                hd.startElement("","","title",atts);
                hd.characters("Suggestions".toCharArray(),0, "Suggestions".length());
                hd.endElement("","","title");
                
                String suggestions = new String("<table>");
                
                ArrayList<RssFeedSuggestion> relatedFeeds = FeedProvider.feedStorage.getRelatedFeedsByCategories(feed);
                relatedFeeds.addAll(FeedProvider.feedStorage.getSuggestions(feed));
                Iterator<RssFeedSuggestion> feedSuggestions = relatedFeeds.iterator();
                
//              while (relatedFeeds.hasNext())
//              {
//                      RssFeed temp = relatedFeeds.next();
//                      suggestions += "<tr>";
//                      suggestions += "<td>";
//                      suggestions += "<a href=\"" + temp.getUrl() + "\">"+ temp.getTitle() +"</a> - ";
//                      suggestions += temp.getDescription();
//                      suggestions += "</td>";
//                      suggestions += "</tr>";
//                      suggestions += "<tr><td>&nbsp;</td></tr>";
//              }
                
                
                while (feedSuggestions.hasNext())
                {
                        RssFeedSuggestion temp = feedSuggestions.next();
                        suggestions += "<tr>";
                        suggestions += "<td>";
                        suggestions += "<a href=\"" + temp.getUrl() + "\">"+ temp.getTitle() +"</a> - ";
                        suggestions += temp.getDescription();
                        suggestions += "</td>";
                        suggestions += "</tr>";
                        suggestions += "<tr><td>&nbsp;</td></tr>";
                }
                
                suggestions += "</table>";
                
                
                hd.startElement("","","description",atts);
                hd.characters(suggestions.toCharArray(),0, suggestions.length());
                hd.endElement("","","description");
                
                SimpleDateFormat dateformat = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss ZZZ", Locale.ENGLISH);
                String pubDate = new StringBuilder(dateformat.format(System.currentTimeMillis())).toString();
                
                hd.startElement("","","pubDate",atts);
                hd.characters(pubDate.toCharArray(),0,pubDate.length());
                hd.endElement("","","pubDate");
                
                hd.startElement("","","author",atts);
                hd.characters("ColFeeds".toCharArray(),0,"ColFeeds".length());
                hd.endElement("","","author");
                
                hd.endElement("","","item");
        }
        
}