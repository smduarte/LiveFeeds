package connectionHandler;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Timer;
import java.util.TimerTask;

import contentHandler.feedData.RssFeed;
import contentHandler.suggestionData.RssFeedSuggestion;
import colFeeds.BloomFilter;
import dbConnection.DBConnection;
import feedProvider.FeedProvider;
import feeds.api.Channel;
import feeds.api.Feeds;
import feeds.api.Payload;
import feeds.api.Receipt;
import feeds.api.Subscriber;


/**
 * Classe responsavel por manter e operar sobre o canal de troca de sugestoes
 * 
 * @author tgarcia
 *
 */
public class SuggestionConnector {
	private BloomFilter<String> suggestionFilter;
	private static DBConnection feedStorage;
	private static Channel<String, RssFeedSuggestion, Float, Double> suggestionChannel;
	
	public SuggestionConnector(final DBConnection feedStorage) {
		Timer timer = new Timer();
	    timer.scheduleAtFixedRate(new TimerTask() {
			@Override
			public void run() {
				Iterator<RssFeed> feedsIT = feedStorage.getFeeds().iterator();
				while (feedsIT.hasNext())
					SuggestionConnector.publish(new RssFeedSuggestion(feedsIT.next()));
			}
		}
		, 0, FeedProvider.suggestionTransmitionPeriod);
		
	    suggestionChannel = Feeds.clone("centradupa", "/suggestions", -1) ;
	    
	    SuggestionConnector.feedStorage = feedStorage;
	    
	    this.suggestionFilter = getFilterData();
	    
	    suggestionChannel.subscribe(suggestionFilter, new Subscriber<String, RssFeedSuggestion>() {                   
	    	public void notify( Receipt r, String e, Payload<RssFeedSuggestion> p) {
	            try {
	                feedStorage.addSuggestion(p.data(), e);
	                System.err.println("=====================================================");
	                System.err.println("Suggestion received from LiveFeeds: " + p.data().getTitle() );
	                System.err.println("=====================================================");
	            } catch (Exception e1) {
	            	System.err.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++");
	                System.err.println("Error receiving suggestion from LiveFeeds");
	                System.err.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++");
	                e1.printStackTrace();
	            }
	            //TODO:averiguar feedback
//	              feedChannel.feedback( r, 0.0f, Feeds.time() ) ;
	        }       
	    }) ;
	}

	private BloomFilter<String> getFilterData() {
		ArrayList<String> feedList = feedStorage.getSuggestionFilterData();
		BloomFilter<String> filter = new BloomFilter<String>(0.01 , Math.max(1, feedList.size()));
		filter.addAll(feedList);
		return filter;
	}
	
	public static void publish(RssFeedSuggestion rss) {
		Iterator<String> it = rss.getCategories().iterator();
		while (it.hasNext())
			suggestionChannel.publish(it.next(), rss);
	}
	
	public void subscribe(String url) {
		this.suggestionFilter = getFilterData();
		
		suggestionChannel.subscribe(suggestionFilter, new Subscriber<String, RssFeedSuggestion>() {			
			public void notify( Receipt r, String e, Payload<RssFeedSuggestion> p) {
				try {
	                feedStorage.addSuggestion(p.data(), e);
					System.err.println("=====================================================");
					System.err.println("Suggestion received from LiveFeeds: " + p.data().getTitle() );
					System.err.println("=====================================================");
				} catch (Exception e1) {
					System.err.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++");
					System.err.println("Error receiving suggestion from LiveFeeds");
					System.err.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++");
					e1.printStackTrace();
				}
				//TODO:averiguar feedback
//				feedChannel.feedback( r, 0.0f, Feeds.time() ) ;
			}			
		}) ;
	}
}
