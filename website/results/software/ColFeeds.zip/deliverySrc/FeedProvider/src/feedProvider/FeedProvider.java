package feedProvider;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import org.w3c.dom.*;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import connectionHandler.FeedConnector;
import connectionHandler.SuggestionConnector;
import connectionHandler.subscriptionEngine.SimpleSubscriptionEngine;
import connectionHandler.subscriptionEngine.SubscriptionEngine;
import connectionHandler.suggestionEngine.SimpleSuggestionEngine;
import connectionHandler.suggestionEngine.SuggestionEngine;
import contentHandler.FeedDisplayer;
import contentHandler.FeedHandler;
import contentHandler.feedData.RssFeed;
import dbConnection.*;
import Comanche.MyResponseWrapper;
import Repository.RepositoryInterface;



public class FeedProvider implements Filter {
	/*
	 * Parametros de configuração
	 */
	public final static long feedTTL = 300000; //5 minutos
	public final static String dbName = "colfeeds1";
	public final static String dbUser = "root";
	public final static String dbPassword = "root";
	public final static long suggestionTransmitionPeriod = 3600000; //1 hora
	public final static String DataURL = "tcp://127.0.0.1:39999";
	public final static String BindingURLs = "tcp://-:38888/-";

	
	
	public static DBConnection feedStorage;
	public static FeedConnector feedConnector;
	public static SuggestionConnector suggestionConnector;
	public static SubscriptionEngine subscribeEngine = new SimpleSubscriptionEngine();
	public static SuggestionEngine suggestionEngine = new SimpleSuggestionEngine();


	public FeedProvider() {
		System.setProperty("BindingURLs", DataURL);
		System.setProperty("DataURL", BindingURLs);
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException 
	{
		feedStorage = new MysqlDBConnection();
		feedStorage.init((RepositoryInterface)fConfig.getServletContext().getAttribute("repository"));

		feedConnector = new FeedConnector(feedStorage);
		suggestionConnector= new SuggestionConnector(feedStorage);

		System.err.println("++++++++++++++ Servlet Init +++++++++++");
	}


	public void doFilter(ServletRequest request, ServletResponse servletResponse, FilterChain chain) throws IOException, ServletException 
	{
		HttpServletRequest httpRequest = (HttpServletRequest)request;
		String httpRequestUrl = httpRequest.getRequestURL().toString();
		MyResponseWrapper myResponse = (MyResponseWrapper)servletResponse;
		boolean isFeed = false;
		boolean isKnownFeed = false;
		
		/*
		 * Detecta se o URL actual é de uma feed conhecida
		 */
		if (feedStorage.containsFeed(httpRequestUrl))
		{
			/*
			 * URL é de uma feed conhecida 
			 * Pedido não é encaminhado pedido para o servidor
			 */
			isFeed = true;
			isKnownFeed = true;
		}
		else
		{
			/*
			 * URL não é de uma feed conhecida
			 * Encaminha-se pedido para o servidor, e verifica-se a resposta obtida
			 */
			chain.doFilter(request, servletResponse);
			
			ArrayList<String> responseLines = new ArrayList<String>(Arrays.asList(myResponse.response.toString().split("\n")));
            Iterator<String> responseLinesIt = responseLines.iterator();
            while (responseLinesIt.hasNext())
            {
                    String temp = responseLinesIt.next();
                    if (temp.toLowerCase().startsWith("content-type") && (temp.toLowerCase().contains("application/xml") || temp.toLowerCase().contains("application/rss+xml") || temp.toLowerCase().contains("text/xml")) )
                            isFeed = true;
            }
			
//          Versão limpa e arrumada do código acima que, por algum motivo, não funciona :(
//			HttpServletResponse httpServletResponse = (HttpServletResponse)servletResponse;
//			if (httpServletResponse.getContentType().contains("application/xml") ||
//					httpServletResponse.getContentType().contains("application/rss+xml") ||
//					httpServletResponse.getContentType().contains("text/xml"))
//				//URL de uma feed desc
//				isFeed = true;
		}

		/*
		 *  Se se tratar de uma feed
		 *  invoca o FeedHandler
		 */
		if (isFeed)
		{
			try {
				FeedHandler.handleFeed(httpRequestUrl, isKnownFeed);
			} catch (Exception e1) {
				isFeed = false;
			}
			
			//Adiciona os hits
			feedStorage.addHitsToFeed(httpRequestUrl, true);
			
			/*
			 * Apresenta a resposta (feed) com base na informação
			 * da base de dados local.
			 * Se alguma coisa decorrer mal, obtem-se a resposta
			 * do servidor (damage control)
			 */
			if (isFeed)
			{
				try {
					
					FeedDisplayer.displayFeed(RssFeed.getFeedId(httpRequestUrl), myResponse);			
				}
				catch (IOException e) {
					chain.doFilter(request, servletResponse);
				}
			}
		}
		/*
		 * Não se está a aceder a uma feed,
		 * mas sim a uma página normal
		 */
		else
		{
			//Acrescenta o hit.
			feedStorage.addHit(httpRequestUrl, null, true);

			//Procura-se por feeds no cabeçalho da página
			//Se houver feeds no cabeçalho da página
			//guardam-se em base de dados
			Iterator<Node> it = detectPageInfo(myResponse.getDOMDocument()).iterator();
			while (it.hasNext())
			{
				Node temp = it.next();
				for (int k = 0; k < temp.getAttributes().getLength(); k++)
				{
					if (temp.getAttributes().item(k).getLocalName().toLowerCase().compareTo("href") == 0 )
					{
						try {
							FeedHandler.handleFeed(temp.getAttributes().item(k).getTextContent());
						} catch (Exception e) {}
					}
				}
			}
		}
	}

	public void destroy() {}

	/*
	 * Procura no html de uma página se existem referências para outras feeds
	 */
	private ArrayList<Node> detectPageInfo(Document doc) {
		ArrayList<Node> detectedFeeds = new ArrayList<Node>();
		if (doc != null)
		{
			NodeList nodes = doc.getElementsByTagName("head");
			//Percorre todas as heads (só há uma, mas enfim...)
			for (int i = 0; i < nodes.getLength(); i++)
			{
				NodeList headContent = nodes.item(i).getChildNodes();
				//Percorre todos os elementos de cada head
				for (int j = 0; j < headContent.getLength(); j++)
				{
					Node headElement = headContent.item(j);
					if ( headElement instanceof Element  && ((Element)headElement).getTagName().toLowerCase().compareTo("link") == 0 && ((Element)headElement).hasAttributes())
					{
						//Percorre os atributos de todos os elementos link, para obter as feeds
						for (int k = 0; k < headElement.getAttributes().getLength(); k++)
						{
							if (headElement.getAttributes().item(k).getTextContent().toLowerCase().compareTo("application/rss+xml") == 0 )
							{
								detectedFeeds.add(headElement);
							}
						}
					}
				}
			}
		}
		return detectedFeeds;
	}



}
