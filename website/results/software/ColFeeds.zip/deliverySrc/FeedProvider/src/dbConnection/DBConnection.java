package dbConnection;

import java.util.ArrayList;

import contentHandler.HitCount;
import contentHandler.feedData.RssFeed;
import contentHandler.suggestionData.RssFeedSuggestion;
import Repository.RepositoryInterface;


/**
 * Interface de interaccao com o SGBD
 * @author tgarcia
 *
 */
public interface DBConnection {

	public void addHit(String link, String feedURL, boolean directHit);
	
	public void addHitsToFeed(String feed, boolean directHit);
	
	public boolean containsFeed(String url);
	
	public boolean isFresh(String url, long feedTTL);
	
	public RssFeed getFeed(String id);
	
	public void addFeed(RssFeed feed, boolean directHit);
	
	public void updateFeed(RssFeed feed);
	
	public void addSuggestion(RssFeedSuggestion suggestion, String category);
	
	public ArrayList<HitCount> getHits();
	
	public ArrayList<HitCount> getHits(String url);
	
	public ArrayList<String> getFeedFilterData();
	
	public ArrayList<String> getSuggestionFilterData();
	
	public void setFeedSubscription(String url, boolean isSubscribed);
	
	public ArrayList<RssFeed> getFeeds();
	
	public void init(RepositoryInterface repository);
	
	public ArrayList<RssFeedSuggestion> getRelatedFeedsByCategories(RssFeed feed);
	
	public RssFeedSuggestion getSuggestion(String id);
	
	public ArrayList<RssFeedSuggestion> getSuggestions(RssFeed feed);

}
