package dbConnection;

import java.io.File;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.UUID;

import contentHandler.HitCount;
import contentHandler.feedData.RssFeed;
import contentHandler.feedData.RssItem;
import contentHandler.suggestionData.RssFeedSuggestion;

//import colFeeds.BloomFilter;
import feedProvider.FeedProvider;

import Repository.RepositoryInterface;

/**
 * implementacao da interface de interaccao com o SGBD
 * com recurso a MySQL
 * @author tgarcia
 *
 */
public class MysqlDBConnection implements DBConnection {

	private Connection conn;

	public MysqlDBConnection() {
		super();
	}

	private String getId(String url) {
		try {
			MessageDigest digest = java.security.MessageDigest.getInstance("MD5");
			digest.update(url.getBytes());
			byte[] array = digest.digest();

			String result = new String();
			for (int i=0; i < array.length; i++) {
				result += Integer.toString( ( array[i] & 0xff ) + 0x100, 16).substring( 1 );
			}
			return result;
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			return "";
		} catch (NullPointerException en) {
			//			en.printStackTrace();
			return null;
		}
	}

	private void addLink(String link, String feedId, String itemID, boolean directHit) {
		try {
			PreparedStatement ps = conn.prepareStatement("Insert into HitCount(url, feed, item, directHit, time) VALUES (" +
			"?, ?, ?, ?, ?)");

			ps.setString(1, link);
			ps.setString(2, feedId);
			ps.setString(3, itemID);
			ps.setInt(4, directHit ? 1 : 0);
			ps.setTimestamp(5, new Timestamp(System.currentTimeMillis()));

			ps.execute();
			ps.close();
		} catch (Exception e1) {
			System.err.println("||Error on addLink ||");
			e1.printStackTrace();
		}
	}

	public void addHit(String link, String feedURL, boolean directHit) {
		try {
			PreparedStatement ps = conn.prepareStatement("Insert into HitCount(url, feed, item, directHit, time) VALUES (" +
			"?, ?, ?, ?, ?)");

			ps.setString(1, link);
			ps.setString(2, RssFeed.getFeedId(feedURL));
			ps.setString(3, null);
			ps.setInt(4, directHit ? 1 : 0);
			ps.setTimestamp(5, new Timestamp(System.currentTimeMillis()));

			ps.execute();
			ps.close();
		} catch (Exception e1) {
			System.err.println("||Error on updating HitCount ||");
			e1.printStackTrace();
		}
	}

	public void addHitsToFeed(String feedURL, boolean directHit) {
		String feedId = RssFeed.getFeedId(feedURL);
		try {
			PreparedStatement ps = conn.prepareStatement("Insert into HitCount(url, feed, item, directHit, time) VALUES (" +
			"?, ?, ?, ?, ?)");

			ps.setString(1, feedURL);
			ps.setString(2, feedId);
			ps.setString(3, null);
			ps.setInt(4, directHit ? 1 : 0);
			ps.setTimestamp(5, new Timestamp(System.currentTimeMillis()));

			try
			{
				ps.execute();
				ps.close();
			}
			catch (SQLException e) 
			{
				System.err.println("||Error on updating HitCount ||");
				e.printStackTrace();
			}

			ps = conn.prepareStatement("select Items.id, Items.link, Items.title, Items.description from Items Join FeedsItems on Items.id = FeedsItems.item where FeedsItems.feed = ? order by Items.pubDate DESC");
			ps.setString(1, feedId);
			ResultSet getItemsQuery = ps.executeQuery();
			while (getItemsQuery.next())
			{
				if (getItemsQuery.getString("link") != null)
					addLink(getItemsQuery.getString("link"), feedId, getItemsQuery.getString("id"), false);
			}
			getItemsQuery.close();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}

	public boolean containsFeed(String url) {
		try 
		{
			PreparedStatement ps = conn.prepareStatement("Select * from Feeds where id = ?");
			ps.setString(1, RssFeed.getFeedId(url));
			ResultSet result = ps.executeQuery();
			boolean hasFeed = result.next();
			result.close();
			ps.close();
			return hasFeed;
		}
		catch (Exception e) 
		{
			System.err.println("||Error on containsFeed||");
			e.printStackTrace();
		}
		return false;
	}

	public boolean isFresh(String url, long feedTTL) {
		try 
		{
			PreparedStatement ps = conn.prepareStatement("Select lastUpdate from Feeds where id = ?");
			ps.setString(1, RssFeed.getFeedId(url));
			ResultSet result = ps.executeQuery();
			if (!result.next())
				return false;
			Timestamp dbTimestamp = result.getTimestamp("lastUpdate");
			long sysTimestamp = System.currentTimeMillis();
			result.close();
			ps.close();
			return sysTimestamp < dbTimestamp.getTime()+feedTTL;
		}
		catch (Exception e) 
		{
			System.err.println("||Error on isFresh:||");
			e.printStackTrace();
		}
		return false;
	}


	public RssFeed getFeed(String id) {
		RssFeed result = new RssFeed();
		String feedId = id;
		try 
		{
			PreparedStatement ps = conn.prepareStatement("select * from Feeds where id = ?");
			ps.setString(1, feedId);
			ResultSet getFeedsQuery = ps.executeQuery();
			if (getFeedsQuery.next())
			{
				result.setTitle(getFeedsQuery.getString("title"));
				result.setHeader(getFeedsQuery.getString("header"));
				result.setUrl(getFeedsQuery.getString("url"));
				result.setDescription(getFeedsQuery.getString("description"));
				result.setLink(getFeedsQuery.getString("link"));
				result.setLanguage(getFeedsQuery.getString("language"));
				result.setGenerator(getFeedsQuery.getString("generator"));
				result.setCopyright(getFeedsQuery.getString("copyright"));
				result.setImageUrl(getFeedsQuery.getString("imageUrl"));
				result.setImageTitle(getFeedsQuery.getString("imageTitle"));
				result.setImageLink(getFeedsQuery.getString("imageLink"));
				result.setSubscribed(getFeedsQuery.getInt("isSubscribed") == 1);
				result.setVersion(getFeedsQuery.getString("version"));

				ps = conn.prepareStatement("select * from HitCount where feed = ? and item = 'null'");
				ps.setString(1, feedId);
				ResultSet getFeedHitQuery = ps.executeQuery();
				while (getFeedHitQuery.next())
				{
					result.incDirectHit(getFeedHitQuery.getInt("directHit"));
					result.incIndirectHit(getFeedHitQuery.getInt("indirectHit"));
				}
				getFeedHitQuery.close();

				ps = conn.prepareStatement("select Categories.* from Categories Join FeedsCategories on Categories.id = FeedsCategories.category where FeedsCategories.feed = ?");
				ps.setString(1, feedId);
				ResultSet getCategoriesQuery = ps.executeQuery();
				ArrayList<String> feedCategories = new ArrayList<String>();
				while (getCategoriesQuery.next())
				{
					feedCategories.add(getCategoriesQuery.getString("category"));
				}
				getCategoriesQuery.close();
				result.setCategories(feedCategories);

				ps = conn.prepareStatement("select Items.* from Items Join FeedsItems on Items.id = FeedsItems.item where FeedsItems.feed = ? order by Items.pubDate DESC");
				ps.setString(1, feedId);
				ResultSet getItemsQuery = ps.executeQuery();
				ArrayList<RssItem> feedItems = new ArrayList<RssItem>();
				while (getItemsQuery.next())
				{
					RssItem item = new RssItem();
					item.setTitle(getItemsQuery.getString("title"));
					item.setDescription(getItemsQuery.getString("description"));
					item.setLink(getItemsQuery.getString("link"));
					item.setPubDate(getItemsQuery.getTimestamp("pubDate"));
					item.setAuthor(getItemsQuery.getString("author"));
					item.setComments(getItemsQuery.getString("comments"));
					item.setEnclosure(getItemsQuery.getString("enclosure"));
					item.setGuid(getItemsQuery.getString("guid"));
					item.setSource(getItemsQuery.getString("source"));
					feedItems.add(item);

					ps = conn.prepareStatement("select HitCount.* from HitCount Join Feeds on Feeds.url = HitCount.feed where Feeds.id = ? and HitCount.item = ?");
					ps.setString(1, feedId);
					ps.setString(2, getItemsQuery.getString("id"));

					ResultSet getItemHitQuery = ps.executeQuery();
					while (getItemHitQuery.next())
					{
						if (getItemHitQuery.getInt("directHit") == 1)
							item.incDirectHit();
						else
							item.incIndirectHit();
					}
					getItemHitQuery.close();
				}
				getItemsQuery.close();
				result.setItems(feedItems);
			}
			getFeedsQuery.close();
			ps.close();
		}    
		catch (Exception e) 
		{
			System.err.println("|| Error getting feed from db ||");
		}
		return result;
	}

	public void addFeed(RssFeed feed, boolean directHit) {
		if (conn == null)
			return;
		try 
		{
			String feedUUID = feed.getId();

			PreparedStatement ps = conn.prepareStatement("Select url from Feeds where url =  ?");
			ps.setString(1, feed.getUrl());

			//Detecta se a feed já existe na base de dados
			boolean isInsert = true;
			try
			{
				ResultSet feedIdResult = ps.executeQuery();
				isInsert = !(feedIdResult.next());
				feedIdResult.close();
				ps.close();
			}
			catch (SQLException e) 
			{
				System.err.println("||Error on detecting feed||");
				e.printStackTrace();
			}

			//Insere feed, caso ainda não exista
			if (isInsert)
			{
				ps = conn.prepareStatement("Insert into Feeds(" +
						" id, version, url, header, title, description, link, generator, language, copyright, imageUrl, imageTitle, imageLink, isSubscribed) VALUES ( " +
				"?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

				ps.setString(1, feedUUID);
				ps.setString(2, feed.getVersion());
				ps.setString(3, feed.getUrl());
				ps.setString(4, feed.getHeader());
				ps.setString(5, feed.getTitle());
				ps.setString(6, feed.getDescription());
				ps.setString(7, feed.getLink());
				ps.setString(8, feed.getGenerator());
				ps.setString(9, feed.getLanguage());
				ps.setString(10, feed.getCopyright());
				ps.setString(11, feed.getImageUrl());
				ps.setString(12, feed.getImageTitle());
				ps.setString(13, feed.getImageLink());
				ps.setInt(14, feed.isSubscribed() ? 1 : 0);

				try
				{
					ps.execute();
					ps.close();

				}
				catch (SQLException e) 
				{
					System.err.println("||Error on inserting feed||");
					e.printStackTrace();
				}
			}
			//Actualiza a feed, caso já exista
			else
			{
				ps = conn.prepareStatement("Update Feeds set " +
						"version = ?, header = ?, title = ?, description =  ?, link = ?, generator = ?, language = ?," +
				" copyright = ?, imageUrl = ?, imageTitle = ?, imageLink = ? where id =  ?");

				ps.setString(1, feed.getVersion());
				ps.setString(2, feed.getHeader());
				ps.setString(3, feed.getTitle());
				ps.setString(4, feed.getDescription());
				ps.setString(5, feed.getLink());
				ps.setString(6, feed.getGenerator());
				ps.setString(7, feed.getLanguage());
				ps.setString(8, feed.getCopyright());
				ps.setString(9, feed.getImageUrl());
				ps.setString(10, feed.getImageTitle());
				ps.setString(11, feed.getImageLink());
				ps.setString(12, feedUUID);

				try
				{
					ps.execute();
					ps.close();
				}
				catch (SQLException e) 
				{
					System.err.println("||Error on updating feed||");
					e.printStackTrace();
				}

				//Remove as associações já existentes entre feeds e categorias, para assim tratar de enventuais alterações
				ps = conn.prepareStatement("Delete from FeedsCategories where feed = ?");
				ps.setString(1, feedUUID);

				try
				{
					ps.execute();
					ps.close();
				}
				catch (SQLException e) 
				{
					System.err.println("||Error on removing FeedsCategories relations||");
					e.printStackTrace();
				}
			}

			//Caso a feed tenha categories (keywords), insere-as
			if (feed.getCategories().size() != 0)
			{

				Iterator<String> catIt = feed.getCategories().iterator();
				while (catIt.hasNext())
				{
					String category = catIt.next();
					String catUUID = getId(category);

					ps = conn.prepareStatement("Insert into Categories(id, category) VALUES ( ?, ?)");
					ps.setString(1, catUUID);
					ps.setString(2, category);

					try
					{
						ps.execute();
						ps.close();
					}
					catch (SQLException e) 
					{
					}

					ps = conn.prepareStatement("Insert into FeedsCategories(id, feed, category) VALUES ( ?, ?, ?)");
					ps.setString(1, UUID.randomUUID().toString());
					ps.setString(2, feedUUID);
					ps.setString(3, catUUID);

					try
					{
						ps.execute();
						ps.close();
					}
					catch (SQLException e) 
					{
					}
				}
			}

			//Caso a feed tenha items, insere-as
			if (feed.getItems().size() != 0)
			{
				ArrayList<String> itemList = new ArrayList<String>();
				Iterator<RssItem> itemIt = feed.getItems().iterator();
				while (itemIt.hasNext())
				{
					RssItem item = itemIt.next();

					String itemUUID = getId(item.getLink()+item.getDescription());

					itemList.add(itemUUID);

					ps = conn.prepareStatement("Insert into Items(id, title, link, description, author, comments, enclosure, guid, pubDate, source) VALUES " +
					"( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

					ps.setString(1, itemUUID);
					ps.setString(2, item.getTitle());
					ps.setString(3, item.getLink());
					ps.setString(4, item.getDescription());
					ps.setString(5, item.getAuthor());
					ps.setString(6, item.getComments());
					ps.setString(7, item.getEnclosure());
					ps.setString(8, item.getGuid());
					ps.setTimestamp(9, new Timestamp(item.getPubDate().getTime()));
					ps.setString(10, item.getSource());

					try
					{
						ps.execute();
						ps.close();
					}
					catch (Exception e) 
					{
						if (!e.getMessage().contains("Duplicate entry"))
							e.printStackTrace();
					}

					Iterator<String> catIt = item.getCategories().iterator();
					while (catIt.hasNext())
					{
						String category = catIt.next();
						String catUUID = getId(category);

						ps = conn.prepareStatement("Insert into Categories(id, category) VALUES ( ?, ?)");
						ps.setString(1, catUUID);
						ps.setString(2, category);

						try
						{
							ps.execute();
							ps.close();
						}
						catch (SQLException e) 
						{
							if (!e.getMessage().contains("Duplicate entry"))
								e.printStackTrace();
						}

						ps = conn.prepareStatement("Insert into ItemsCategories(id, item, category) VALUES ( ?, ?, ?)");
						ps.setString(1, UUID.randomUUID().toString());
						ps.setString(2, itemUUID);
						ps.setString(3, catUUID);

						try
						{
							ps.execute();
							ps.close();
						}
						catch (SQLException e) 
						{
							if (!e.getMessage().contains("Duplicate entry"))
							{
								System.err.println("||Error on adding ItemsCategories relations||");
								e.printStackTrace();
							}
						}
					}

					ps = conn.prepareStatement("Insert into FeedsItems(id, feed, item, valid) VALUES " +
					"( ?, ?, ?, 1)");

					ps.setString(1, UUID.randomUUID().toString());
					ps.setString(2, feedUUID);
					ps.setString(3, itemUUID);

					try
					{
						ps.execute();
						ps.close();
					}
					catch (SQLException e) 
					{
						//				    	System.err.println("||Error on adding FeedsItems relations, possibly already exists||");
						//					    e.printStackTrace();
					}
				}
				String updateOldItemsQuery = new String("Update FeedsItems set valid = 0 where feed = '" +feedUUID
						+ "' and valid = 1 and item not in (");

				Iterator<String> itemUUIDIt = itemList.iterator();
				while (itemUUIDIt.hasNext())
				{
					updateOldItemsQuery += "'" + itemUUIDIt.next() + "' ,";
				}
				updateOldItemsQuery = updateOldItemsQuery.substring(0, updateOldItemsQuery.length()-1);
				updateOldItemsQuery += ")";
				Statement st = conn.createStatement();
				try
				{
					st.execute(updateOldItemsQuery);
					st.close();
				}
				catch (SQLException e) 
				{
					System.err.println("||Error updating old items||");
					e.printStackTrace();
				}
			}
			try{
				ps.close();
			}
			catch (Exception e) {
			}
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

	public void updateFeed(RssFeed feed) {
		if (conn == null)
			return;
		String feedUUID = feed.getId();
		try 
		{
			PreparedStatement ps = conn.prepareStatement("Select * from Feeds where id = ?");
			ps.setString(1, feedUUID);

			//Detecta se a feed já existe na base de dados
			boolean isInsert = true;
			try
			{
				ResultSet feedIdResult = ps.executeQuery();
				isInsert = !(feedIdResult.next());
				feedIdResult.close();
				ps.close();
			}
			catch (SQLException e) 
			{
				System.err.println("||Error on detecting feed||");
				e.printStackTrace();
			}

			//Insere feed, caso ainda não exista
			if (isInsert)
			{
				System.err.println("||Warning: Trying to update a non existent feed from LiveFeeds.\n" +
						" This might have been triggered by a false positive from LiveFeeds," +
						"or might just be a nasty bug...||");
			}
			//Actualiza a feed, caso já exista
			else
			{
				ps = conn.prepareStatement("Update Feeds set " +
						"version = ?, header = ?, title = ?, description =  ?, link = ?, generator = ?, language = ?," +
				" copyright = ?, imageUrl = ?, imageTitle = ?, imageLink = ? , lastUpdate = ? where id =  ?");

				ps.setString(1, feed.getVersion());
				ps.setString(2, feed.getHeader());
				ps.setString(3, feed.getTitle());
				ps.setString(4, feed.getDescription());
				ps.setString(5, feed.getLink());
				ps.setString(6, feed.getGenerator());
				ps.setString(7, feed.getLanguage());
				ps.setString(8, feed.getCopyright());
				ps.setString(9, feed.getImageUrl());
				ps.setString(10, feed.getImageTitle());
				ps.setString(11, feed.getImageLink());
				ps.setTimestamp(12, new Timestamp(feed.getLastUpdated().getTime()));
				ps.setString(13, feedUUID);

				try
				{
					ps.execute();
					ps.close();
				}
				catch (SQLException e) 
				{
					System.err.println("||Error on updating feed||");
					e.printStackTrace();
				}

				//Remove as associações já existentes entre feeds e categorias, para assim tratar de enventuais alterações
				ps = conn.prepareStatement("Delete from FeedsCategories where feed = ?");
				ps.setString(1, feedUUID);

				try
				{
					ps.execute();
					ps.close();
				}
				catch (SQLException e) 
				{
					System.err.println("||Error on removing FeedsCategories relations||");
					e.printStackTrace();
				}
			}

			//Caso a feed tenha categories (keywords), insere-as
			if (feed.getCategories().size() != 0)
			{

				Iterator<String> catIt = feed.getCategories().iterator();
				while (catIt.hasNext())
				{
					String category = catIt.next();

					String catUUID = getId(category);

					ps = conn.prepareStatement("Insert into Categories(id, category) VALUES ( ?, ?)");
					ps.setString(1, catUUID);
					ps.setString(2, category);

					try
					{
						ps.execute();
						ps.close();
					}
					catch (SQLException e) 
					{
						if (!e.getMessage().contains("Duplicate entry"))
							e.printStackTrace();
					}

					ps = conn.prepareStatement("Insert into FeedsCategories(id, feed, category) VALUES ( ?, ?, ?)");
					ps.setString(1, UUID.randomUUID().toString());
					ps.setString(2, feedUUID);
					ps.setString(3, catUUID);

					try
					{
						ps.execute();
						ps.close();
					}
					catch (SQLException e) 
					{
						System.err.println("||Error on adding FeedsCategories relations||");
						e.printStackTrace();
					}
				}
			}

			//Caso a feed tenha items, insere-as
			if (feed.getItems().size() != 0)
			{
				ArrayList<String> itemList = new ArrayList<String>();
				Iterator<RssItem> itemIt = feed.getItems().iterator();
				while (itemIt.hasNext())
				{
					RssItem item = itemIt.next();

					String itemUUID = getId(item.getLink()+item.getDescription());
					itemList.add(itemUUID);

					ps = conn.prepareStatement("Insert into Items(id, title, link, description, author, comments, enclosure, guid, pubDate, source) VALUES " +
					"( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

					ps.setString(1, itemUUID);
					ps.setString(2, item.getTitle());
					ps.setString(3, item.getLink());
					ps.setString(4, item.getDescription());
					ps.setString(5, item.getAuthor());
					ps.setString(6, item.getComments());
					ps.setString(7, item.getEnclosure());
					ps.setString(8, item.getGuid());
					ps.setTimestamp(9, new Timestamp(item.getPubDate().getTime()));
					ps.setString(10, item.getSource());

					try
					{
						ps.execute();
						ps.close();

						//Actualiza os hits para o url do item e os urls contidos na sua descrição
						if (item.getLink() != null)
							addLink(item.getLink(), feedUUID, itemUUID, false);
					}
					catch (Exception e) 
					{
						if (!e.getMessage().contains("Duplicate entry"))
						{
							System.err.println("||Error on adding item||");
							e.printStackTrace();
						}
					}

					Iterator<String> catIt = item.getCategories().iterator();
					while (catIt.hasNext())
					{
						String category = catIt.next();
						String catUUID = getId(category);

						ps = conn.prepareStatement("Insert into Categories(id, category) VALUES ( ?, ?)");
						ps.setString(1, catUUID);
						ps.setString(2, category);

						try
						{
							ps.execute();
							ps.close();
						}
						catch (SQLException e) 
						{
							if (!e.getMessage().contains("Duplicate entry"))
								e.printStackTrace();
						}

						ps = conn.prepareStatement("Insert into ItemsCategories(id, item, category) VALUES ( ?, ?, ?)");
						ps.setString(1, UUID.randomUUID().toString());
						ps.setString(2, itemUUID);
						ps.setString(3, catUUID);

						try
						{
							ps.execute();
							ps.close();
						}
						catch (SQLException e) 
						{
							if (!e.getMessage().contains("Duplicate entry"))
							{
								System.err.println("||Error on adding ItemsCategories relations||");
								e.printStackTrace();
							}
						}
					}

					ps = conn.prepareStatement("Insert into FeedsItems(id, feed, item, valid) VALUES " +
					"( ?, ?, ?, 0)");

					ps.setString(1, UUID.randomUUID().toString());
					ps.setString(2, feedUUID);
					ps.setString(3, itemUUID);

					try
					{
						ps.execute();
						ps.close();
					}
					catch (SQLException e) 
					{
						if (!e.getMessage().contains("Duplicate entry"))
						{
							System.err.println("||Error on adding FeedsItems relations||");
							e.printStackTrace();
						}
					}
				}
				String updateOldItemsQuery = new String("Update FeedsItems set valid = 0 where feed = '" +feedUUID
						+ "' and valid = 1 and item not in (");

				Iterator<String> itemUUIDIt = itemList.iterator();
				boolean hasElements = false;
				while (itemUUIDIt.hasNext())
				{
					hasElements = true;
					updateOldItemsQuery += "'" + itemUUIDIt.next() + "' ,";
				}
				if (hasElements)
					updateOldItemsQuery = updateOldItemsQuery.substring(0, updateOldItemsQuery.length()-1);
				updateOldItemsQuery += ")";
				Statement st = conn.createStatement();
				try
				{
					st.execute(updateOldItemsQuery);
					st.close();
				}
				catch (SQLException e) 
				{
					System.err.println("||Error updating old items||");
					System.err.println(updateOldItemsQuery);
					e.printStackTrace();
				}
			}
			ps.close();
		}
		catch (Exception e) 
		{
			System.err.println("||Error updating feed||");
			e.printStackTrace();
		}
	}

	public ArrayList<HitCount> getHits() {
		ArrayList<HitCount> result = new ArrayList<HitCount>();
		try 
		{
			PreparedStatement ps = conn.prepareStatement("select * from HitCount");
			ResultSet getHitsQuery = ps.executeQuery(); 
			while (getHitsQuery.next())
			{
				HitCount hit = new HitCount();

				hit.setUrl(getHitsQuery.getString("url"));
				hit.setFeed(getHitsQuery.getString("feed"));
				hit.setItem(getHitsQuery.getString("item"));
				hit.setDirectHit(getHitsQuery.getInt("directHit") == 1);
				hit.setTime(getHitsQuery.getTimestamp("time"));
				result.add(hit);
			}
			ps.close();
			getHitsQuery.close();
		}    
		catch (Exception e) 
		{
			e.printStackTrace();
			System.err.println("|| Error getting feeds from db ||");
		}
		return result;
	}

	public ArrayList<HitCount> getHits(String url) {
		ArrayList<HitCount> result = new ArrayList<HitCount>();
		try 
		{
			PreparedStatement ps = conn.prepareStatement("select * from HitCount where url = ?");
			ps.setString(1, url);
			ResultSet getHitsQuery = ps.executeQuery(); 
			while (getHitsQuery.next())
			{
				HitCount hit = new HitCount();

				hit.setUrl(getHitsQuery.getString("url"));
				hit.setFeed(getHitsQuery.getString("feed"));
				hit.setItem(getHitsQuery.getString("item"));
				hit.setDirectHit(getHitsQuery.getInt("directHit") == 1);
				hit.setTime(getHitsQuery.getTimestamp("time"));
				result.add(hit);
			}
			ps.close();
			getHitsQuery.close();
		}    
		catch (Exception e) 
		{
			e.printStackTrace();
			System.err.println("||Error getting hits from db||");
		}
		return result;
	}

	public ArrayList<String> getFeedFilterData() {
		ArrayList<String> feedList = new ArrayList<String>();
		try 
		{
			PreparedStatement ps = conn.prepareStatement("select url from Feeds where isSubscribed != 0");
			ResultSet getFeedsQuery = ps.executeQuery();
			while (getFeedsQuery.next())
			{
				feedList.add(getFeedsQuery.getString("url"));
			}

			getFeedsQuery.close();
			ps.close();
		}    
		catch (Exception e) 
		{
			e.printStackTrace();
			System.err.println("|| Error getting filter data from db ||");
		}
		return feedList;
	}

	public ArrayList<String> getSuggestionFilterData() {
		ArrayList<String> categoriesList = new ArrayList<String>();
		try 
		{
			PreparedStatement ps = conn.prepareStatement("select Categories.category from Feeds Join FeedsCategories On Feeds.id = FeedsCategories.feed" +
			" Join Categories On FeedsCategories.category = Categories.id where Feeds.isSubscribed != 0 Group by Categories.category");
			ResultSet getFeedsQuery = ps.executeQuery();
			while (getFeedsQuery.next())
			{
				categoriesList.add(getFeedsQuery.getString("category"));
			}


			getFeedsQuery.close();
			ps.close();
		}    
		catch (Exception e) 
		{
			e.printStackTrace();
			System.err.println("|| Error getting filter data from db ||");
		}
		return categoriesList;
	}

	public void setFeedSubscription(String url, boolean isSubscribed) {
		try
		{
			PreparedStatement ps = conn.prepareStatement("Update Feeds set " +
			"isSubscribed = ? where id =  ?");

			ps.setInt(1, isSubscribed ? 1 : 0);
			ps.setString(2, RssFeed.getFeedId(url));

			try
			{
				ps.execute();
				ps.close();
			}
			catch (SQLException e) 
			{
				System.err.println("||Error on updating feed subscription status||");
				e.printStackTrace();
			}
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

	public ArrayList<RssFeed> getFeeds() {
		ArrayList<RssFeed> result = new ArrayList<RssFeed>();
		try
		{
			PreparedStatement ps = conn.prepareStatement("select * from Feeds");
			ResultSet getFeedsQuery = ps.executeQuery();
			while (getFeedsQuery.next())
			{
				RssFeed feed = new RssFeed();

				feed.setTitle(getFeedsQuery.getString("title"));
				feed.setHeader(getFeedsQuery.getString("header"));
				feed.setDescription(getFeedsQuery.getString("description"));
				feed.setUrl(getFeedsQuery.getString("url"));
				feed.setLink(getFeedsQuery.getString("link"));
				feed.setLanguage(getFeedsQuery.getString("language"));
				feed.setGenerator(getFeedsQuery.getString("generator"));
				feed.setCopyright(getFeedsQuery.getString("copyright"));
				feed.setImageUrl(getFeedsQuery.getString("imageUrl"));
				feed.setImageTitle(getFeedsQuery.getString("imageTitle"));
				feed.setImageLink(getFeedsQuery.getString("imageLink"));
				feed.setSubscribed(getFeedsQuery.getInt("isSubscribed") == 1);
				feed.setVersion(getFeedsQuery.getString("version"));
				feed.setLastUpdated(getFeedsQuery.getTimestamp("lastUpdate"));

				String feedUUID = RssFeed.getFeedId(getFeedsQuery.getString("url"));

				ps = conn.prepareStatement("select * from HitCount where feed = ? and item = 'null'");
				ps.setString(1, feedUUID);
				ResultSet getFeedHitQuery = ps.executeQuery();

				while (getFeedHitQuery.next())
				{
					feed.incDirectHit(getFeedHitQuery.getInt("directHit"));
					feed.incIndirectHit(getFeedHitQuery.getInt("indirectHit"));
				}
				getFeedHitQuery.close();

				ps = conn.prepareStatement("select Categories.* from Categories Join FeedsCategories on Categories.id = FeedsCategories.category where FeedsCategories.feed = ?");
				ps.setString(1, feedUUID);
				ResultSet getCategoriesQuery = ps.executeQuery();
				ArrayList<String> feedCategories = new ArrayList<String>();
				while (getCategoriesQuery.next())
				{
					feedCategories.add(getCategoriesQuery.getString("category"));
				}
				getCategoriesQuery.close();
				feed.setCategories(feedCategories);

				ps = conn.prepareStatement("select Items.* from Items Join FeedsItems on Items.id = FeedsItems.item where FeedsItems.feed = ?");
				ps.setString(1, feedUUID);
				ResultSet getItemsQuery = ps.executeQuery();
				ArrayList<RssItem> feedItems = new ArrayList<RssItem>();
				while (getItemsQuery.next())
				{
					RssItem item = new RssItem();
					item.setTitle(getItemsQuery.getString("title"));
					item.setDescription(getItemsQuery.getString("description"));
					item.setLink(getItemsQuery.getString("link"));
					item.setPubDate(getItemsQuery.getTimestamp("pubDate"));
					item.setAuthor(getItemsQuery.getString("author"));
					item.setComments(getItemsQuery.getString("comments"));
					item.setEnclosure(getItemsQuery.getString("enclosure"));
					item.setGuid(getItemsQuery.getString("guid"));
					item.setSource(getItemsQuery.getString("source"));
					feedItems.add(item);

					String itemUUID = getId(item.getLink()+item.getDescription());

					ps = conn.prepareStatement("select HitCount.* from HitCount Join Feeds on Feeds.url = HitCount.feed where Feeds.url = ? and HitCount.item = ?");
					ps.setString(1, feedUUID);
					ps.setString(2, itemUUID);
					ResultSet getItemHitQuery = ps.executeQuery();
					while (getItemHitQuery.next())
					{
						System.err.println("|| Doing hits on getFeeds ||");
						item.incDirectHit(getItemHitQuery.getInt("directHit"));
						item.incIndirectHit(getItemHitQuery.getInt("indirectHit"));
					}
					getItemHitQuery.close();
				}
				getItemsQuery.close();
				feed.setItems(feedItems);
				result.add(feed);
			}
			getFeedsQuery.close();
			ps.close();
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
			System.err.println("||Error getting feeds from db||");
		}
		return result;
	}

	@Override
	public ArrayList<RssFeedSuggestion> getRelatedFeedsByCategories(RssFeed feed) {
		String getFeedsQuery = "";
		try
		{
			Statement st = conn.createStatement();

			getFeedsQuery = new String("Select distinct Feeds.id from Feeds join FeedsCategories on Feeds.id = FeedsCategories.feed join Categories on Categories.id = FeedsCategories.category " +
					"where Feeds.isSubscribed = 0 and Feeds.id != '" + feed.getId() + "'");

			if (feed.getCategories().size() != 0)
			{
				getFeedsQuery += "and Categories.category in (";
				Iterator<String> categoriesIt = feed.getCategories().iterator();
				boolean hasElements = false;
				while (categoriesIt.hasNext())
				{
					hasElements = true;
					getFeedsQuery += "'" + categoriesIt.next() + "' ,";
				}
				if (hasElements)
					getFeedsQuery = getFeedsQuery.substring(0, getFeedsQuery.length()-1);
				getFeedsQuery += ")";
			}
			ResultSet getFeedsQueryResult = st.executeQuery(getFeedsQuery);
			ArrayList<RssFeedSuggestion> feeds = new ArrayList<RssFeedSuggestion>();
			while (getFeedsQueryResult.next())
			{
				feeds.add(new RssFeedSuggestion(getFeed(getFeedsQueryResult.getString("id"))));
			}
			st.close();

			return feeds;
		}
		catch (SQLException e) 
		{
			System.err.println("||Error getting feeds by categories||");
			System.err.println(getFeedsQuery);
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void addSuggestion(RssFeedSuggestion suggestion, String category) {
		try
		{
			PreparedStatement ps = conn.prepareStatement("Insert into Suggestions(" +
					" id, url, title, description, link) VALUES ( " +
			"?, ?, ?, ?, ?)");

			ps.setString(1, getId(suggestion.getUrl()));
			ps.setString(2, suggestion.getUrl());
			ps.setString(3, suggestion.getTitle());
			ps.setString(4, suggestion.getDescription());
			ps.setString(5, suggestion.getLink());
			try
			{
				ps.execute();
			}
			catch (SQLException e) 
			{
				if (e.getMessage().contains("Duplicate entry"))
					System.err.println("Suggestions already created");
				else
					e.printStackTrace();
			}

			ps = conn.prepareStatement("Insert into SuggestionsCategories(" +
					" id, suggestion, category) VALUES ( " +
			"?, ?, ?)");

			ps.setString(1, UUID.randomUUID().toString());
			ps.setString(2, getId(suggestion.getUrl()));
			ps.setString(3, getId(category));

			try
			{
				ps.execute();
				ps.close();
			}
			catch (SQLException e) 
			{
				if (e.getMessage().contains("Duplicate entry"))
					System.err.println("Suggestions relation to category already created");
				else
					e.printStackTrace();
			}
		}
		catch (SQLException e) 
		{
			System.err.println("||Error inserting suggestions||");
			//	    	if (e.getMessage().contains("already exists"))
			//	    		System.err.println("Suggestions already created");
			//	    	else
			//	    		e.printStackTrace();
		}
	}

	public RssFeedSuggestion getSuggestion(String id) {
		RssFeedSuggestion result = new RssFeedSuggestion();
		try 
		{
			PreparedStatement ps = conn.prepareStatement("select * from Suggestions where id = ?");
			ps.setString(1, id);
			ResultSet getFeedsQuery = ps.executeQuery();
			if (getFeedsQuery.next())
			{
				result.setTitle(getFeedsQuery.getString("title"));
				result.setUrl(getFeedsQuery.getString("url"));
				result.setDescription(getFeedsQuery.getString("description"));
				result.setLink(getFeedsQuery.getString("link"));
			}
		} catch (SQLException e) 
		{
			System.err.println("||Error getting suggestion||");
			e.printStackTrace();
		}
		return result;
	}


	@Override
	public ArrayList<RssFeedSuggestion> getSuggestions(RssFeed feed) {
		if (feed.getCategories().size() == 0)
			return new ArrayList<RssFeedSuggestion>();

		String getFeedsQuery = "";
		try
		{
			Statement st = conn.createStatement();
			getFeedsQuery = new String("Select distinct SuggestionsCategories.suggestion from Categories Join SuggestionsCategories on Categories.id = SuggestionsCategories.category " +
					" Left join Feeds on SuggestionsCategories.suggestion = Feeds.id " +
					"where Feeds.id is null and " +
			"Categories.category in (");

			Iterator<String> categoriesIt = feed.getCategories().iterator();
			while (categoriesIt.hasNext())
				getFeedsQuery += "'" + categoriesIt.next() + "' ,";
			getFeedsQuery = getFeedsQuery.substring(0, getFeedsQuery.length()-1);
			getFeedsQuery += ") group by SuggestionsCategories.suggestion";

			ResultSet getFeedsQueryResult = st.executeQuery(getFeedsQuery);

			ArrayList<RssFeedSuggestion> suggestions = new ArrayList<RssFeedSuggestion>();
			while (getFeedsQueryResult.next())
			{
				suggestions.add(getSuggestion(getFeedsQueryResult.getString("suggestion")));
			}
			st.close();

			return suggestions;
		}
		catch (SQLException e) 
		{
			System.err.println("||Error getting suggestions||");
			System.err.println(getFeedsQuery);
			e.printStackTrace();
		}
		return null;
	}

	public void init(RepositoryInterface repository)
	{
		//		RepositoryInterface repository = (RepositoryInterface) context.getAttribute("(RepositoryInterface) context.getAttribute("repository");");
		File dummyFile = repository.getFile("dummy.file");
		if(dummyFile == null)
			dummyFile = repository.newFile("dummy.file");

		String driver = "com.mysql.jdbc.Driver";
		String connectionURL = "jdbc:mysql://localhost:3306/"+ FeedProvider.dbName +"?user="+ FeedProvider.dbUser + "&password=" + FeedProvider.dbPassword;

		try{
			Class.forName(driver); 
		} 
		catch(java.lang.ClassNotFoundException e) {
			e.printStackTrace();
		}

		try 
		{
			try
			{
				conn = (Connection) DriverManager.getConnection(connectionURL);
			} catch (Exception e) {
				Class.forName("com.mysql.jdbc.Driver");
				conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql?user="+ FeedProvider.dbUser + "&password=" + FeedProvider.dbPassword);
				Statement st = conn.createStatement();
				st.executeUpdate("CREATE DATABASE "+ FeedProvider.dbName);
				
				conn.close();
				conn = DriverManager.getConnection(connectionURL);
			}
			Statement st = conn.createStatement();

			try
			{
				st.execute("create table Feeds("+
						"id VARCHAR(36) not null,"+
						"version VARCHAR(10)," +
						"url VARCHAR(1024) not null,"+
						"header VARCHAR(1024),"+
						"title VARCHAR(1024),"+
						"description TEXT,"+
						"link VARCHAR(1024),"+
						"generator VARCHAR(1024),"+
						"language VARCHAR(10),"+
						"copyright VARCHAR(1024),"+
						"imageUrl VARCHAR(1024),"+
						"imageTitle VARCHAR(1024),"+
						"imageLink VARCHAR(1024),"+
						"isSubscribed TINYINT default 0,"+
						"lastUpdate TIMESTAMP default CURRENT_TIMESTAMP"
						+", PRIMARY KEY (id)"
						+ ")");
			}
			catch (SQLException e) 
			{
				if (e.getMessage().contains("already exists"))
					System.err.println("Feeds table already created");
				else
					e.printStackTrace();
			}

			try
			{
				st.execute("create table Items("+
						"id VARCHAR(36) not null,"+
						"title VARCHAR(1024),"+
						"link VARCHAR(1024),"+
						"description TEXT,"+
						"author VARCHAR(1024),"+
						"comments VARCHAR(1024),"+
						"enclosure VARCHAR(1024),"+
						"guid VARCHAR(1024),"+
						"pubDate TIMESTAMP,"+
						"source VARCHAR(1024)"
						+", PRIMARY KEY (id)"
						+ ")");
			}
			catch (SQLException e) 
			{
				if (e.getMessage().contains("already exists"))
					System.err.println("Items table already created");
				else
					e.printStackTrace();
			}

			try
			{
				st.execute("create table Categories("+
						"id VARCHAR(36) not null,"+
						"category VARCHAR(1024) not null"
						//		    		    +", UNIQUE (category)"
						+ ", PRIMARY KEY (id)"
						+ ")");
			}
			catch (SQLException e) 
			{
				if (e.getMessage().contains("already exists"))
					System.err.println("Categories table already created");
				else
					e.printStackTrace();
			}

			try
			{
				st.execute("create table FeedsCategories("+
						"id VARCHAR(36) not null,"+
						"feed VARCHAR(36) not null,"+
						"category VARCHAR(36) not null"
						+",PRIMARY KEY (id),"+
						"CONSTRAINT no_repeats_fc UNIQUE (feed,category)"
						+", FOREIGN KEY (feed) REFERENCES Feeds(id),"+
						"FOREIGN KEY (category) REFERENCES Categories(id)"
						+ ")");

			}
			catch (SQLException e) 
			{
				if (e.getMessage().contains("already exists"))
					System.err.println("Feeds-Categories table already created");
				else
					e.printStackTrace();
			}

			try
			{
				st.execute("create table FeedsItems("+
						"id VARCHAR(36) not null,"+
						"feed VARCHAR(36) not null,"+
						"item VARCHAR(36) not null,"+
						"valid SMALLINT not null default 1"
						+", PRIMARY KEY (id)"
						+", CONSTRAINT no_repeats_fi UNIQUE (feed,item)"
						+", FOREIGN KEY (feed) REFERENCES Feeds(id)"
						+", FOREIGN KEY (item) REFERENCES Items(id)"
						+ ")");
			}
			catch (SQLException e) 
			{
				if (e.getMessage().contains("already exists"))
					System.err.println("Feeds-Items table already created");
				else
					e.printStackTrace();
			}

			try
			{
				st.execute("create table ItemsCategories("+
						"id VARCHAR(36) not null,"+
						"item VARCHAR(36) not null,"+
						"category VARCHAR(36) not null"
						+",PRIMARY KEY (id),"+
						"CONSTRAINT no_repeats_ic UNIQUE (item,category)"
						+", FOREIGN KEY (item) REFERENCES Items(id),"+
						"FOREIGN KEY (category) REFERENCES Categories(id)"
						+ ")");
			}
			catch (SQLException e) 
			{
				if (e.getMessage().contains("already exists"))
					System.err.println("Item-Category table already created");
				else
					e.printStackTrace();
			}

			try
			{
				st.execute("create table HitCount("+
						"url VARCHAR(1024) not null,"+
						"feed VARCHAR(1024),"+
						"item VARCHAR(36),"+
						"directHit SMALLINT not null, " +
						"time TIMESTAMP not null"
						+", FOREIGN KEY (feed) REFERENCES Feeds(id)"
						+ ")");
			}
			catch (SQLException e) 
			{
				if (e.getMessage().contains("already exists"))
					System.err.println("HitCount table already created");
				else
					e.printStackTrace();
			}

			try
			{
				st.execute("create table Suggestions("+
						"id VARCHAR(36) not null,"+
						"url VARCHAR(1024) not null,"+
						"title VARCHAR(1024),"+
						"description TEXT,"+
						"link VARCHAR(1024),"
						+"PRIMARY KEY (id)"
						+ ")");
			}
			catch (SQLException e) 
			{
				if (e.getMessage().contains("already exists"))
					System.err.println("Suggestions table already created");
				else
					e.printStackTrace();
			}

			try
			{
				st.execute("create table SuggestionsCategories("+
						"id VARCHAR(36) not null,"+
						"suggestion VARCHAR(36) not null,"+
						"category VARCHAR(36) not null"
						+",PRIMARY KEY (id),"+
						"CONSTRAINT no_repeats_sc UNIQUE (suggestion,category)"
						+", FOREIGN KEY (suggestion) REFERENCES Suggestions(id),"+
						"FOREIGN KEY (category) REFERENCES Categories(id)"
						+ ")");

			}
			catch (SQLException e) 
			{
				if (e.getMessage().contains("already exists"))
					System.err.println("Suggestions-Categories table already created");
				else
					e.printStackTrace();
			}

			st.close();
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

}
