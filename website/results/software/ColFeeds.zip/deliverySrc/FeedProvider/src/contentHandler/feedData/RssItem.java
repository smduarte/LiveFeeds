package contentHandler.feedData;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

/**
 * Item/noticia pertencente a uma feed
 * 
 * @author tgarcia
 *
 */
public class RssItem implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	private int directHit = 0;
	private int indirectHit = 0;
	
	private String title = new String();
    private String description = new String();
    private String link = new String();
    private Date pubDate = new Date(System.currentTimeMillis());
    private String author = new String();
    private String comments = new String();
    private String enclosure = new String();
    private String guid = new String();
    private String source = new String();
    		
    private ArrayList <String> category = new ArrayList<String>();
    
   
    public String toString()
    {
        return (this.title + ": " + this.pubDate + "n" + this.description);
    }

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public Date getPubDate() {
		return pubDate;
	}
	
	public String getPubDateString() {
		SimpleDateFormat dateformat = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss ZZZ", Locale.ENGLISH);
		return new StringBuilder(dateformat.format( pubDate )).toString();
	}

	public void setPubDate(String pubDate) {
		try {
			DateFormat formatter = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss ZZZ", Locale.ENGLISH);
			Date date = formatter.parse(pubDate);
			this.pubDate = date;
		} catch (ParseException e) {
//			e.printStackTrace();
//			System.err.println("Warning - Erro ao processar a data. Utilizando a actual...");
			this.pubDate = new Date(System.currentTimeMillis());
		}
	}
	
	public void setPubDate(Date pubDate) {
		this.pubDate = pubDate;
	}
	
	public void addCategory(String category) {
		this.category.add(category);
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getEnclosure() {
		return enclosure;
	}

	public void setEnclosure(String enclosure) {
		this.enclosure = enclosure;
	}

	public String getGuid() {
		return guid;
	}

	public void setGuid(String guid) {
		this.guid = guid;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public ArrayList<String> getCategories() {
		return category;
	}

	public void setCategories(ArrayList<String> categories) {
		this.category = categories;
	}
    
	public int getDirectHit() {
		return directHit;
	}

	public void incDirectHit(int hitCount) {
		this.directHit += hitCount;
	}
	
	public void incDirectHit() {
		this.directHit++;
	}

	public int getIndirectHit() {
		return indirectHit;
	}

	public void incIndirectHit(int hitCount) {
		this.indirectHit += hitCount;
	}
	
	public void incIndirectHit() {
		this.indirectHit++;
	}
	
}