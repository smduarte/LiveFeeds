package contentHandler;

import java.util.Date;

/**
 * Contabilizacao de hits, utilizados para inferencia de interesses, etc
 * 
 * @author tgarcia
 *
 */
public class HitCount {
	private String url;
	private String feed;
	private String item;
	private boolean directHit;
	private Date time;
	
	public HitCount() {
		super();
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getFeed() {
		return feed;
	}

	public void setFeed(String feed) {
		this.feed = feed;
	}

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public boolean isDirectHit() {
		return directHit;
	}

	public void setDirectHit(boolean directHit) {
		this.directHit = directHit;
	}

	public Date getTime() {
		return time;
	}

	public void setTime(Date time) {
		this.time = time;
	}
	
}
