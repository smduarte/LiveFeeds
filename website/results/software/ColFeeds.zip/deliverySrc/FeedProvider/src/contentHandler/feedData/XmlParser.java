package contentHandler.feedData;

import java.io.InputStream;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Parser que recebe o texto em xml correspondente a uma feed e 
 * cria os diversos objectos com a informacao nela contida
 * 
 * @author tgarcia
 *
 */
public class XmlParser extends DefaultHandler
{  
	private RssFeed rssFeed;
	private String header = new String();
	private StringBuilder text;
	private RssItem item;
	private boolean imgStatus;

	public XmlParser ()
	{
		this.text = new StringBuilder();
	}

	public RssFeed parse(InputStream content, String urlContent) throws Exception
	{
		SAXParserFactory spf = null;
		SAXParser sp = null;

		try
		{
			spf = SAXParserFactory.newInstance();
			if (spf != null)
			{
				sp = spf.newSAXParser();
				sp.parse(content, this);
			}
			rssFeed.setUrl(urlContent);
			return rssFeed;
		}
		catch (Exception e)
		{
			throw e;
		}
		finally
		{
			try
			{
				if (content != null)
					content.close();
			}
			catch (Exception e) {}
		}
		
		
	}

	public void startElement(String uri, String localName, String qName,
			Attributes attributes)
	{
		if (qName.equalsIgnoreCase("rss"))
		{
			this.rssFeed = new RssFeed();
			 for (int i = 0; i < attributes.getLength(); i++)
             {
                 if ( attributes.getQName(i).toLowerCase().equals("version"))
                	 rssFeed.setVersion(attributes.getValue(i));
                 else
                	 header += attributes.getQName(i) + "=\"" + attributes.getValue(i) + "\" ";
             }
		}
		else if (qName.equalsIgnoreCase("item") && (this.rssFeed != null))
		{
			this.item = new RssItem();
			this.rssFeed.addItem(this.item);
		}
		else if (qName.equalsIgnoreCase("image") && (this.rssFeed != null))
			this.imgStatus = true;
	}

	public void endElement(String uri, String localName, String qName)
	{
		if (this.rssFeed == null)
			return;

		if (qName.equalsIgnoreCase("item"))
			this.item = null;

		else if (qName.equalsIgnoreCase("rss"))
			rssFeed.setHeader(header);

		else if (qName.equalsIgnoreCase("image"))
			this.imgStatus = false;

		else if (qName.equalsIgnoreCase("title"))
		{
			if (this.item != null)
				this.item.setTitle(this.text.toString().trim());
			else if (this.imgStatus) 
				this.rssFeed.setImageTitle(this.text.toString().trim());
			else 
				this.rssFeed.setTitle(this.text.toString().trim());
		}       

		else if (qName.equalsIgnoreCase("link"))
		{
			if (this.item != null) 
				this.item.setLink(this.text.toString().trim());
			else if (this.imgStatus) 
				this.rssFeed.setImageLink(this.text.toString().trim());
			else 
				this.rssFeed.setLink(this.text.toString().trim());
		}

		else if (qName.equalsIgnoreCase("description"))
		{
			if (this.item != null) 
				this.item.setDescription(this.text.toString().trim());
			else 
				this.rssFeed.setDescription(this.text.toString().trim());
		}
		
		else if (qName.equalsIgnoreCase("url") && this.imgStatus)
			this.rssFeed.setImageUrl(this.text.toString().trim());

		else if (qName.equalsIgnoreCase("language"))
			this.rssFeed.setLanguage(this.text.toString().trim());

		else if (qName.equalsIgnoreCase("generator"))
			this.rssFeed.setGenerator(this.text.toString().trim());

		else if (qName.equalsIgnoreCase("copyright"))
			this.rssFeed.setCopyright(this.text.toString().trim());

		else if (qName.equalsIgnoreCase("pubDate") && (this.item != null))
			this.item.setPubDate(this.text.toString().trim());
		
		else if (qName.equalsIgnoreCase("guid") && (this.item != null))
			this.item.setGuid(this.text.toString().trim());
		
		else if (qName.equalsIgnoreCase("author") && (this.item != null))
			this.item.setAuthor(this.text.toString().trim());
		
		else if (qName.equalsIgnoreCase("comments") && (this.item != null))
			this.item.setComments(this.text.toString().trim());
		
		else if (qName.equalsIgnoreCase("enclosure") && (this.item != null))
			this.item.setEnclosure(this.text.toString().trim());
		
		else if (qName.equalsIgnoreCase("source") && (this.item != null))
			this.item.setSource(this.text.toString().trim());
		
		else if (qName.equalsIgnoreCase("category"))
		{
			if (this.item != null)
				this.item.addCategory(this.text.toString().trim());
			this.rssFeed.addCategory(this.text.toString().trim());
		}
		this.text.setLength(0);
	}

	public void characters(char[] ch, int start, int length)
	{
		this.text.append(ch, start, length);
	}

}