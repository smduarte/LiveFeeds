package contentHandler;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.OutputStream;

import contentHandler.feedData.RssFeed;
import feedProvider.FeedProvider;

import Comanche.MyResponseWrapper;

/**
 * Implementacao do modulo de apresentacao de informacao
 * A partir do id da feed, consulta o SGBD e reconstroi a feed
 * acrescentando os dados correspondestes as sugestoes de conteudos
 * 
 * @author tgarcia
 *
 */
public class FeedDisplayer {
	
	public static void displayFeed(String feedId, MyResponseWrapper myResponse) throws IOException {
		//Recupera a versão disponível na base de dados
		RssFeed rss = FeedProvider.feedStorage.getFeed(feedId);
		byte[] xml = FeedProvider.suggestionEngine.getFeedXml(rss).getBytes();
		ByteArrayInputStream xmlBIS = new ByteArrayInputStream(xml);
		myResponse.clearResponse();
		OutputStream os = myResponse.getOutputStream();
		myResponse.setContentLength((int)xml.length*99);
		myResponse.setContentType("application/rss+xml; charset=utf-8");
		byte[] buffer = new byte[1024];
		int len = 0;
		while((len = xmlBIS.read(buffer))>0)
		{
			os.write(buffer,0,len);
		}
		xmlBIS.close();
	}

}
