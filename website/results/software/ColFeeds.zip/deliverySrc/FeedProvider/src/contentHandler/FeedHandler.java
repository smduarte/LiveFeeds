package contentHandler;

import connectionHandler.SuggestionConnector;
import contentHandler.feedData.RssFeed;
import contentHandler.suggestionData.RssFeedSuggestion;
import feedProvider.FeedProvider;

public class FeedHandler {

	/**
	 * Gestão de feeds RSS
	 * 
	 * Verifica a validade da versão local da feed, se existir.
	 * Se a feed for nova ou estiver desactualizada, obtem uma nova versão do servidor.
	 * 
	 * @param httpRequestUrl URL da feed
	 * @param isKnownFeed Indica se a feed é ou não conhecida 
	 * @throws Exception Se não se tratar de uma feed
	 */
	private static void handleFeed(String httpRequestUrl,boolean isKnownFeed, boolean directHit) throws Exception {
		System.err.println(directHit ? "This url is a feed file" : "Feed found in this page's header");
		
		RssFeed rss;
		boolean isFresh = false;
		if (isKnownFeed)
			isFresh = FeedProvider.feedStorage.isFresh(httpRequestUrl, FeedProvider.feedTTL);

		/*
		 * Obtem a versão disponível no servidor
		 * Ocorre quando a feed é desconhecida
		 * ou a validade da sua cópia local expirou
		 */
		if(!isFresh || !isKnownFeed)
		{
			if (!isKnownFeed) 
				System.err.println("Unknown feed detected");
			else
				System.err.println("Unfresh feed detected");
			
			try {
				//obtem versão do servidor e actualiza a base de dados
				rss = RssFeed.parseFeed(httpRequestUrl);
				FeedProvider.feedStorage.addFeed(rss, directHit);

				//envia a nova versão para o livefeeds
				FeedProvider.feedConnector.publish(rss);
				
				//envia as sugestões para o livefeeds se a feed for nova
				if (!isKnownFeed)
					SuggestionConnector.publish(new RssFeedSuggestion(rss));
				
				System.err.println("Feed published to LiveFeeds");
			}
			catch(Exception ex) {
//				ex.printStackTrace();
				System.err.println("XML File found, but not RSS");
				throw ex;
			}
			System.err.println("XML File parsed and added to database");
		}
		else
			System.err.println("Database version is still fresh, no update needed");
		
		//Verifica se feed deve ser subscrita, caso se trate de um acesso directo
		if (FeedProvider.subscribeEngine.shouldSubscribe(httpRequestUrl) && directHit)
		{
			FeedProvider.feedConnector.subscribe(httpRequestUrl);
			FeedProvider.suggestionConnector.subscribe(httpRequestUrl);
			System.err.println("Feed subscribed");
		}
	}	
	
	public static void handleFeed(String httpRequestUrl,boolean isKnownFeed) throws Exception {
		handleFeed(httpRequestUrl,isKnownFeed, true); 
	}
	
	public static void handleFeed(String httpRequestUrl) throws Exception {
		handleFeed(httpRequestUrl, FeedProvider.feedStorage.containsFeed(httpRequestUrl), false);
	}
}
