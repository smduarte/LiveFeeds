package contentHandler.feedData;

import java.io.InputStream;
import java.io.Serializable;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

import contentHandler.suggestionData.RssFeedSuggestion;

/**
 * Objecto que representa a feed completa
 * 
 * @author tgarcia
 *
 */
public class RssFeed implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	private int directHit = 0;
	private int indirectHit = 0;
	private String url;
	
	private String header;
	private String title;
    private String description;
    private String link;
    private String language;
    private String generator;
    private String copyright;
    private String imageUrl;
    private String imageTitle;
    private String imageLink;
    private String version;
    private boolean isSubscribed = false;
    private Date lastUpdated;
   
    private ArrayList<RssItem> items;
    private ArrayList<String> category;
    
    public RssFeed() {
    	this.items = new ArrayList<RssItem>();
    	this.category = new ArrayList<String>();
    }
    
    public static RssFeed parseFeed(String address) throws Exception {
		RssFeed rss = new RssFeed();
		URL url = new URL(address);
		InputStream content = url.openStream();
		XmlParser parser = new XmlParser();
		rss = parser.parse(content, address);
		if (rss != null)
			rss.lastUpdated = new Date(System.currentTimeMillis());
		return rss;
	}
   
    public void addItem(RssItem item)
    {
        if (this.items == null)
            this.items = new ArrayList<RssItem>();
        this.items.add(item);
    }
    
	public String getHeader() {
		return header;
	}

	public void setHeader(String header) {
		this.header = header;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getGenerator() {
		return generator;
	}

	public void setGenerator(String generator) {
		this.generator = generator;
	}

	public String getCopyright() {
		return copyright;
	}

	public void setCopyright(String copyright) {
		this.copyright = copyright;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public String getImageTitle() {
		return imageTitle;
	}

	public void setImageTitle(String imageTitle) {
		this.imageTitle = imageTitle;
	}

	public String getImageLink() {
		return imageLink;
	}

	public void setImageLink(String imageLink) {
		this.imageLink = imageLink;
	}

	public ArrayList<RssItem> getItems() {
		return items;
	}

	public void setItems(ArrayList<RssItem> items) {
		this.items = items;
	}

	public ArrayList<String> getCategories() {
		return category;
	}

	public void setCategories(ArrayList<String> categorys) {
		this.category = categorys;
	}
	
	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}
     
	public void addCategory(String category) {
		Iterator<String> it = this.category.iterator();
		while (it.hasNext())
		{
			if (it.next().compareTo(category) == 0)
				return;
		}
		this.category.add(category);
	}

	public int getDirectHit() {
		return directHit;
	}

	public void incDirectHit(int hitCount) {
		this.directHit += hitCount;
	}

	public int getIndirectHit() {
		return indirectHit;
	}

	public void incIndirectHit(int hitCount) {
		this.indirectHit += hitCount;
	}
	
	public boolean isSubscribed() {
		return isSubscribed;
	}

	public void setSubscribed(boolean isSubscribed) {
		this.isSubscribed = isSubscribed;
	}
	
	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public RssFeedSuggestion getSuggestion() {
		return new RssFeedSuggestion(this);
	}
	
	public String getId() {
		return getFeedId(url);
	}
	
	public static String getFeedId(String url) {
		try {
			MessageDigest digest = java.security.MessageDigest.getInstance("MD5");
			digest.update(url.getBytes());
			byte[] array = digest.digest();

			String result = new String();
			for (int i=0; i < array.length; i++) {
				result += Integer.toString( ( array[i] & 0xff ) + 0x100, 16).substring( 1 );
			}
			return result;
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			return "";
		} catch (NullPointerException en) {
			//			en.printStackTrace();
			return null;
		}
	}
}