Esta pasta contem o projecto eclipse correspondente ao código da aplicação de transformação do Comanche que implementa todas as funcionalidades do protótipo. A classe principal é a FeedProvider, contida no ficheiro .java do mesmo nome. Todas as restantes classes têm descritas no topo a sua função. Algumas funções têm comentários pelo meio que ajudam a perceber o que nelas é feito. 

Na pasta WebContent existem dois ficheiros jar, correspondendo à biblioteca de comunicação com o Mysql (tem de estar instalado a priori) e ao LiveFeeds.

Este projecto permite exportar um ficheiro .war que, em conjunto com o ficheiro FeedProvider.xml, permitem a instalação da aplicação no Comanche.

Qualquer questão adicional podem-me contactar para:
tiagojsag@gmail.com
