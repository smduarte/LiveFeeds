package simsim.gui;

import simsim.gui.geom.XY;

public class InputHandler0 implements InputHandler {
	
	public void onMouseClick(int button, XY pu, XY ps) {
	}

	public void onMouseDragged(int button, XY pu, XY ps) {
	}

	public void onMouseMove(XY pu, XY ps) {
	}

}
